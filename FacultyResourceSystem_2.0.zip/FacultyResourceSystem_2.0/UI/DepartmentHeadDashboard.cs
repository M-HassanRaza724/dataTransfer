﻿using Krypton_toolKit_Demo.BL;
using Krypton_toolKit_Demo.UI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Krypton_toolKit_Demo
{
    public partial class DepartmentHeadDashboard: Form
    {
        static User User = null;
        public DepartmentHeadDashboard(User user = null)
        {
            InitializeComponent();
            User = user;
        }

        private void btn_courses_Click(object sender, EventArgs e)
        {
            new FacultyCourseSchedule(3).Show(); 
            this.Close();
        }

        private void btn_profiles_Click(object sender, EventArgs e)
        {
            new FacultyCourseAllocationForm(3).Show();
            this.Close();
        }

        private void btn_faculty_requests_Click(object sender, EventArgs e)
        {
            new FacultyRequestForm(3).Show();
            this.Close();
        }

        private void btn_semesters_Click(object sender, EventArgs e)
        {
            new ProjectSupervision(3).Show();
            this.Close();
        }

        private void btn_rooms_Click(object sender, EventArgs e)
        {
            new FacultyRoomAllocation().Show();
            this.Close();
        }

        private void btn_consumables_Click(object sender, EventArgs e)
        {
            new FacultyAdminRoleForm(3).Show();
            this.Close();
        }

        private void btn_logout_Click(object sender, EventArgs e)
        {
            User = null;
            new LoginForm().Show();
            this.Close();
        }
    }
}
