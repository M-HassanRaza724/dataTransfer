﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Krypton_toolKit_Demo.BL;
using ComponentFactory.Krypton.Toolkit;

namespace Krypton_toolKit_Demo.UI
{
    public partial class AddUpdateCourse : KryptonForm
    {
        Course course { get; set; }
        public AddUpdateCourse(Course course = null)
        {
            InitializeComponent();
            if(course != null )
                this.course = course;
        }

        private void AddUpdateCourse_Load(object sender, EventArgs e)
        {
            if(course != null)
            {
                txt_course_name.Text = course.course_name;
                txt_credit_hours.Text = course.credit_hours.ToString();
                txt_contact_hours.Text = course.contact_hours.ToString();
                btn_add_updt.Text = "Update";
                lbl_heading.Text = "Update Course";
                if (course.course_type == "Theory")
                    rdo_theory.Checked = true;
                else
                    rdo_lab.Checked = true;
            }
        }

        private void txt_course_name_Enter(object sender, EventArgs e)
        {
            if(txt_course_name.Text == "Enter a Course Name")
            {
                txt_course_name.Text = "";
            }
        }

        private void txt_course_name_Leave(object sender, EventArgs e)
        {
            if (txt_course_name.Text == "")
            {
                txt_course_name.Text = "Enter a Course Name";
            }
        }

        private void txt_credit_hours_Leave(object sender, EventArgs e)
        {
            if (txt_credit_hours.Text == "")
            {
                txt_credit_hours.Text = "Enter CreditHours";
            }
        }

        private void txt_credit_hours_Enter(object sender, EventArgs e)
        {
            if (txt_credit_hours.Text == "Enter CreditHours")
            {
                txt_credit_hours.Text = "";
            }
        }

        private void txt_contact_hours_Leave(object sender, EventArgs e)
        {
            if (txt_contact_hours.Text == "")
            {
                txt_contact_hours.Text = "Enter ContactHours";
            }
        }

        private void txt_contact_hours_Enter(object sender, EventArgs e)
        {
            if (txt_contact_hours.Text == "Enter ContactHours")
            {
                txt_contact_hours.Text = "";
            }
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_add_updt_Click(object sender, EventArgs e)
        {
            if (course != null)
            {
                course.course_name = txt_course_name.Text;
                course.credit_hours = Convert.ToInt32(txt_credit_hours.Text);
                course.contact_hours = Convert.ToInt32(txt_contact_hours.Text);
                course.course_type = rdo_theory.Checked ? "Theory" : "Lab";
                course.UpdateCourse();
            }
            else
            {
                try
                {
                    Course c = new Course(txt_course_name.Text, Convert.ToInt32(txt_credit_hours.Text), Convert.ToInt32(txt_contact_hours.Text), rdo_theory.Checked ? "Theory" : "Lab");
                    c.AddCourse();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            this.Close();
        }
    }

}
