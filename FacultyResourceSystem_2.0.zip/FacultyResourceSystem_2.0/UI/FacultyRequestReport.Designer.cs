﻿namespace Krypton_toolKit_Demo.UI
{
    partial class FacultyRequestReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.facultyRequestBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.rpt_faculty_requests = new Microsoft.Reporting.WinForms.ReportViewer();
            ((System.ComponentModel.ISupportInitialize)(this.facultyRequestBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // facultyRequestBindingSource
            // 
            this.facultyRequestBindingSource.DataSource = typeof(Krypton_toolKit_Demo.BL.FacultyRequestDTO);
            // 
            // rpt_faculty_requests
            // 
            this.rpt_faculty_requests.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.rpt_faculty_requests.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource1.Name = "DataSet1";
            reportDataSource1.Value = this.facultyRequestBindingSource;
            this.rpt_faculty_requests.LocalReport.DataSources.Add(reportDataSource1);
            this.rpt_faculty_requests.LocalReport.ReportEmbeddedResource = "Krypton_toolKit_Demo.Reports.ResourceRequest.rdlc";
            this.rpt_faculty_requests.Location = new System.Drawing.Point(0, 0);
            this.rpt_faculty_requests.Name = "rpt_faculty_requests";
            this.rpt_faculty_requests.ServerReport.BearerToken = null;
            this.rpt_faculty_requests.Size = new System.Drawing.Size(800, 450);
            this.rpt_faculty_requests.TabIndex = 0;
            // 
            // FacultyRequestReport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.rpt_faculty_requests);
            this.Name = "FacultyRequestReport";
            this.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.ProfessionalSystem;
            this.Text = "FacultyRequestReport";
            this.Load += new System.EventHandler(this.FacultyRequestReport_Load);
            ((System.ComponentModel.ISupportInitialize)(this.facultyRequestBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer rpt_faculty_requests;
        private System.Windows.Forms.BindingSource facultyRequestBindingSource;
    }
}