﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Krypton_toolKit_Demo.BL;
using Krypton_toolKit_Demo.DL;

namespace Krypton_toolKit_Demo.UI
{
    public partial class ProjectManagement : Form
    {
        static Project project;
        public ProjectManagement()
        {
            InitializeComponent();
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            //dgv_projects.DataSource = null;

            string name = null, sortby = null, direction = null;
            List<Project> projects;
            // Get the item text


            if (txt_search_projects.Text != "Search projects")
                name = txt_search_projects.Text;

            if (rdo_sort_id.Checked)
                sortby = "project_id";
            else if (rdo_sort_title.Checked)
                sortby = "title";
            else
                sortby = null;

            if (rdo_asc.Checked)
            {
                direction = "DESC";
            }
            else if (rdo_desc.Checked)
            {
                direction = "ASC";
            }

            //MessageBox.Show($"name is {name}, type is {itemType}, sort is {sortby}");
            projects = ProjectCRUD.GetProjects(name, sortby, direction);

            //ProjectBindingSource.DataSource = null;
            ProjectBindingSource.DataSource = projects;
            dgv_projects.DataSource = ProjectBindingSource;
            dgv_projects.Refresh();
            MessageBox.Show("Data Loaded Successfully");
        }

        private void dgv_projects_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //projectBindingSource.ResetBindings(true);
            if (e.RowIndex >= 0 && e.ColumnIndex == dgv_projects.Columns["update"].Index)
            {
                var cellValue = dgv_projects.Rows[e.RowIndex].Cells["projectidDataGridViewTextBoxColumn"].Value;
                int projectId = Convert.ToInt32(cellValue);
                project = ProjectCRUD.GetProject(projectId);
                enableGroupBox();
                //MessageBox.Show($"Update button clicked in row: {e.RowIndex + 1}");
            }
            if (e.RowIndex >= 0 && e.ColumnIndex == dgv_projects.Columns["delete"].Index)
            {
                var cellValue = dgv_projects.Rows[e.RowIndex].Cells["projectidDataGridViewTextBoxColumn"].Value;
                int projectId = Convert.ToInt32(cellValue);

                Project.DeleteProject(projectId);
                btn_search_Click(sender, e);
                //Handle button click
                //MessageBox.Show($"Delete button clicked in row: {e.RowIndex + 1}");

            }
        }

        private void btn_add_updt_Click(object sender, EventArgs e)
        {
            if (btn_add_updt.Text == "Update")
            {
                try
                {
                    Project p = new Project(project.project_id, txt_project_title.Text, txt_project_description.Text);
                    p.UpdateProject();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {

                try
                {
                    Project p = new Project(txt_project_title.Text, txt_project_description.Text);
                    p.AddProject();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            btn_search_Click(sender, e);
            disableGroupBox();
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            disableGroupBox();
        }
        private void enableGroupBox()
        {
            gbx_add_updt_project.Enabled = true;
            gbx_add_updt_project.Visible = true;
            if (project != null)
            {
                txt_project_title.Text = project.title;
                txt_project_description.Text = project.description;
                gbx_add_updt_project.Text = "Update Project";
                btn_add_updt.Text = "Update";
                gbx_add_updt_project.Refresh();

            }

        }
        private void disableGroupBox()
        {
            gbx_add_updt_project.Enabled = false;
            gbx_add_updt_project.Visible = false;
            project = null;
            txt_project_title.Text = "Enter Project Title";
            txt_project_description.Text = "Enter Project Description";
            gbx_add_updt_project.Text = "Add Project";
            btn_add_updt.Text = "Add";
            gbx_add_updt_project.Refresh();
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            enableGroupBox();
        }

        private void txt_search_projects_Leave(object sender, EventArgs e)
        {
            if (txt_search_projects.Text == "")
                txt_search_projects.Text = "Search projects";
        }

        private void txt_search_projects_Enter(object sender, EventArgs e)
        {
            if (txt_search_projects.Text == "Search projects")
                txt_search_projects.Text = "";
        }

        private void btn_dashboard_Click(object sender, EventArgs e)
        {
            new AdminDashboard().Show();
            this.Close();
        }

        private void ProjectManagement_Load(object sender, EventArgs e)
        {
            btn_search_Click(sender, e);
        }
    }
}
