﻿using ComponentFactory.Krypton.Toolkit;
using System;
using System.Windows.Forms;
using Krypton_toolKit_Demo.BL;

namespace Krypton_toolKit_Demo
{
    public partial class ForgotPasswordForm : KryptonForm
    {
        static User user;
        public ForgotPasswordForm()
        {
            InitializeComponent();
        }


        private void btn_back_to_login_Click(object sender, EventArgs e)
        {
            this.Close(); // Close the forgot password form and return to the login form

        }

        private void btn_authenticate_Click(object sender, EventArgs e)
        {
            string email = txt_email.Text;
            string username = txt_username.Text;   

            // Validate email (replace with your logic)
            if (User.forgotRequest(username,email))
            {
                btn_authenticate.Visible = false;
                btn_authenticate.Enabled = false;
                btn_back_to_login.Visible = false;
                btn_back_to_login.Enabled = false;
                txt_email.Enabled = false;
                txt_username.Visible = false;
                txt_new_password.Visible = true;
                txt_new_password2.Visible = true;
                btn_submit.Visible = true;
            }
            else
            {
                KryptonMessageBox.Show("Invalid email address or username", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_submit_Click(object sender, EventArgs e)
        {
            if(txt_new_password.Text == txt_new_password2.Text)
            {
                user = new User(txt_username.Text, txt_email.Text, txt_new_password.Text);
                user.ResetPassword();
                KryptonMessageBox.Show("Password reset successful.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
            KryptonMessageBox.Show("Passwords do not match.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }

        private void txt_new_password_Enter(object sender, EventArgs e)
        {
            if (txt_new_password.Text == "Enter New Password")
            {
                txt_new_password.Text = "";
            }
        }

        private void txt_new_password_Leave(object sender, EventArgs e)
        {
            if (txt_new_password.Text == "")
            {
                txt_new_password.Text = "Enter New Password";
            }
        }

        private void txt_new_password2_Leave(object sender, EventArgs e)
        {
            if (txt_new_password2.Text == "")
            {
                txt_new_password2.Text = "Re-enter New Password";
            }
        }

        private void txt_new_password2_Enter(object sender, EventArgs e)
        {
            if (txt_new_password2.Text == "Re-enter New Password")
            {
                txt_new_password2.Text = "";
            }
        }

        private void txt_email_Leave(object sender, EventArgs e)
        {
            if (txt_email.Text == "")
            {
                txt_email.Text = "Enter Registered Email";
            }
        }

        private void txt_email_Enter(object sender, EventArgs e)
        {
            if (txt_email.Text == "Enter Registered Email")
            {
                txt_email.Text = "";
            }
        }

        private void txt_username_Leave(object sender, EventArgs e)
        {
            if(txt_username.Text == "")
            {
                txt_username.Text = "Enter Registered Username";
            }
        }

        private void txt_username_Enter(object sender, EventArgs e)
        {
            if (txt_username.Text == "Enter Registered Username")
            {
                txt_username.Text = "";
            }
        }
    }
}