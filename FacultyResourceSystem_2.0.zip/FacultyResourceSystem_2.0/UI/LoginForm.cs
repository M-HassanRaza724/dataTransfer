﻿using ComponentFactory.Krypton.Toolkit;
using Krypton_toolKit_Demo;
using Krypton_toolKit_Demo.DL;
using MySql.Data.MySqlClient;
using System;
using System.Windows.Forms;

namespace Krypton_toolKit_Demo.UI
{
    public partial class LoginForm : KryptonForm
    {

        public LoginForm()
        {
            InitializeComponent();
        }

        private void RedirectToDashboard(int roleId,string email)
        {
            this.Hide();
            switch (roleId)
            {
                case 1: // Admin
                    new AdminDashboard().Show();
                    break;
                case 2: // Faculty
                    new FacultyDashboard(FacultyCRUD.GetFacultyIdFromEmail(email)).Show();
                    break;
                case 3: // Department Head
                    new DepartmentHeadDashboard().Show();
                    break;
                default:
                    KryptonMessageBox.Show("Invalid role.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
            }
        }

        

        private void btn_login_Click(object sender, EventArgs e)
        {
            string email = txt_email.Text;
            string password = txt_password.Text;
            User u = new User(email, password);
            if (u.Login())
            {
                RedirectToDashboard(u.RoleId,u.Email);
            }
            else
            {
                MessageBox.Show("Invalid email or password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_forgotPassword_Click(object sender, EventArgs e)
        {
            new ForgotPasswordForm().Show();

        }

        private void txt_email_Leave(object sender, EventArgs e)
        {
            if (txt_email.Text == "")
            {
                txt_email.Text = "Enter Email";
            }
        }

        private void txt_email_Enter(object sender, EventArgs e)
        {
            if (txt_email.Text == "Enter Email")
            {
                txt_email.Text = "";
            }
        }

        private void txt_password_Leave(object sender, EventArgs e)
        {
            if (txt_password.Text == "")
            {
                txt_password.Text = "Enter Password";
                txt_password.PasswordChar = '\0';
            }
        }

        private void txt_password_Enter(object sender, EventArgs e)
        {
            if (txt_password.Text == "Enter Password")
            {
                txt_password.Text = "";
            }
        }

        private void txt_password_TextChanged(object sender, EventArgs e)
        {
            if (txt_password.Text != "Enter Password")
            {
                txt_password.PasswordChar = '*';
            }
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {

        }
    }
}