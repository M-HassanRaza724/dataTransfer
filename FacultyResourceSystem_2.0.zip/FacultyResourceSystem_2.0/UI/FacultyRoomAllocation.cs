﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ComponentFactory.Krypton.Toolkit;
using Krypton_toolKit_Demo.BL;
using Krypton_toolKit_Demo.DL;

namespace Krypton_toolKit_Demo.UI
{
    public partial class FacultyRoomAllocation: KryptonForm
    {
        static int? room_allocation_id = null;
        static int faculty_id { get; set; }
        public FacultyRoomAllocation()
        {
            InitializeComponent();
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            string name = null, sortby = null, direction = null;
            List<FacultyRoomAllocationDTO> faculty_rooms;
            // Get the item text
            // Get the item text
            ItemCheckListHandler handler = new ItemCheckListHandler(cbx_semester_term);
            List<string> semester_terms = handler.GetCheckedItems();


            if (txt_search_faculty_rooms.Text != "Search room/faculty")
                name = txt_search_faculty_rooms.Text;

            if (rdo_sort_faculty_name.Checked)
                sortby = "f.name";
            else if (rdo_sort_semester_year.Checked)
                sortby = "s.year";
            else if (rdo_sort_room_name.Checked)
                sortby = "c.room_name";


            if (rdo_asc.Checked)
            {
                direction = "DESC";
            }
            else if (rdo_desc.Checked)
            {
                direction = "ASC";
            }
            faculty_rooms = FacultyRoomAllocationCRUD.GetRoomAllocations(name, semester_terms, sortby, direction);
            facultyRoomAllocationDTOBindingSource.DataSource = faculty_rooms;
            dgv_faculty_rooms.DataSource = facultyRoomAllocationDTOBindingSource;
        }

        private void dgv_faculty_rooms_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                var cellValue = dgv_faculty_rooms.Rows[e.RowIndex].Cells["facultyIdDataGridViewTextBoxColumn"].Value;
                faculty_id = Convert.ToInt32(cellValue);
            }
            if (e.RowIndex >= 0 && e.ColumnIndex == dgv_faculty_rooms.Columns["update"].Index)
            {
                var cellValue = dgv_faculty_rooms.Rows[e.RowIndex].Cells["allocationIdDataGridViewTextBoxColumn"].Value;
                room_allocation_id = Convert.ToInt32(cellValue);

                var ca = FacultyRoomAllocationCRUD.GetRoomAllocation(room_allocation_id.Value);
                enableGroupBox(ca);
                //MessageBox.Show($"Delete button clicked in row: {e.RowIndex + 1}");
            }
            if (e.RowIndex >= 0 && e.ColumnIndex == dgv_faculty_rooms.Columns["delete"].Index)
            {
                var cellValue = dgv_faculty_rooms.Rows[e.RowIndex].Cells["allocationIdDataGridViewTextBoxColumn"].Value;
                //IsDBNull(reader.GetOrdinal("AllocationId")) ? (int?)null : reader.GetInt32(reader.GetOrdinal("AllocationId"))
                if (cellValue != null && cellValue != DBNull.Value)
                {
                    room_allocation_id = Convert.ToInt32(cellValue);
                }
                FacultyRoomAllocationDTO.DeleteRoomAllocation(room_allocation_id.Value);
                room_allocation_id = null;
                btn_search_Click(sender, e);
                //MessageBox.Show($"Delete button clicked in row: {e.RowIndex + 1}");
            }
        }
        private void enableGroupBox(FacultyRoomAllocationDTO ca = null)
        {
            gbx_add_updt_faculty_room.Enabled = true;
            gbx_add_updt_faculty_room.Visible = true;
            List<string> years = SemesterCRUD.GetSemesterYears();
            cmbx_semester_year.Items.AddRange(years.ToArray());
            List<string> rooms = RoomCRUD.GetRoomsNames();
            cmbx_room.Items.AddRange(rooms.ToArray());
            List<string> faculty_names = FacultyCRUD.GetFacultyNames();
            cmbx_faculty_name.Items.AddRange(faculty_names.ToArray());

            if (room_allocation_id.HasValue)
            {
                if (ca.SemesterYear.HasValue)
                {
                    cmbx_semester_year.Text = ca.SemesterYear.Value.ToString();
                }
                else
                {
                    cmbx_semester_year.Text = string.Empty;
                }
                cmbx_semester_term.Text = ca.SemesterTerm ?? string.Empty;
                cmbx_room.Text = ca.RoomName;
                txt_reserved_hours.Text = ca.ReservedHours.ToString();
                cmbx_faculty_name.Text = ca.FacultyName;

                btn_add_updt.Text = "Update";
            }
        }
        private void disableGroupBox()
        {
            gbx_add_updt_faculty_room.Enabled = false;
            gbx_add_updt_faculty_room.Visible = false;
            cmbx_semester_year.Text = "Select Year";
            cmbx_semester_term.Text = "Select Term";
            cmbx_room.Text = "Select Room";
            txt_reserved_hours.Text = "Enter Reserved Hours";

            room_allocation_id = null;
            cmbx_room.Items.Clear();
            cmbx_semester_year.Items.Clear();
            cmbx_faculty_name.Items.Clear();
            room_allocation_id = null;
            faculty_id = 0;
        }

        private void FacultyRoomAllocationForm_Load(object sender, EventArgs e)
        {
            //List<string> years = SemesterCRUD.GetSemesterYears();
            //cmbx_semester_year.Items.AddRange(years.ToArray());
        }

        private void cmbx_semester_year_SelectedIndexChanged(object sender, EventArgs e)
        {
            int selectedValue = Convert.ToInt32(cmbx_semester_year.Text);
            List<string> terms = SemesterCRUD.GetSemesterTerms(selectedValue);
            cmbx_semester_term.Items.Clear();
            cmbx_semester_term.Items.AddRange(terms.ToArray());
        }


        private void btn_add_updt_Click(object sender, EventArgs e)
        {
            try
            {

                if (room_allocation_id.HasValue)
                {
                    if (room_allocation_id.HasValue)
                    {
                        FacultyRoomAllocationDTO ca = new FacultyRoomAllocationDTO
                        {
                            RoomName = cmbx_room.Text,
                            ReservedHours = Convert.ToInt32(txt_reserved_hours.Text),
                            AllocationId = room_allocation_id.Value,
                            SemesterId = SemesterCRUD.GetSemesterId(Convert.ToInt32(cmbx_semester_year.Text), cmbx_semester_term.Text),
                            RoomId = RoomCRUD.GetRoomId(cmbx_room.Text),
                            FacultyId = faculty_id,
                            SemesterYear = Convert.ToInt32(cmbx_semester_year.Text)
                        };
                        ca.UpdateRoomAllocation();
                    }
                }
                else
                {
                    FacultyRoomAllocationDTO ca = new FacultyRoomAllocationDTO
                    {
                        RoomName = txt_search_faculty_rooms.Text,
                        SemesterId = SemesterCRUD.GetSemesterId(Convert.ToInt32(cmbx_semester_year.Text), cmbx_semester_term.Text),
                        //SemesterYear = Convert.ToInt32(cmbx_semester_year.Text),
                        ReservedHours = Convert.ToInt32(txt_reserved_hours.Text),

                        RoomId = RoomCRUD.GetRoomId(cmbx_room.Text),
                        FacultyId = FacultyCRUD.GetFacultyId(cmbx_faculty_name.Text)
                    };
                    ca.AddRoomAllocation();

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                disableGroupBox();
                btn_search_Click(sender, e);
            }
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            disableGroupBox();
        }

       

        private void btn_add_Click(object sender, EventArgs e)
        {
            enableGroupBox();
        }

        private void btn_dashboard_Click_1(object sender, EventArgs e)
        {
            new DepartmentHeadDashboard().Show();
            this.Close();
        }

        private void FacultyRoomAllocation_Load(object sender, EventArgs e)
        {
            btn_search_Click(sender, e);
        }
    }
}
