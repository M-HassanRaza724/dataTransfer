﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using ComponentFactory.Krypton.Toolkit;
using Krypton_toolKit_Demo.BL;
using Krypton_toolKit_Demo.DL;

namespace Krypton_toolKit_Demo.UI
{
    public partial class CourseManagement : KryptonForm
    {
        public CourseManagement()
        {
            InitializeComponent();
        }

        private void CourseManagement_Load(object sender, EventArgs e)
        {
            btn_search_Click(sender, e);
        }

        static string itemType = null;
        private void btn_search_Click(object sender, EventArgs e)
        {
        string name = null,sortby = null;
            List<Course> courses;
            // Get the item text


            if (txt_search_courses.Text != "Search courses")
                name = txt_search_courses.Text;

            if (rdo_sort1.Checked)
                sortby = "contact_hours";
            else if (rdo_sort2.Checked)
                sortby = "credit_hours";
            else if (rdo_sort3.Checked)
                sortby = "course_id";
            else
                sortby = null;

            MessageBox.Show($"name is {name}, type is {itemType}, sort is {sortby}");
            courses = CourseCRUD.GetCourses(name,itemType,sortby);

            CourseBindingSource.DataSource = courses;
            dgv_courses.DataSource = CourseBindingSource;
            dgv_courses.Refresh();
            MessageBox.Show("Data Loaded Successfully");
        }
       



        private void dgv_courses_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex == dgv_courses.Columns["update"].Index)
            {
                var cellValue = dgv_courses.Rows[e.RowIndex].Cells["courseidDataGridViewTextBoxColumn"].Value;
                int courseId = Convert.ToInt32(cellValue);
                Course course = CourseCRUD.GetCourseFromDB(courseId);
                new AddUpdateCourse(course).ShowDialog();
                //MessageBox.Show($"Update button clicked in row: {e.RowIndex + 1}");
            }
            if (e.RowIndex >= 0 && e.ColumnIndex == dgv_courses.Columns["delete"].Index)
            {
                var cellValue = dgv_courses.Rows[e.RowIndex].Cells["courseidDataGridViewTextBoxColumn"].Value;
                int courseId = Convert.ToInt32(cellValue);
                CourseCRUD.DeleteCourse(courseId);
                btn_search_Click(sender, e);
                // Handle button click
                //MessageBox.Show($"Delete button clicked in row: {e.RowIndex + 1}");
            }
        }

        private void cbx_type_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            // Get the current state of the items
            bool isItem1Checked = cbx_type.GetItemChecked(0);
            bool isItem2Checked = cbx_type.GetItemChecked(1);

            // Determine the new state after the current change
            if (e.Index == 0)
            {
                isItem1Checked = (e.NewValue == CheckState.Checked);
            }
            else if (e.Index == 1)
            {
                isItem2Checked = (e.NewValue == CheckState.Checked);
            }

            // Logic to determine the return value
            if (isItem1Checked && isItem2Checked)
            {
                // Both items are checked
                itemType = null;
                //MessageBox.Show("Returning: null (both items are checked)");
            }
            else if (!isItem1Checked && !isItem2Checked)
            {
                // Both items are unchecked
                itemType = null;
                //MessageBox.Show("Returning: null (both items are unchecked)");
            }
            else
            {
                // Only one item is checked
                string checkedItemText = isItem1Checked ? cbx_type.Items[0].ToString() : cbx_type.Items[1].ToString();
                itemType = checkedItemText;
                //MessageBox.Show($"Returning: {checkedItemText}");
            }
        }

        private void kryptonRadioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void lbl_sort_Click(object sender, EventArgs e)
        {

        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            new AddUpdateCourse().ShowDialog();
        }

        private void txt_search_courses_Leave(object sender, EventArgs e)
        {
            if (txt_search_courses.Text == "")
            {
                txt_search_courses.Text = "Search courses";
            }
        }

        private void txt_search_courses_Enter(object sender, EventArgs e)
        {
            if (txt_search_courses.Text == "Search courses")
            {
                txt_search_courses.Text = "";
            }
        }

        private void btn_dashboard_Click(object sender, EventArgs e)
        {
            new AdminDashboard().Show();
            this.Close();

        }
    }
}

