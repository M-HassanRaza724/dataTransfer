﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ComponentFactory.Krypton.Toolkit;
using Krypton_toolKit_Demo.DL;

namespace Krypton_toolKit_Demo.UI
{
    public partial class ScheduleReportForm: KryptonForm
    {
        int FacultyId = 0;
        public ScheduleReportForm(int facultyId)
        {
            InitializeComponent();
            FacultyId = facultyId;
        }

        private void SheduleReportForm_Load(object sender, EventArgs e)
        {
            reportViewer1.Clear();
            facultyCourseScheduleDTOBindingSource.DataSource = FacultyCourseScheduleCRUD.GetFacultyCourseSchedules(FacultyId);
            this.reportViewer1.RefreshReport();
        }
    }
}
