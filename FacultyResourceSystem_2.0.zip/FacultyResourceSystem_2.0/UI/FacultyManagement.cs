﻿using ComponentFactory.Krypton.Toolkit;
using Krypton_toolKit_Demo.BL;
using Krypton_toolKit_Demo.DL;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Krypton_toolKit_Demo.UI
{
    public partial class FacultyManagement : KryptonForm
    {
        static User user = null;
        static Faculty faculty = null;
        public FacultyManagement()
        {
            InitializeComponent();
        }

        private void gbx_add_updt_faculty_Panel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void gbx_add_updt_faculty_Paint(object sender, PaintEventArgs e)
        {

        }

        private void kryptonTextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void FacultyManagement_Load(object sender, EventArgs e)
        {
            //btn_search_Click(sender, e);
            List<string> designations = LookupCRUD.GetValues("Designations");
            cmbx_designations.Items.AddRange(designations.ToArray());
            cbx_designation.Items.AddRange(designations.ToArray());
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            List<Faculty> facultys;
            string name = null, sortby = null, direction = null;
            // Get the item text
            ItemCheckListHandler handler = new ItemCheckListHandler(cbx_designation);
            List<string> designations = handler.GetCheckedItems();

            if (txt_search_facultys.Text != "Search faculty")
                name = txt_search_facultys.Text;

            if (rdo_sort_name.Checked)
                sortby = "name";
            else if (rdo_sort_email.Checked)
                sortby = "email";
            else if (rdo_sort_id.Checked)
                sortby = "faculty_id";

            if (rdo_asc.Checked)
            {
                direction = "DESC";
            }
            else if (rdo_desc.Checked)
            {
                direction = "ASC";
            }

            //MessageBox.Show($"name is {name}, type is {itemType}, sort is {sortby}");
            facultys = FacultyCRUD.GetFaculties(name, designations, sortby, direction);

            facultyBindingSource.DataSource = facultys;
            dgv_facultys.DataSource = facultyBindingSource;
            dgv_facultys.Refresh();
            MessageBox.Show("Data Loaded Successfully");
        }
        private void enableGroupBox()
        {
            gbx_add_updt_faculty.Enabled = true;
            gbx_add_updt_faculty.Visible = true;
            if (faculty != null)
            {
                txt_name.Text = faculty.name;
                txt_email.Text = faculty.email;
                txt_research_area.Text = faculty.research_area;
                txt_teaching_hours.Text = faculty.total_teaching_hours.ToString();
                txt_contact.Text = faculty.contact;
                txt_email.Visible = false;
                txt_user_name.Visible = false;
                txt_password.Visible = false;
                //lbl_email.Visible = false;
                lbl_user_name.Visible = false;
                //lbl_password.Visible = false;
                gbx_add_updt_faculty.Size = new System.Drawing.Size(348, 420);
                btn_add_updt.Location = new System.Drawing.Point(76, 332);
                btn_back.Location = new System.Drawing.Point(202, 332);
                gbx_add_updt_faculty.Location = new System.Drawing.Point(138, 66);

                cmbx_designations.SelectedIndex = faculty.designation_id - 4;
                gbx_add_updt_faculty.Text = "Update Faculty";
                btn_add_updt.Text = "Update";
                gbx_add_updt_faculty.Refresh();
            }
            else
            {

                txt_email.Visible = true;
                txt_user_name.Visible = true;
                txt_password.Visible = true;
                //lbl_email.Visible = true;
                lbl_user_name.Visible = true;
                //lbl_password.Visible = true;
                gbx_add_updt_faculty.Size = new System.Drawing.Size(667, 353);
                btn_add_updt.Location = new System.Drawing.Point(372, 254);
                btn_back.Location = new System.Drawing.Point(246, 254);
                gbx_add_updt_faculty.Location = new System.Drawing.Point(138, 66);
            }
        }

        private void disableGroupBox()
        {
            gbx_add_updt_faculty.Enabled = false;
            gbx_add_updt_faculty.Visible = false;
            faculty = null;
            txt_name.Text = "Enter Name";
            txt_user_name.Text = "Enter UserName";
            txt_research_area.Text = "Enter Reasearch Area";
            txt_email.Text = "Enter Email";
            txt_password.Text = "Enter Password";
            gbx_add_updt_faculty.Text = "Add Faculty";
            btn_add_updt.Text = "Add";
            gbx_add_updt_faculty.Refresh();
        }

        private void dgv_facultys_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex == dgv_facultys.Columns["update"].Index)
            {
                var cellValue = dgv_facultys.Rows[e.RowIndex].Cells["facultyidDataGridViewTextBoxColumn"].Value;
                int facultyId = Convert.ToInt32(cellValue);
                faculty = FacultyCRUD.GetFaculty(facultyId);
                //user = UserCRUD.GetUser(faculty.user_id);
                enableGroupBox();
                //MessageBox.Show($"Update button clicked in row: {e.RowIndex + 1}");
            }
            if (e.RowIndex >= 0 && e.ColumnIndex == dgv_facultys.Columns["delete"].Index)
            {
                var cellValue = dgv_facultys.Rows[e.RowIndex].Cells["facultyidDataGridViewTextBoxColumn"].Value;
                int facultyId = Convert.ToInt32(cellValue);

                Faculty.DeleteFaculty(facultyId);
                btn_search_Click(sender, e);
                //Handle button click
                //MessageBox.Show($"Delete button clicked in row: {e.RowIndex + 1}");
            }
        }

        private void txt_email_Leave(object sender, EventArgs e)
        {
            if (txt_email.Text == "")
            {
                txt_email.Text = "Enter Email";
            }
            else if (txt_email.Text != "Enter Email")
            {
                user = UserCRUD.GetUser(txt_email.Text);
                IfUserFound(user);
            }
        }

        private void txt_password_Leave(object sender, EventArgs e)
        {
            if (txt_password.Text == "")
            {
                txt_password.Text = "Enter Password";
            }
            else
            {
                txt_password.PasswordChar = '*';
            }
        }
        private void IfUserFound(User user)
        {
            if (user != null && user.RoleId == 2)
            {
                txt_user_name.Text = user.Name;
                txt_password.PasswordChar = '*';
                txt_password.Text = "password";
                MessageBox.Show("User Found");
            }
            else if (user != null && user.RoleId != 2)
            {
                txt_email.Text = "Enter Email";
                MessageBox.Show("Email already exist with different identity");
            }
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            enableGroupBox();
        }

        private void btn_add_updt_Click(object sender, EventArgs e)
        {
            if (btn_add_updt.Text == "Update")
            {
                try
                {
                    Faculty f = new Faculty(faculty.faculty_id, txt_name.Text, faculty.email, txt_contact.Text, LookupCRUD.GetId(cmbx_designations.Text), txt_research_area.Text, Convert.ToInt32(txt_teaching_hours.Text),faculty.user_id);
                    f.UpdateFaculty();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                try
                {
                    if (user == null)
                    {
                        string email = txt_email.Text;
                        User us = new User(txt_user_name.Text, txt_email.Text, PasswordHasher.HashPassword( txt_password.Text),   2);
                        us.AddUser();
                        user = UserCRUD.GetUser(email);
                    }
                    Faculty f = new Faculty(txt_name.Text, txt_email.Text, txt_contact.Text, LookupCRUD.GetId(cmbx_designations.Text), txt_research_area.Text, Convert.ToInt32(txt_teaching_hours.Text), user.UserId);

                    f.AddFaculty();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(cmbx_designations.Text);
                    MessageBox.Show($"{LookupCRUD.GetId(cmbx_designations.Text)}");
                    MessageBox.Show(ex.Message);
                }
            }
            disableGroupBox();
            btn_search_Click(sender, e);
        }

        private void gbx_add_updt_faculty_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            disableGroupBox();
        }

        private void txt_search_facultys_Leave(object sender, EventArgs e)
        {
            if (txt_search_facultys.Text == "")
            {
                txt_search_facultys.Text = "Search faculty";
            }
        }

        private void txt_search_facultys_Enter(object sender, EventArgs e)
        {
            if(txt_search_facultys.Text == "Search faculty")
            {
                txt_search_facultys.Text = "";
            }
        }

        private void txt_name_Leave(object sender, EventArgs e)
        {
            
            if (txt_name.Text == "")
            {
                txt_name.Text = "Enter Name";
            }
        }

        private void txt_name_Enter(object sender, EventArgs e)
        {
            if (txt_name.Text == "Enter Name")
            {
                txt_name.Text = "";
            }
        }

        private void txt_contact_Leave(object sender, EventArgs e)
        {
            if (txt_contact.Text == "")
            {
                txt_contact.Text = "Enter ContactNo.";
            }
        }

        private void txt_contact_Enter(object sender, EventArgs e)
        {
            if (txt_contact.Text == "Enter ContactNo.")
            {
                txt_contact.Text = "";
            }
        }

        private void txt_teaching_hours_Leave(object sender, EventArgs e)
        {
            if (txt_teaching_hours.Text == "")
            {
                txt_teaching_hours.Text = "Enter Teaching Hours";
            }
        }

        private void txt_teaching_hours_Enter(object sender, EventArgs e)
        {
            if (txt_teaching_hours.Text == "Enter Teaching Hours")
            {
                txt_teaching_hours.Text = "";
            }
        }

        private void txt_research_area_Leave(object sender, EventArgs e)
        {
            if(txt_research_area.Text == "")
            {
                txt_research_area.Text = "Enter Research Area";
            }
        }

        private void txt_research_area_Enter(object sender, EventArgs e)
        {
            if (txt_research_area.Text == "Enter Research Area")
            {
                txt_research_area.Text = "";
            }
        }

        private void txt_email_Enter(object sender, EventArgs e)
        {
            if (txt_email.Text == "Enter Email")
            {
                txt_email.Text = "";
            }
        }

        private void txt_user_name_Leave(object sender, EventArgs e)
        {
            if(txt_user_name.Text == "")
            {
                txt_user_name.Text = "Enter UserName";
            }
        }

        private void txt_user_name_Enter(object sender, EventArgs e)
        {
            if (txt_user_name.Text == "Enter UserName")
            {
                txt_user_name.Text = "";
            }
        }

        private void txt_password_Enter(object sender, EventArgs e)
        {
            if (txt_password.Text == "Enter Password")
            {
                txt_password.Text = "";
            }
        }

        private void btn_dashboard_Click(object sender, EventArgs e)
        {
            new AdminDashboard().Show();
            this.Close();
        }
    }
}

