﻿using Krypton_toolKit_Demo.UI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Krypton_toolKit_Demo
{
    public partial class FacultyDashboard: Form
    {
        int facultyId;
        static User User;
        public FacultyDashboard(int facultyId,User user = null)
        {
            InitializeComponent();
            this.facultyId = facultyId;
            User = user;
        }

        private void btn_profiles_Click(object sender, EventArgs e)
        {
            new FacultyCourseSchedule(2, facultyId).Show();
        }

        private void FacultyDashboard_Load(object sender, EventArgs e)
        {

        }

        private void btn_courses_Click(object sender, EventArgs e)
        {
            new FacultyCourseSchedule(2,facultyId).Show();
            this.Close();
        }

        private void btn_profiles_Click_1(object sender, EventArgs e)
        {
            new FacultyCourseAllocationForm(2, facultyId).Show();
            this.Close();
        }

        private void btn_faculty_requests_Click(object sender, EventArgs e)
        {
            new FacultyRequestForm(2, facultyId).Show();
            this.Close();
        }

        private void btn_semesters_Click(object sender, EventArgs e)
        {
            new ProjectSupervision(2,facultyId).Show();
            this.Close();
        }

        private void btn_consumables_Click(object sender, EventArgs e)
        {
            new FacultyAdminRoleForm(2,facultyId).Show();
            this.Close();
        }

        private void btn_logout_Click(object sender, EventArgs e)
        {
            User = null;
            new LoginForm().Show();
            this.Close();
        }
    }
}
