﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ComponentFactory.Krypton.Toolkit;
using Krypton_toolKit_Demo.BL;
using Krypton_toolKit_Demo.DL;


namespace Krypton_toolKit_Demo.UI
{
    public partial class ConsumableManagement: KryptonForm
    {
        static Consumable consumable;
        public ConsumableManagement()
        {
            InitializeComponent();
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            consumableBindingSource.Clear();
            string name = null,sortby = null, direction = null;
            if (txt_search_consumables.Text != "Search consumables")
                name = txt_search_consumables.Text;
            if (rdo_sort_consumable_id.Checked)
                sortby = "consumable_id";
            else if (rdo_sort_item_name.Checked)
                sortby = "item_name";
            if(rdo_asc.Checked)
                direction = "DESC";
            else if (rdo_desc.Checked)
                direction = "ASC";
            consumableBindingSource.DataSource = ConsumableCRUD.GetConsumables(name, sortby, direction);
            dgv_consumables.DataSource = consumableBindingSource;
        }

        private void txt_search_consumables_Leave(object sender, EventArgs e)
        {
            if (txt_search_consumables.Text == "")
            {
                txt_search_consumables.Text = "Search consumables";
            }
        }

        private void txt_search_consumables_Enter(object sender, EventArgs e)
        {
            if (txt_search_consumables.Text == "Search consumables")
            {
                txt_search_consumables.Text = "";
            }
        }

        private void txt_consumable_name_Leave(object sender, EventArgs e)
        {
            if (txt_consumable_name.Text == "")
            {
                txt_consumable_name.Text = "Enter Consumable Name";
            }
        }

        private void txt_consumable_name_Enter(object sender, EventArgs e)
        {
            if (txt_consumable_name.Text == "Enter Consumable Name")
            {
                txt_consumable_name.Text = "";
            }
        }

        private void dgv_consumables_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex == dgv_consumables.Columns["update"].Index)
            {
                var cellValue = dgv_consumables.Rows[e.RowIndex].Cells["consumableidDataGridViewTextBoxColumn"].Value;
                int consumableId = Convert.ToInt32(cellValue);
                consumable = ConsumableCRUD.GetConsumable(consumableId);
                enableGroupBox();
                //MessageBox.Show($"Update button clicked in row: {e.RowIndex + 1}");
            }
            if (e.RowIndex >= 0 && e.ColumnIndex == dgv_consumables.Columns["delete"].Index)
            {
                var cellValue = dgv_consumables.Rows[e.RowIndex].Cells["consumableidDataGridViewTextBoxColumn"].Value;
                int consumableId = Convert.ToInt32(cellValue);

                Consumable.DeleteConsumable(consumableId);
                btn_search_Click(sender, e);
                //Handle button click
                //MessageBox.Show($"Delete button clicked in row: {e.RowIndex + 1}");
            }
        }

        private void btn_add_updt_Click(object sender, EventArgs e)
        {
            if (btn_add_updt.Text == "Update")
            {
                try
                {
                    Consumable c = new Consumable(consumable.consumable_id,txt_consumable_name.Text);
                    c.UpdateConsumable();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {

                try
                {
                    Consumable c = new Consumable(txt_consumable_name.Text);
                    c.AddConsumable();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            btn_search_Click(sender, e);
            disableGroupBox();
        }
        void enableGroupBox()
        {
            gbx_add_updt_consumable.Enabled = true;
            gbx_add_updt_consumable.Visible = true;
            if(consumable != null)
            {
                txt_consumable_name.Text = consumable.item_name;
                btn_add_updt.Text = "Update";
                gbx_add_updt_consumable.Text = "Update Consumable";
            }
        }
        void disableGroupBox()
        {
            gbx_add_updt_consumable.Enabled = false;
            gbx_add_updt_consumable.Visible = false;
            consumable = null;
            txt_consumable_name.Text = "Enter Consumable Name";
            btn_add_updt.Text = "Add";
            gbx_add_updt_consumable.Text = "Add Consumable";
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            disableGroupBox();
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            enableGroupBox();
        }

        private void btn_dashboard_Click(object sender, EventArgs e)
        {
            new AdminDashboard().Show();
            this.Close();

        }

        private void ConsumableManagement_Load(object sender, EventArgs e)
        {
            btn_search_Click(sender, e);
        }
    }
}
