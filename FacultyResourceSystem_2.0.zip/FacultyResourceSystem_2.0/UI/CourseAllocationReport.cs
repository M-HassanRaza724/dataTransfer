﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Krypton_toolKit_Demo.DL;

namespace Krypton_toolKit_Demo.UI
{
    public partial class CourseAllocationReport: Form
    {
        public CourseAllocationReport()
        {
            InitializeComponent();
        }

        private void CourseAllocationReport_Load(object sender, EventArgs e)
        {
            courseAllocationDTOBindingSource.DataSource = CourseAllocationCRUD.GetCourseAllocations();
            this.reportViewer1.RefreshReport();
        }
    }
}
