﻿namespace Krypton_toolKit_Demo.UI
{
    partial class FacultyManagement
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label lbl_direction;
            System.Windows.Forms.Label lbl_sort;
            System.Windows.Forms.Label label1;
            System.Windows.Forms.Label lbl_email;
            System.Windows.Forms.Label lbl_password;
            this.gbx_add_updt_faculty = new ComponentFactory.Krypton.Toolkit.KryptonGroupBox();
            this.kryptonPalette1 = new ComponentFactory.Krypton.Toolkit.KryptonPalette(this.components);
            this.lbl_teaching_hours = new System.Windows.Forms.Label();
            this.txt_teaching_hours = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.lbl_contact = new System.Windows.Forms.Label();
            this.txt_contact = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.lbl_designations = new System.Windows.Forms.Label();
            this.txt_password = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.lbl_name = new System.Windows.Forms.Label();
            this.txt_name = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.cmbx_designations = new ComponentFactory.Krypton.Toolkit.KryptonComboBox();
            this.txt_email = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.btn_back = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.btn_add_updt = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.lbl_research_area = new System.Windows.Forms.Label();
            this.lbl_user_name = new System.Windows.Forms.Label();
            this.txt_research_area = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.txt_user_name = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.pnl_sort_direction = new System.Windows.Forms.Panel();
            this.rdo_desc = new ComponentFactory.Krypton.Toolkit.KryptonRadioButton();
            this.rdo_asc = new ComponentFactory.Krypton.Toolkit.KryptonRadioButton();
            this.pnl_sortby = new System.Windows.Forms.Panel();
            this.rdo_sort_name = new ComponentFactory.Krypton.Toolkit.KryptonRadioButton();
            this.rdo_sort_id = new ComponentFactory.Krypton.Toolkit.KryptonRadioButton();
            this.rdo_sort_email = new ComponentFactory.Krypton.Toolkit.KryptonRadioButton();
            this.btn_add = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.txt_search_facultys = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.btn_dashboard = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.btn_search = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.cbx_designation = new ComponentFactory.Krypton.Toolkit.KryptonCheckedListBox();
            this.dgv_facultys = new ComponentFactory.Krypton.Toolkit.KryptonDataGridView();
            this.facultyidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.emailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contactDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.designationidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.designationDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.researchareaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.totalteachinghoursDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.useridDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.update = new ComponentFactory.Krypton.Toolkit.KryptonDataGridViewButtonColumn();
            this.delete = new ComponentFactory.Krypton.Toolkit.KryptonDataGridViewButtonColumn();
            this.facultyBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.lbl_designation = new System.Windows.Forms.Label();
            lbl_direction = new System.Windows.Forms.Label();
            lbl_sort = new System.Windows.Forms.Label();
            label1 = new System.Windows.Forms.Label();
            lbl_email = new System.Windows.Forms.Label();
            lbl_password = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.gbx_add_updt_faculty)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gbx_add_updt_faculty.Panel)).BeginInit();
            this.gbx_add_updt_faculty.Panel.SuspendLayout();
            this.gbx_add_updt_faculty.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cmbx_designations)).BeginInit();
            this.pnl_sort_direction.SuspendLayout();
            this.pnl_sortby.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_facultys)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.facultyBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_direction
            // 
            lbl_direction.AutoSize = true;
            lbl_direction.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            lbl_direction.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            lbl_direction.Location = new System.Drawing.Point(9, 193);
            lbl_direction.Name = "lbl_direction";
            lbl_direction.Size = new System.Drawing.Size(65, 18);
            lbl_direction.TabIndex = 67;
            lbl_direction.Text = "Direction";
            // 
            // lbl_sort
            // 
            lbl_sort.AutoSize = true;
            lbl_sort.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            lbl_sort.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            lbl_sort.Location = new System.Drawing.Point(12, 84);
            lbl_sort.Name = "lbl_sort";
            lbl_sort.Size = new System.Drawing.Size(51, 18);
            lbl_sort.TabIndex = 61;
            lbl_sort.Text = "Sort by";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new System.Drawing.Font("Calibri", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            label1.Location = new System.Drawing.Point(281, 14);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(76, 24);
            label1.TabIndex = 58;
            label1.Text = "Facultys";
            // 
            // lbl_email
            // 
            lbl_email.AutoSize = true;
            lbl_email.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            lbl_email.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            lbl_email.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            lbl_email.Location = new System.Drawing.Point(331, 13);
            lbl_email.Name = "lbl_email";
            lbl_email.Size = new System.Drawing.Size(51, 20);
            lbl_email.TabIndex = 42;
            lbl_email.Text = "Email:";
            // 
            // lbl_password
            // 
            lbl_password.AutoSize = true;
            lbl_password.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            lbl_password.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            lbl_password.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            lbl_password.Location = new System.Drawing.Point(323, 134);
            lbl_password.Name = "lbl_password";
            lbl_password.Size = new System.Drawing.Size(80, 20);
            lbl_password.TabIndex = 43;
            lbl_password.Text = "Password:";
            // 
            // gbx_add_updt_faculty
            // 
            this.gbx_add_updt_faculty.Enabled = false;
            this.gbx_add_updt_faculty.Location = new System.Drawing.Point(138, 66);
            this.gbx_add_updt_faculty.Name = "gbx_add_updt_faculty";
            this.gbx_add_updt_faculty.Palette = this.kryptonPalette1;
            this.gbx_add_updt_faculty.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.Custom;
            // 
            // gbx_add_updt_faculty.Panel
            // 
            this.gbx_add_updt_faculty.Panel.Controls.Add(this.lbl_teaching_hours);
            this.gbx_add_updt_faculty.Panel.Controls.Add(this.txt_teaching_hours);
            this.gbx_add_updt_faculty.Panel.Controls.Add(lbl_password);
            this.gbx_add_updt_faculty.Panel.Controls.Add(lbl_email);
            this.gbx_add_updt_faculty.Panel.Controls.Add(this.lbl_contact);
            this.gbx_add_updt_faculty.Panel.Controls.Add(this.txt_contact);
            this.gbx_add_updt_faculty.Panel.Controls.Add(this.lbl_designations);
            this.gbx_add_updt_faculty.Panel.Controls.Add(this.txt_password);
            this.gbx_add_updt_faculty.Panel.Controls.Add(this.lbl_name);
            this.gbx_add_updt_faculty.Panel.Controls.Add(this.txt_name);
            this.gbx_add_updt_faculty.Panel.Controls.Add(this.cmbx_designations);
            this.gbx_add_updt_faculty.Panel.Controls.Add(this.txt_email);
            this.gbx_add_updt_faculty.Panel.Controls.Add(this.btn_back);
            this.gbx_add_updt_faculty.Panel.Controls.Add(this.btn_add_updt);
            this.gbx_add_updt_faculty.Panel.Controls.Add(this.lbl_research_area);
            this.gbx_add_updt_faculty.Panel.Controls.Add(this.lbl_user_name);
            this.gbx_add_updt_faculty.Panel.Controls.Add(this.txt_research_area);
            this.gbx_add_updt_faculty.Panel.Controls.Add(this.txt_user_name);
            this.gbx_add_updt_faculty.Size = new System.Drawing.Size(548, 420);
            this.gbx_add_updt_faculty.StateCommon.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.gbx_add_updt_faculty.StateCommon.Border.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(174)))), ((int)(((byte)(244)))));
            this.gbx_add_updt_faculty.StateCommon.Border.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(142)))), ((int)(((byte)(254)))));
            this.gbx_add_updt_faculty.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.gbx_add_updt_faculty.StateCommon.Border.Rounding = 10;
            this.gbx_add_updt_faculty.StateCommon.Border.Width = 5;
            this.gbx_add_updt_faculty.TabIndex = 68;
            this.gbx_add_updt_faculty.Values.Heading = "Add Faculty";
            this.gbx_add_updt_faculty.Visible = false;
            this.gbx_add_updt_faculty.Paint += new System.Windows.Forms.PaintEventHandler(this.gbx_add_updt_faculty_Paint_1);
            // 
            // kryptonPalette1
            // 
            this.kryptonPalette1.BasePaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.ProfessionalSystem;
            this.kryptonPalette1.ButtonStyles.ButtonCustom1.OverrideDefault.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.kryptonPalette1.ButtonStyles.ButtonCustom1.OverrideDefault.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.kryptonPalette1.ButtonStyles.ButtonCustom1.OverrideDefault.Back.ColorAngle = 45F;
            this.kryptonPalette1.ButtonStyles.ButtonCustom1.OverrideDefault.Border.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.kryptonPalette1.ButtonStyles.ButtonCustom1.OverrideDefault.Border.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.kryptonPalette1.ButtonStyles.ButtonCustom1.OverrideDefault.Border.ColorAngle = 45F;
            this.kryptonPalette1.ButtonStyles.ButtonCustom1.OverrideDefault.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonPalette1.ButtonStyles.ButtonCustom1.OverrideDefault.Border.GraphicsHint = ComponentFactory.Krypton.Toolkit.PaletteGraphicsHint.AntiAlias;
            this.kryptonPalette1.ButtonStyles.ButtonCustom1.OverrideDefault.Border.Rounding = 20;
            this.kryptonPalette1.ButtonStyles.ButtonCustom1.OverrideDefault.Border.Width = 1;
            this.kryptonPalette1.ButtonStyles.ButtonCustom1.StateCommon.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.kryptonPalette1.ButtonStyles.ButtonCustom1.StateCommon.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.kryptonPalette1.ButtonStyles.ButtonCustom1.StateCommon.Back.ColorAngle = 45F;
            this.kryptonPalette1.ButtonStyles.ButtonCustom1.StateCommon.Border.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.kryptonPalette1.ButtonStyles.ButtonCustom1.StateCommon.Border.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.kryptonPalette1.ButtonStyles.ButtonCustom1.StateCommon.Border.ColorAngle = 45F;
            this.kryptonPalette1.ButtonStyles.ButtonCustom1.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonPalette1.ButtonStyles.ButtonCustom1.StateCommon.Border.GraphicsHint = ComponentFactory.Krypton.Toolkit.PaletteGraphicsHint.AntiAlias;
            this.kryptonPalette1.ButtonStyles.ButtonCustom1.StateCommon.Border.Rounding = 20;
            this.kryptonPalette1.ButtonStyles.ButtonCustom1.StateCommon.Border.Width = 1;
            this.kryptonPalette1.ButtonStyles.ButtonCustom1.StateCommon.Content.Padding = new System.Windows.Forms.Padding(-3, -10, -3, -10);
            this.kryptonPalette1.ButtonStyles.ButtonCustom1.StateCommon.Content.ShortText.Color1 = System.Drawing.Color.White;
            this.kryptonPalette1.ButtonStyles.ButtonCustom1.StateCommon.Content.ShortText.Color2 = System.Drawing.Color.White;
            this.kryptonPalette1.ButtonStyles.ButtonCustom1.StateCommon.Content.ShortText.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonPalette1.ButtonStyles.ButtonCustom1.StatePressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(165)))), ((int)(((byte)(168)))));
            this.kryptonPalette1.ButtonStyles.ButtonCustom1.StatePressed.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(141)))), ((int)(((byte)(176)))));
            this.kryptonPalette1.ButtonStyles.ButtonCustom1.StatePressed.Back.ColorAngle = 135F;
            this.kryptonPalette1.ButtonStyles.ButtonCustom1.StatePressed.Border.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(165)))), ((int)(((byte)(168)))));
            this.kryptonPalette1.ButtonStyles.ButtonCustom1.StatePressed.Border.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(141)))), ((int)(((byte)(176)))));
            this.kryptonPalette1.ButtonStyles.ButtonCustom1.StatePressed.Border.ColorAngle = 135F;
            this.kryptonPalette1.ButtonStyles.ButtonCustom1.StatePressed.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonPalette1.ButtonStyles.ButtonCustom1.StatePressed.Border.GraphicsHint = ComponentFactory.Krypton.Toolkit.PaletteGraphicsHint.AntiAlias;
            this.kryptonPalette1.ButtonStyles.ButtonCustom1.StatePressed.Border.Rounding = 20;
            this.kryptonPalette1.ButtonStyles.ButtonCustom1.StatePressed.Border.Width = 1;
            this.kryptonPalette1.ButtonStyles.ButtonCustom1.StateTracking.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(182)))), ((int)(((byte)(184)))));
            this.kryptonPalette1.ButtonStyles.ButtonCustom1.StateTracking.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(204)))), ((int)(((byte)(174)))));
            this.kryptonPalette1.ButtonStyles.ButtonCustom1.StateTracking.Back.ColorAngle = 45F;
            this.kryptonPalette1.ButtonStyles.ButtonCustom1.StateTracking.Border.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(182)))), ((int)(((byte)(184)))));
            this.kryptonPalette1.ButtonStyles.ButtonCustom1.StateTracking.Border.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(204)))), ((int)(((byte)(174)))));
            this.kryptonPalette1.ButtonStyles.ButtonCustom1.StateTracking.Border.ColorAngle = 45F;
            this.kryptonPalette1.ButtonStyles.ButtonCustom1.StateTracking.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonPalette1.ButtonStyles.ButtonCustom1.StateTracking.Border.GraphicsHint = ComponentFactory.Krypton.Toolkit.PaletteGraphicsHint.AntiAlias;
            this.kryptonPalette1.ButtonStyles.ButtonCustom1.StateTracking.Border.Rounding = 20;
            this.kryptonPalette1.ButtonStyles.ButtonCustom1.StateTracking.Border.Width = 1;
            this.kryptonPalette1.ButtonStyles.ButtonCustom2.OverrideDefault.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.kryptonPalette1.ButtonStyles.ButtonCustom2.OverrideDefault.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.kryptonPalette1.ButtonStyles.ButtonCustom2.OverrideDefault.Back.ColorAngle = 45F;
            this.kryptonPalette1.ButtonStyles.ButtonCustom2.OverrideDefault.Border.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.kryptonPalette1.ButtonStyles.ButtonCustom2.OverrideDefault.Border.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.kryptonPalette1.ButtonStyles.ButtonCustom2.OverrideDefault.Border.ColorAngle = 45F;
            this.kryptonPalette1.ButtonStyles.ButtonCustom2.OverrideDefault.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonPalette1.ButtonStyles.ButtonCustom2.OverrideDefault.Border.GraphicsHint = ComponentFactory.Krypton.Toolkit.PaletteGraphicsHint.AntiAlias;
            this.kryptonPalette1.ButtonStyles.ButtonCustom2.OverrideDefault.Border.Rounding = 20;
            this.kryptonPalette1.ButtonStyles.ButtonCustom2.OverrideDefault.Border.Width = 1;
            this.kryptonPalette1.ButtonStyles.ButtonCustom2.StateCommon.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.kryptonPalette1.ButtonStyles.ButtonCustom2.StateCommon.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.kryptonPalette1.ButtonStyles.ButtonCustom2.StateCommon.Back.ColorAngle = 45F;
            this.kryptonPalette1.ButtonStyles.ButtonCustom2.StateCommon.Border.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.kryptonPalette1.ButtonStyles.ButtonCustom2.StateCommon.Border.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.kryptonPalette1.ButtonStyles.ButtonCustom2.StateCommon.Border.ColorAngle = 45F;
            this.kryptonPalette1.ButtonStyles.ButtonCustom2.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonPalette1.ButtonStyles.ButtonCustom2.StateCommon.Border.GraphicsHint = ComponentFactory.Krypton.Toolkit.PaletteGraphicsHint.AntiAlias;
            this.kryptonPalette1.ButtonStyles.ButtonCustom2.StateCommon.Border.Rounding = 20;
            this.kryptonPalette1.ButtonStyles.ButtonCustom2.StateCommon.Border.Width = 1;
            this.kryptonPalette1.ButtonStyles.ButtonCustom2.StateCommon.Content.Padding = new System.Windows.Forms.Padding(-1, -3, -1, -3);
            this.kryptonPalette1.ButtonStyles.ButtonCustom2.StateCommon.Content.ShortText.Color1 = System.Drawing.Color.White;
            this.kryptonPalette1.ButtonStyles.ButtonCustom2.StateCommon.Content.ShortText.Color2 = System.Drawing.Color.White;
            this.kryptonPalette1.ButtonStyles.ButtonCustom2.StateCommon.Content.ShortText.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonPalette1.ButtonStyles.ButtonCustom2.StatePressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(100)))), ((int)(((byte)(70)))));
            this.kryptonPalette1.ButtonStyles.ButtonCustom2.StatePressed.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(85)))), ((int)(((byte)(60)))));
            this.kryptonPalette1.ButtonStyles.ButtonCustom2.StatePressed.Back.ColorAngle = 135F;
            this.kryptonPalette1.ButtonStyles.ButtonCustom2.StatePressed.Border.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(100)))), ((int)(((byte)(70)))));
            this.kryptonPalette1.ButtonStyles.ButtonCustom2.StatePressed.Border.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(85)))), ((int)(((byte)(60)))));
            this.kryptonPalette1.ButtonStyles.ButtonCustom2.StatePressed.Border.ColorAngle = 135F;
            this.kryptonPalette1.ButtonStyles.ButtonCustom2.StatePressed.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonPalette1.ButtonStyles.ButtonCustom2.StatePressed.Border.GraphicsHint = ComponentFactory.Krypton.Toolkit.PaletteGraphicsHint.AntiAlias;
            this.kryptonPalette1.ButtonStyles.ButtonCustom2.StatePressed.Border.Rounding = 20;
            this.kryptonPalette1.ButtonStyles.ButtonCustom2.StatePressed.Border.Width = 1;
            this.kryptonPalette1.ButtonStyles.ButtonCustom2.StateTracking.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(112)))), ((int)(((byte)(86)))));
            this.kryptonPalette1.ButtonStyles.ButtonCustom2.StateTracking.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(138)))), ((int)(((byte)(76)))));
            this.kryptonPalette1.ButtonStyles.ButtonCustom2.StateTracking.Back.ColorAngle = 45F;
            this.kryptonPalette1.ButtonStyles.ButtonCustom2.StateTracking.Border.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(112)))), ((int)(((byte)(86)))));
            this.kryptonPalette1.ButtonStyles.ButtonCustom2.StateTracking.Border.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(138)))), ((int)(((byte)(76)))));
            this.kryptonPalette1.ButtonStyles.ButtonCustom2.StateTracking.Border.ColorAngle = 45F;
            this.kryptonPalette1.ButtonStyles.ButtonCustom2.StateTracking.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonPalette1.ButtonStyles.ButtonCustom2.StateTracking.Border.GraphicsHint = ComponentFactory.Krypton.Toolkit.PaletteGraphicsHint.AntiAlias;
            this.kryptonPalette1.ButtonStyles.ButtonCustom2.StateTracking.Border.Rounding = 20;
            this.kryptonPalette1.ButtonStyles.ButtonCustom2.StateTracking.Border.Width = 1;
            this.kryptonPalette1.ButtonStyles.ButtonForm.StateNormal.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.kryptonPalette1.ButtonStyles.ButtonForm.StateNormal.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.kryptonPalette1.ButtonStyles.ButtonForm.StateNormal.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonPalette1.ButtonStyles.ButtonForm.StateNormal.Border.Width = 0;
            this.kryptonPalette1.ButtonStyles.ButtonForm.StatePressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.kryptonPalette1.ButtonStyles.ButtonForm.StatePressed.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.kryptonPalette1.ButtonStyles.ButtonForm.StatePressed.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonPalette1.ButtonStyles.ButtonForm.StatePressed.Border.Width = 0;
            this.kryptonPalette1.ButtonStyles.ButtonForm.StateTracking.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.kryptonPalette1.ButtonStyles.ButtonForm.StateTracking.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.kryptonPalette1.ButtonStyles.ButtonForm.StateTracking.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonPalette1.ButtonStyles.ButtonForm.StateTracking.Border.Width = 0;
            this.kryptonPalette1.FormStyles.FormCommon.StateActive.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.kryptonPalette1.FormStyles.FormCommon.StateActive.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.kryptonPalette1.FormStyles.FormCommon.StateActive.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonPalette1.FormStyles.FormCommon.StateActive.Border.Rounding = 12;
            this.kryptonPalette1.FormStyles.FormCommon.StateCommon.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.kryptonPalette1.FormStyles.FormCommon.StateCommon.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.kryptonPalette1.FormStyles.FormCommon.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonPalette1.FormStyles.FormCommon.StateCommon.Border.GraphicsHint = ComponentFactory.Krypton.Toolkit.PaletteGraphicsHint.None;
            this.kryptonPalette1.FormStyles.FormCommon.StateCommon.Border.Rounding = 12;
            this.kryptonPalette1.HeaderStyles.HeaderCommon.StateCommon.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.kryptonPalette1.HeaderStyles.HeaderCommon.StateCommon.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.kryptonPalette1.HeaderStyles.HeaderCommon.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonPalette1.HeaderStyles.HeaderCommon.StateCommon.Border.Rounding = 10;
            this.kryptonPalette1.HeaderStyles.HeaderCommon.StateCommon.ButtonEdgeInset = 10;
            this.kryptonPalette1.HeaderStyles.HeaderCustom1.StateCommon.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.kryptonPalette1.HeaderStyles.HeaderCustom1.StateCommon.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.kryptonPalette1.HeaderStyles.HeaderCustom1.StateCommon.ButtonEdgeInset = 10;
            this.kryptonPalette1.HeaderStyles.HeaderForm.StateCommon.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.kryptonPalette1.HeaderStyles.HeaderForm.StateCommon.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.kryptonPalette1.HeaderStyles.HeaderForm.StateCommon.ButtonEdgeInset = 10;
            this.kryptonPalette1.HeaderStyles.HeaderForm.StateCommon.Content.Padding = new System.Windows.Forms.Padding(10, -1, -1, -1);
            this.kryptonPalette1.HeaderStyles.HeaderForm.StateNormal.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.kryptonPalette1.HeaderStyles.HeaderForm.StateNormal.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            // 
            // lbl_teaching_hours
            // 
            this.lbl_teaching_hours.AutoSize = true;
            this.lbl_teaching_hours.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.lbl_teaching_hours.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_teaching_hours.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbl_teaching_hours.Location = new System.Drawing.Point(10, 133);
            this.lbl_teaching_hours.Name = "lbl_teaching_hours";
            this.lbl_teaching_hours.Size = new System.Drawing.Size(117, 20);
            this.lbl_teaching_hours.TabIndex = 45;
            this.lbl_teaching_hours.Text = "TeachingHours:";
            // 
            // txt_teaching_hours
            // 
            this.txt_teaching_hours.Location = new System.Drawing.Point(42, 146);
            this.txt_teaching_hours.Name = "txt_teaching_hours";
            this.txt_teaching_hours.Size = new System.Drawing.Size(283, 33);
            this.txt_teaching_hours.StateCommon.Back.Color1 = System.Drawing.Color.White;
            this.txt_teaching_hours.StateCommon.Border.Color1 = System.Drawing.Color.Silver;
            this.txt_teaching_hours.StateCommon.Border.Color2 = System.Drawing.Color.Silver;
            this.txt_teaching_hours.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.txt_teaching_hours.StateCommon.Border.GraphicsHint = ComponentFactory.Krypton.Toolkit.PaletteGraphicsHint.AntiAlias;
            this.txt_teaching_hours.StateCommon.Border.Rounding = 20;
            this.txt_teaching_hours.StateCommon.Border.Width = 1;
            this.txt_teaching_hours.StateCommon.Content.Color1 = System.Drawing.Color.Gray;
            this.txt_teaching_hours.StateCommon.Content.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_teaching_hours.StateCommon.Content.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.txt_teaching_hours.TabIndex = 44;
            this.txt_teaching_hours.Text = "Enter Teaching Hours";
            this.txt_teaching_hours.Enter += new System.EventHandler(this.txt_teaching_hours_Enter);
            this.txt_teaching_hours.Leave += new System.EventHandler(this.txt_teaching_hours_Leave);
            // 
            // lbl_contact
            // 
            this.lbl_contact.AutoSize = true;
            this.lbl_contact.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.lbl_contact.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_contact.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbl_contact.Location = new System.Drawing.Point(10, 73);
            this.lbl_contact.Name = "lbl_contact";
            this.lbl_contact.Size = new System.Drawing.Size(67, 20);
            this.lbl_contact.TabIndex = 41;
            this.lbl_contact.Text = "Contact:";
            // 
            // txt_contact
            // 
            this.txt_contact.Location = new System.Drawing.Point(42, 86);
            this.txt_contact.Name = "txt_contact";
            this.txt_contact.Size = new System.Drawing.Size(283, 33);
            this.txt_contact.StateCommon.Back.Color1 = System.Drawing.Color.White;
            this.txt_contact.StateCommon.Border.Color1 = System.Drawing.Color.Silver;
            this.txt_contact.StateCommon.Border.Color2 = System.Drawing.Color.Silver;
            this.txt_contact.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.txt_contact.StateCommon.Border.GraphicsHint = ComponentFactory.Krypton.Toolkit.PaletteGraphicsHint.AntiAlias;
            this.txt_contact.StateCommon.Border.Rounding = 20;
            this.txt_contact.StateCommon.Border.Width = 1;
            this.txt_contact.StateCommon.Content.Color1 = System.Drawing.Color.Gray;
            this.txt_contact.StateCommon.Content.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_contact.StateCommon.Content.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.txt_contact.TabIndex = 40;
            this.txt_contact.Text = "Enter ContactNo.";
            this.txt_contact.Enter += new System.EventHandler(this.txt_contact_Enter);
            this.txt_contact.Leave += new System.EventHandler(this.txt_contact_Leave);
            // 
            // lbl_designations
            // 
            this.lbl_designations.AutoSize = true;
            this.lbl_designations.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.lbl_designations.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_designations.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbl_designations.Location = new System.Drawing.Point(10, 254);
            this.lbl_designations.Name = "lbl_designations";
            this.lbl_designations.Size = new System.Drawing.Size(97, 20);
            this.lbl_designations.TabIndex = 30;
            this.lbl_designations.Text = "Designation:";
            // 
            // txt_password
            // 
            this.txt_password.Location = new System.Drawing.Point(355, 146);
            this.txt_password.Name = "txt_password";
            this.txt_password.Palette = this.kryptonPalette1;
            this.txt_password.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.Custom;
            this.txt_password.Size = new System.Drawing.Size(283, 33);
            this.txt_password.StateCommon.Back.Color1 = System.Drawing.Color.White;
            this.txt_password.StateCommon.Border.Color1 = System.Drawing.Color.Silver;
            this.txt_password.StateCommon.Border.Color2 = System.Drawing.Color.Silver;
            this.txt_password.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.txt_password.StateCommon.Border.GraphicsHint = ComponentFactory.Krypton.Toolkit.PaletteGraphicsHint.AntiAlias;
            this.txt_password.StateCommon.Border.Rounding = 20;
            this.txt_password.StateCommon.Border.Width = 1;
            this.txt_password.StateCommon.Content.Color1 = System.Drawing.Color.Gray;
            this.txt_password.StateCommon.Content.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_password.StateCommon.Content.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.txt_password.TabIndex = 38;
            this.txt_password.Text = "Enter Password";
            this.txt_password.TextChanged += new System.EventHandler(this.kryptonTextBox2_TextChanged);
            this.txt_password.Enter += new System.EventHandler(this.txt_password_Enter);
            this.txt_password.Leave += new System.EventHandler(this.txt_password_Leave);
            // 
            // lbl_name
            // 
            this.lbl_name.AutoSize = true;
            this.lbl_name.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.lbl_name.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_name.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbl_name.Location = new System.Drawing.Point(10, 13);
            this.lbl_name.Name = "lbl_name";
            this.lbl_name.Size = new System.Drawing.Size(55, 20);
            this.lbl_name.TabIndex = 37;
            this.lbl_name.Text = "Name:";
            // 
            // txt_name
            // 
            this.txt_name.Location = new System.Drawing.Point(42, 26);
            this.txt_name.Name = "txt_name";
            this.txt_name.Size = new System.Drawing.Size(283, 33);
            this.txt_name.StateCommon.Back.Color1 = System.Drawing.Color.White;
            this.txt_name.StateCommon.Border.Color1 = System.Drawing.Color.Silver;
            this.txt_name.StateCommon.Border.Color2 = System.Drawing.Color.Silver;
            this.txt_name.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.txt_name.StateCommon.Border.GraphicsHint = ComponentFactory.Krypton.Toolkit.PaletteGraphicsHint.AntiAlias;
            this.txt_name.StateCommon.Border.Rounding = 20;
            this.txt_name.StateCommon.Border.Width = 1;
            this.txt_name.StateCommon.Content.Color1 = System.Drawing.Color.Gray;
            this.txt_name.StateCommon.Content.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_name.StateCommon.Content.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.txt_name.TabIndex = 36;
            this.txt_name.Text = "Enter Name";
            this.txt_name.Enter += new System.EventHandler(this.txt_name_Enter);
            this.txt_name.Leave += new System.EventHandler(this.txt_name_Leave);
            // 
            // cmbx_designations
            // 
            this.cmbx_designations.DropDownWidth = 123;
            this.cmbx_designations.Location = new System.Drawing.Point(73, 275);
            this.cmbx_designations.Name = "cmbx_designations";
            this.cmbx_designations.Palette = this.kryptonPalette1;
            this.cmbx_designations.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.Custom;
            this.cmbx_designations.Size = new System.Drawing.Size(123, 29);
            this.cmbx_designations.StateCommon.ComboBox.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.cmbx_designations.StateCommon.ComboBox.Border.Color1 = System.Drawing.Color.Silver;
            this.cmbx_designations.StateCommon.ComboBox.Border.Color2 = System.Drawing.Color.Silver;
            this.cmbx_designations.StateCommon.ComboBox.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.cmbx_designations.StateCommon.ComboBox.Border.GraphicsHint = ComponentFactory.Krypton.Toolkit.PaletteGraphicsHint.AntiAlias;
            this.cmbx_designations.StateCommon.ComboBox.Border.Rounding = 10;
            this.cmbx_designations.StateCommon.ComboBox.Border.Width = 1;
            this.cmbx_designations.StateCommon.ComboBox.Content.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.cmbx_designations.StateCommon.ComboBox.Content.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbx_designations.StateCommon.DropBack.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.cmbx_designations.StateCommon.DropBack.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.cmbx_designations.StateCommon.Item.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.cmbx_designations.StateCommon.Item.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.cmbx_designations.StateCommon.Item.Content.ShortText.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.cmbx_designations.StateCommon.Item.Content.ShortText.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.cmbx_designations.StateTracking.Item.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(174)))), ((int)(((byte)(244)))));
            this.cmbx_designations.StateTracking.Item.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(142)))), ((int)(((byte)(254)))));
            this.cmbx_designations.StateTracking.Item.Back.ColorAngle = 45F;
            this.cmbx_designations.StateTracking.Item.Content.ShortText.Color1 = System.Drawing.Color.Black;
            this.cmbx_designations.StateTracking.Item.Content.ShortText.Color2 = System.Drawing.Color.Black;
            this.cmbx_designations.TabIndex = 35;
            this.cmbx_designations.Text = "kryptonComboBox1";
            // 
            // txt_email
            // 
            this.txt_email.Location = new System.Drawing.Point(355, 26);
            this.txt_email.Name = "txt_email";
            this.txt_email.Palette = this.kryptonPalette1;
            this.txt_email.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.Custom;
            this.txt_email.Size = new System.Drawing.Size(283, 33);
            this.txt_email.StateCommon.Back.Color1 = System.Drawing.Color.White;
            this.txt_email.StateCommon.Border.Color1 = System.Drawing.Color.Silver;
            this.txt_email.StateCommon.Border.Color2 = System.Drawing.Color.Silver;
            this.txt_email.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.txt_email.StateCommon.Border.GraphicsHint = ComponentFactory.Krypton.Toolkit.PaletteGraphicsHint.AntiAlias;
            this.txt_email.StateCommon.Border.Rounding = 20;
            this.txt_email.StateCommon.Border.Width = 1;
            this.txt_email.StateCommon.Content.Color1 = System.Drawing.Color.Gray;
            this.txt_email.StateCommon.Content.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_email.StateCommon.Content.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.txt_email.TabIndex = 33;
            this.txt_email.Text = "Enter Email";
            this.txt_email.Enter += new System.EventHandler(this.txt_email_Enter);
            this.txt_email.Leave += new System.EventHandler(this.txt_email_Leave);
            // 
            // btn_back
            // 
            this.btn_back.Location = new System.Drawing.Point(202, 332);
            this.btn_back.Name = "btn_back";
            this.btn_back.OverrideDefault.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.btn_back.OverrideDefault.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.btn_back.OverrideDefault.Back.ColorAngle = 45F;
            this.btn_back.OverrideDefault.Border.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(142)))), ((int)(((byte)(254)))));
            this.btn_back.OverrideDefault.Border.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(142)))), ((int)(((byte)(254)))));
            this.btn_back.OverrideDefault.Border.ColorAngle = 45F;
            this.btn_back.OverrideDefault.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.btn_back.OverrideDefault.Border.GraphicsHint = ComponentFactory.Krypton.Toolkit.PaletteGraphicsHint.AntiAlias;
            this.btn_back.OverrideDefault.Border.Rounding = 20;
            this.btn_back.OverrideDefault.Border.Width = 1;
            this.btn_back.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.ProfessionalSystem;
            this.btn_back.Size = new System.Drawing.Size(120, 40);
            this.btn_back.StateCommon.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.btn_back.StateCommon.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.btn_back.StateCommon.Back.ColorAngle = 45F;
            this.btn_back.StateCommon.Border.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(174)))), ((int)(((byte)(244)))));
            this.btn_back.StateCommon.Border.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(142)))), ((int)(((byte)(254)))));
            this.btn_back.StateCommon.Border.ColorAngle = 45F;
            this.btn_back.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.btn_back.StateCommon.Border.GraphicsHint = ComponentFactory.Krypton.Toolkit.PaletteGraphicsHint.AntiAlias;
            this.btn_back.StateCommon.Border.Rounding = 20;
            this.btn_back.StateCommon.Border.Width = 1;
            this.btn_back.StateCommon.Content.ShortText.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(152)))), ((int)(((byte)(254)))));
            this.btn_back.StateCommon.Content.ShortText.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_back.StatePressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(145)))), ((int)(((byte)(198)))));
            this.btn_back.StatePressed.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(121)))), ((int)(((byte)(206)))));
            this.btn_back.StatePressed.Back.ColorAngle = 135F;
            this.btn_back.StatePressed.Border.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(145)))), ((int)(((byte)(198)))));
            this.btn_back.StatePressed.Border.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(121)))), ((int)(((byte)(206)))));
            this.btn_back.StatePressed.Border.ColorAngle = 135F;
            this.btn_back.StatePressed.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.btn_back.StatePressed.Border.Rounding = 20;
            this.btn_back.StatePressed.Border.Width = 1;
            this.btn_back.StateTracking.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(142)))), ((int)(((byte)(254)))));
            this.btn_back.StateTracking.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(174)))), ((int)(((byte)(244)))));
            this.btn_back.StateTracking.Back.ColorAngle = 45F;
            this.btn_back.StateTracking.Border.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(174)))), ((int)(((byte)(244)))));
            this.btn_back.StateTracking.Border.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(142)))), ((int)(((byte)(254)))));
            this.btn_back.StateTracking.Border.ColorAngle = 45F;
            this.btn_back.StateTracking.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.btn_back.StateTracking.Border.GraphicsHint = ComponentFactory.Krypton.Toolkit.PaletteGraphicsHint.AntiAlias;
            this.btn_back.StateTracking.Border.Rounding = 20;
            this.btn_back.StateTracking.Border.Width = 1;
            this.btn_back.StateTracking.Content.ShortText.Color1 = System.Drawing.Color.White;
            this.btn_back.TabIndex = 32;
            this.btn_back.Values.Text = "Back";
            this.btn_back.Click += new System.EventHandler(this.btn_back_Click);
            // 
            // btn_add_updt
            // 
            this.btn_add_updt.Location = new System.Drawing.Point(76, 332);
            this.btn_add_updt.Name = "btn_add_updt";
            this.btn_add_updt.OverrideDefault.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(174)))), ((int)(((byte)(244)))));
            this.btn_add_updt.OverrideDefault.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(142)))), ((int)(((byte)(254)))));
            this.btn_add_updt.OverrideDefault.Back.ColorAngle = 45F;
            this.btn_add_updt.OverrideDefault.Border.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(174)))), ((int)(((byte)(244)))));
            this.btn_add_updt.OverrideDefault.Border.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(142)))), ((int)(((byte)(254)))));
            this.btn_add_updt.OverrideDefault.Border.ColorAngle = 45F;
            this.btn_add_updt.OverrideDefault.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.btn_add_updt.OverrideDefault.Border.GraphicsHint = ComponentFactory.Krypton.Toolkit.PaletteGraphicsHint.AntiAlias;
            this.btn_add_updt.OverrideDefault.Border.Rounding = 20;
            this.btn_add_updt.OverrideDefault.Border.Width = 1;
            this.btn_add_updt.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.ProfessionalSystem;
            this.btn_add_updt.Size = new System.Drawing.Size(120, 40);
            this.btn_add_updt.StateCommon.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(174)))), ((int)(((byte)(244)))));
            this.btn_add_updt.StateCommon.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(142)))), ((int)(((byte)(254)))));
            this.btn_add_updt.StateCommon.Back.ColorAngle = 45F;
            this.btn_add_updt.StateCommon.Border.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(174)))), ((int)(((byte)(244)))));
            this.btn_add_updt.StateCommon.Border.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(142)))), ((int)(((byte)(254)))));
            this.btn_add_updt.StateCommon.Border.ColorAngle = 45F;
            this.btn_add_updt.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.btn_add_updt.StateCommon.Border.GraphicsHint = ComponentFactory.Krypton.Toolkit.PaletteGraphicsHint.AntiAlias;
            this.btn_add_updt.StateCommon.Border.Rounding = 20;
            this.btn_add_updt.StateCommon.Border.Width = 1;
            this.btn_add_updt.StateCommon.Content.ShortText.Color1 = System.Drawing.Color.White;
            this.btn_add_updt.StateCommon.Content.ShortText.Color2 = System.Drawing.Color.White;
            this.btn_add_updt.StateCommon.Content.ShortText.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_add_updt.StatePressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(145)))), ((int)(((byte)(198)))));
            this.btn_add_updt.StatePressed.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(121)))), ((int)(((byte)(206)))));
            this.btn_add_updt.StatePressed.Back.ColorAngle = 135F;
            this.btn_add_updt.StatePressed.Border.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(145)))), ((int)(((byte)(198)))));
            this.btn_add_updt.StatePressed.Border.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(121)))), ((int)(((byte)(206)))));
            this.btn_add_updt.StatePressed.Border.ColorAngle = 135F;
            this.btn_add_updt.StatePressed.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.btn_add_updt.StatePressed.Border.Rounding = 20;
            this.btn_add_updt.StatePressed.Border.Width = 1;
            this.btn_add_updt.StateTracking.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(142)))), ((int)(((byte)(254)))));
            this.btn_add_updt.StateTracking.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(174)))), ((int)(((byte)(244)))));
            this.btn_add_updt.StateTracking.Back.ColorAngle = 45F;
            this.btn_add_updt.StateTracking.Border.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(174)))), ((int)(((byte)(244)))));
            this.btn_add_updt.StateTracking.Border.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(142)))), ((int)(((byte)(254)))));
            this.btn_add_updt.StateTracking.Border.ColorAngle = 45F;
            this.btn_add_updt.StateTracking.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.btn_add_updt.StateTracking.Border.GraphicsHint = ComponentFactory.Krypton.Toolkit.PaletteGraphicsHint.AntiAlias;
            this.btn_add_updt.StateTracking.Border.Rounding = 20;
            this.btn_add_updt.StateTracking.Border.Width = 1;
            this.btn_add_updt.TabIndex = 31;
            this.btn_add_updt.Values.Text = "Add";
            this.btn_add_updt.Click += new System.EventHandler(this.btn_add_updt_Click);
            // 
            // lbl_research_area
            // 
            this.lbl_research_area.AutoSize = true;
            this.lbl_research_area.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.lbl_research_area.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_research_area.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbl_research_area.Location = new System.Drawing.Point(9, 194);
            this.lbl_research_area.Name = "lbl_research_area";
            this.lbl_research_area.Size = new System.Drawing.Size(109, 20);
            this.lbl_research_area.TabIndex = 28;
            this.lbl_research_area.Text = "ResearchArea:";
            // 
            // lbl_user_name
            // 
            this.lbl_user_name.AutoSize = true;
            this.lbl_user_name.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.lbl_user_name.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_user_name.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbl_user_name.Location = new System.Drawing.Point(323, 73);
            this.lbl_user_name.Name = "lbl_user_name";
            this.lbl_user_name.Size = new System.Drawing.Size(87, 20);
            this.lbl_user_name.TabIndex = 27;
            this.lbl_user_name.Text = "UserName:";
            // 
            // txt_research_area
            // 
            this.txt_research_area.Location = new System.Drawing.Point(42, 206);
            this.txt_research_area.Name = "txt_research_area";
            this.txt_research_area.Palette = this.kryptonPalette1;
            this.txt_research_area.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.Custom;
            this.txt_research_area.Size = new System.Drawing.Size(283, 33);
            this.txt_research_area.StateCommon.Back.Color1 = System.Drawing.Color.White;
            this.txt_research_area.StateCommon.Border.Color1 = System.Drawing.Color.Silver;
            this.txt_research_area.StateCommon.Border.Color2 = System.Drawing.Color.Silver;
            this.txt_research_area.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.txt_research_area.StateCommon.Border.GraphicsHint = ComponentFactory.Krypton.Toolkit.PaletteGraphicsHint.AntiAlias;
            this.txt_research_area.StateCommon.Border.Rounding = 20;
            this.txt_research_area.StateCommon.Border.Width = 1;
            this.txt_research_area.StateCommon.Content.Color1 = System.Drawing.Color.Gray;
            this.txt_research_area.StateCommon.Content.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_research_area.StateCommon.Content.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.txt_research_area.TabIndex = 23;
            this.txt_research_area.Text = "Enter Research Area";
            this.txt_research_area.Enter += new System.EventHandler(this.txt_research_area_Enter);
            this.txt_research_area.Leave += new System.EventHandler(this.txt_research_area_Leave);
            // 
            // txt_user_name
            // 
            this.txt_user_name.Location = new System.Drawing.Point(355, 86);
            this.txt_user_name.Name = "txt_user_name";
            this.txt_user_name.Size = new System.Drawing.Size(283, 33);
            this.txt_user_name.StateCommon.Back.Color1 = System.Drawing.Color.White;
            this.txt_user_name.StateCommon.Border.Color1 = System.Drawing.Color.Silver;
            this.txt_user_name.StateCommon.Border.Color2 = System.Drawing.Color.Silver;
            this.txt_user_name.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.txt_user_name.StateCommon.Border.GraphicsHint = ComponentFactory.Krypton.Toolkit.PaletteGraphicsHint.AntiAlias;
            this.txt_user_name.StateCommon.Border.Rounding = 20;
            this.txt_user_name.StateCommon.Border.Width = 1;
            this.txt_user_name.StateCommon.Content.Color1 = System.Drawing.Color.Gray;
            this.txt_user_name.StateCommon.Content.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_user_name.StateCommon.Content.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.txt_user_name.TabIndex = 22;
            this.txt_user_name.Text = "Enter UserName";
            this.txt_user_name.Enter += new System.EventHandler(this.txt_user_name_Enter);
            this.txt_user_name.Leave += new System.EventHandler(this.txt_user_name_Leave);
            // 
            // pnl_sort_direction
            // 
            this.pnl_sort_direction.Controls.Add(this.rdo_desc);
            this.pnl_sort_direction.Controls.Add(this.rdo_asc);
            this.pnl_sort_direction.Location = new System.Drawing.Point(12, 214);
            this.pnl_sort_direction.Name = "pnl_sort_direction";
            this.pnl_sort_direction.Size = new System.Drawing.Size(40, 64);
            this.pnl_sort_direction.TabIndex = 66;
            // 
            // rdo_desc
            // 
            this.rdo_desc.Location = new System.Drawing.Point(3, 28);
            this.rdo_desc.Name = "rdo_desc";
            this.rdo_desc.Palette = this.kryptonPalette1;
            this.rdo_desc.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.Custom;
            this.rdo_desc.Size = new System.Drawing.Size(37, 35);
            this.rdo_desc.StateCommon.ShortText.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.rdo_desc.StateCommon.ShortText.Font = new System.Drawing.Font("Segoe UI Symbol", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdo_desc.StateDisabled.ShortText.Color1 = System.Drawing.Color.LightGray;
            this.rdo_desc.TabIndex = 41;
            this.rdo_desc.Values.Text = "↓";
            // 
            // rdo_asc
            // 
            this.rdo_asc.Location = new System.Drawing.Point(3, 3);
            this.rdo_asc.Name = "rdo_asc";
            this.rdo_asc.Palette = this.kryptonPalette1;
            this.rdo_asc.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.Custom;
            this.rdo_asc.Size = new System.Drawing.Size(37, 35);
            this.rdo_asc.StateCommon.ShortText.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.rdo_asc.StateCommon.ShortText.Font = new System.Drawing.Font("Segoe UI Symbol", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdo_asc.StateDisabled.ShortText.Color1 = System.Drawing.Color.LightGray;
            this.rdo_asc.TabIndex = 36;
            this.rdo_asc.Values.Text = "↑";
            // 
            // pnl_sortby
            // 
            this.pnl_sortby.Controls.Add(this.rdo_sort_name);
            this.pnl_sortby.Controls.Add(this.rdo_sort_id);
            this.pnl_sortby.Controls.Add(this.rdo_sort_email);
            this.pnl_sortby.Location = new System.Drawing.Point(12, 103);
            this.pnl_sortby.Name = "pnl_sortby";
            this.pnl_sortby.Size = new System.Drawing.Size(96, 74);
            this.pnl_sortby.TabIndex = 65;
            // 
            // rdo_sort_name
            // 
            this.rdo_sort_name.Location = new System.Drawing.Point(3, 25);
            this.rdo_sort_name.Name = "rdo_sort_name";
            this.rdo_sort_name.Palette = this.kryptonPalette1;
            this.rdo_sort_name.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.Custom;
            this.rdo_sort_name.Size = new System.Drawing.Size(56, 22);
            this.rdo_sort_name.StateCommon.ShortText.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.rdo_sort_name.TabIndex = 39;
            this.rdo_sort_name.Values.Text = "Name";
            // 
            // rdo_sort_id
            // 
            this.rdo_sort_id.Location = new System.Drawing.Point(3, 5);
            this.rdo_sort_id.Name = "rdo_sort_id";
            this.rdo_sort_id.Palette = this.kryptonPalette1;
            this.rdo_sort_id.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.Custom;
            this.rdo_sort_id.Size = new System.Drawing.Size(77, 22);
            this.rdo_sort_id.StateCommon.ShortText.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.rdo_sort_id.TabIndex = 38;
            this.rdo_sort_id.Values.Text = "Faculty ID";
            // 
            // rdo_sort_email
            // 
            this.rdo_sort_email.Location = new System.Drawing.Point(3, 45);
            this.rdo_sort_email.Name = "rdo_sort_email";
            this.rdo_sort_email.Palette = this.kryptonPalette1;
            this.rdo_sort_email.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.Custom;
            this.rdo_sort_email.Size = new System.Drawing.Size(53, 22);
            this.rdo_sort_email.StateCommon.ShortText.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.rdo_sort_email.TabIndex = 37;
            this.rdo_sort_email.Values.Text = "Email";
            // 
            // btn_add
            // 
            this.btn_add.Location = new System.Drawing.Point(160, 14);
            this.btn_add.Name = "btn_add";
            this.btn_add.OverrideDefault.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(174)))), ((int)(((byte)(244)))));
            this.btn_add.OverrideDefault.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(142)))), ((int)(((byte)(254)))));
            this.btn_add.OverrideDefault.Back.ColorAngle = 45F;
            this.btn_add.OverrideDefault.Border.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(174)))), ((int)(((byte)(244)))));
            this.btn_add.OverrideDefault.Border.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(142)))), ((int)(((byte)(254)))));
            this.btn_add.OverrideDefault.Border.ColorAngle = 45F;
            this.btn_add.OverrideDefault.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.btn_add.OverrideDefault.Border.GraphicsHint = ComponentFactory.Krypton.Toolkit.PaletteGraphicsHint.AntiAlias;
            this.btn_add.OverrideDefault.Border.Rounding = 20;
            this.btn_add.OverrideDefault.Border.Width = 1;
            this.btn_add.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.ProfessionalSystem;
            this.btn_add.Size = new System.Drawing.Size(43, 43);
            this.btn_add.StateCommon.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(174)))), ((int)(((byte)(244)))));
            this.btn_add.StateCommon.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(142)))), ((int)(((byte)(254)))));
            this.btn_add.StateCommon.Back.ColorAngle = 45F;
            this.btn_add.StateCommon.Border.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(174)))), ((int)(((byte)(244)))));
            this.btn_add.StateCommon.Border.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(142)))), ((int)(((byte)(254)))));
            this.btn_add.StateCommon.Border.ColorAngle = 45F;
            this.btn_add.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.btn_add.StateCommon.Border.GraphicsHint = ComponentFactory.Krypton.Toolkit.PaletteGraphicsHint.AntiAlias;
            this.btn_add.StateCommon.Border.Rounding = 20;
            this.btn_add.StateCommon.Border.Width = 1;
            this.btn_add.StateCommon.Content.Padding = new System.Windows.Forms.Padding(-8, -8, -10, -10);
            this.btn_add.StateCommon.Content.ShortText.Color1 = System.Drawing.Color.White;
            this.btn_add.StateCommon.Content.ShortText.Color2 = System.Drawing.Color.White;
            this.btn_add.StateCommon.Content.ShortText.Font = new System.Drawing.Font("Calibri", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_add.StatePressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(145)))), ((int)(((byte)(198)))));
            this.btn_add.StatePressed.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(121)))), ((int)(((byte)(206)))));
            this.btn_add.StatePressed.Back.ColorAngle = 135F;
            this.btn_add.StatePressed.Border.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(145)))), ((int)(((byte)(198)))));
            this.btn_add.StatePressed.Border.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(121)))), ((int)(((byte)(206)))));
            this.btn_add.StatePressed.Border.ColorAngle = 135F;
            this.btn_add.StatePressed.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.btn_add.StatePressed.Border.Rounding = 20;
            this.btn_add.StatePressed.Border.Width = 1;
            this.btn_add.StateTracking.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(142)))), ((int)(((byte)(254)))));
            this.btn_add.StateTracking.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(174)))), ((int)(((byte)(244)))));
            this.btn_add.StateTracking.Back.ColorAngle = 45F;
            this.btn_add.StateTracking.Border.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(174)))), ((int)(((byte)(244)))));
            this.btn_add.StateTracking.Border.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(142)))), ((int)(((byte)(254)))));
            this.btn_add.StateTracking.Border.ColorAngle = 45F;
            this.btn_add.StateTracking.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.btn_add.StateTracking.Border.GraphicsHint = ComponentFactory.Krypton.Toolkit.PaletteGraphicsHint.AntiAlias;
            this.btn_add.StateTracking.Border.Rounding = 20;
            this.btn_add.StateTracking.Border.Width = 1;
            this.btn_add.TabIndex = 59;
            this.btn_add.Values.Text = "+";
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // txt_search_facultys
            // 
            this.txt_search_facultys.Location = new System.Drawing.Point(437, 14);
            this.txt_search_facultys.Name = "txt_search_facultys";
            this.txt_search_facultys.Size = new System.Drawing.Size(263, 33);
            this.txt_search_facultys.StateCommon.Back.Color1 = System.Drawing.Color.White;
            this.txt_search_facultys.StateCommon.Border.Color1 = System.Drawing.Color.Silver;
            this.txt_search_facultys.StateCommon.Border.Color2 = System.Drawing.Color.Silver;
            this.txt_search_facultys.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.txt_search_facultys.StateCommon.Border.GraphicsHint = ComponentFactory.Krypton.Toolkit.PaletteGraphicsHint.AntiAlias;
            this.txt_search_facultys.StateCommon.Border.Rounding = 20;
            this.txt_search_facultys.StateCommon.Border.Width = 1;
            this.txt_search_facultys.StateCommon.Content.Color1 = System.Drawing.Color.Gray;
            this.txt_search_facultys.StateCommon.Content.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_search_facultys.StateCommon.Content.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.txt_search_facultys.TabIndex = 57;
            this.txt_search_facultys.Text = "Search faculty";
            this.txt_search_facultys.Enter += new System.EventHandler(this.txt_search_facultys_Enter);
            this.txt_search_facultys.Leave += new System.EventHandler(this.txt_search_facultys_Leave);
            // 
            // btn_dashboard
            // 
            this.btn_dashboard.Location = new System.Drawing.Point(15, 14);
            this.btn_dashboard.Name = "btn_dashboard";
            this.btn_dashboard.OverrideDefault.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.btn_dashboard.OverrideDefault.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.btn_dashboard.OverrideDefault.Back.ColorAngle = 45F;
            this.btn_dashboard.OverrideDefault.Border.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(142)))), ((int)(((byte)(254)))));
            this.btn_dashboard.OverrideDefault.Border.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(142)))), ((int)(((byte)(254)))));
            this.btn_dashboard.OverrideDefault.Border.ColorAngle = 45F;
            this.btn_dashboard.OverrideDefault.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.btn_dashboard.OverrideDefault.Border.GraphicsHint = ComponentFactory.Krypton.Toolkit.PaletteGraphicsHint.AntiAlias;
            this.btn_dashboard.OverrideDefault.Border.Rounding = 20;
            this.btn_dashboard.OverrideDefault.Border.Width = 1;
            this.btn_dashboard.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.ProfessionalSystem;
            this.btn_dashboard.Size = new System.Drawing.Size(139, 43);
            this.btn_dashboard.StateCommon.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.btn_dashboard.StateCommon.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.btn_dashboard.StateCommon.Back.ColorAngle = 45F;
            this.btn_dashboard.StateCommon.Border.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(174)))), ((int)(((byte)(244)))));
            this.btn_dashboard.StateCommon.Border.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(142)))), ((int)(((byte)(254)))));
            this.btn_dashboard.StateCommon.Border.ColorAngle = 45F;
            this.btn_dashboard.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.btn_dashboard.StateCommon.Border.GraphicsHint = ComponentFactory.Krypton.Toolkit.PaletteGraphicsHint.AntiAlias;
            this.btn_dashboard.StateCommon.Border.Rounding = 20;
            this.btn_dashboard.StateCommon.Border.Width = 1;
            this.btn_dashboard.StateCommon.Content.ShortText.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(152)))), ((int)(((byte)(254)))));
            this.btn_dashboard.StateCommon.Content.ShortText.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_dashboard.StatePressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(145)))), ((int)(((byte)(198)))));
            this.btn_dashboard.StatePressed.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(121)))), ((int)(((byte)(206)))));
            this.btn_dashboard.StatePressed.Back.ColorAngle = 135F;
            this.btn_dashboard.StatePressed.Border.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(145)))), ((int)(((byte)(198)))));
            this.btn_dashboard.StatePressed.Border.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(121)))), ((int)(((byte)(206)))));
            this.btn_dashboard.StatePressed.Border.ColorAngle = 135F;
            this.btn_dashboard.StatePressed.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.btn_dashboard.StatePressed.Border.Rounding = 20;
            this.btn_dashboard.StatePressed.Border.Width = 1;
            this.btn_dashboard.StateTracking.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(142)))), ((int)(((byte)(254)))));
            this.btn_dashboard.StateTracking.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(174)))), ((int)(((byte)(244)))));
            this.btn_dashboard.StateTracking.Back.ColorAngle = 45F;
            this.btn_dashboard.StateTracking.Border.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(174)))), ((int)(((byte)(244)))));
            this.btn_dashboard.StateTracking.Border.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(142)))), ((int)(((byte)(254)))));
            this.btn_dashboard.StateTracking.Border.ColorAngle = 45F;
            this.btn_dashboard.StateTracking.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.btn_dashboard.StateTracking.Border.GraphicsHint = ComponentFactory.Krypton.Toolkit.PaletteGraphicsHint.AntiAlias;
            this.btn_dashboard.StateTracking.Border.Rounding = 20;
            this.btn_dashboard.StateTracking.Border.Width = 1;
            this.btn_dashboard.StateTracking.Content.ShortText.Color1 = System.Drawing.Color.White;
            this.btn_dashboard.TabIndex = 56;
            this.btn_dashboard.Values.Text = "Dashboard";
            this.btn_dashboard.Click += new System.EventHandler(this.btn_dashboard_Click);
            // 
            // btn_search
            // 
            this.btn_search.Location = new System.Drawing.Point(704, 14);
            this.btn_search.Name = "btn_search";
            this.btn_search.OverrideDefault.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(174)))), ((int)(((byte)(244)))));
            this.btn_search.OverrideDefault.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(142)))), ((int)(((byte)(254)))));
            this.btn_search.OverrideDefault.Back.ColorAngle = 45F;
            this.btn_search.OverrideDefault.Border.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(174)))), ((int)(((byte)(244)))));
            this.btn_search.OverrideDefault.Border.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(142)))), ((int)(((byte)(254)))));
            this.btn_search.OverrideDefault.Border.ColorAngle = 45F;
            this.btn_search.OverrideDefault.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.btn_search.OverrideDefault.Border.GraphicsHint = ComponentFactory.Krypton.Toolkit.PaletteGraphicsHint.AntiAlias;
            this.btn_search.OverrideDefault.Border.Rounding = 20;
            this.btn_search.OverrideDefault.Border.Width = 1;
            this.btn_search.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.ProfessionalSystem;
            this.btn_search.Size = new System.Drawing.Size(83, 33);
            this.btn_search.StateCommon.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(174)))), ((int)(((byte)(244)))));
            this.btn_search.StateCommon.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(142)))), ((int)(((byte)(254)))));
            this.btn_search.StateCommon.Back.ColorAngle = 45F;
            this.btn_search.StateCommon.Border.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(174)))), ((int)(((byte)(244)))));
            this.btn_search.StateCommon.Border.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(142)))), ((int)(((byte)(254)))));
            this.btn_search.StateCommon.Border.ColorAngle = 45F;
            this.btn_search.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.btn_search.StateCommon.Border.GraphicsHint = ComponentFactory.Krypton.Toolkit.PaletteGraphicsHint.AntiAlias;
            this.btn_search.StateCommon.Border.Rounding = 20;
            this.btn_search.StateCommon.Border.Width = 1;
            this.btn_search.StateCommon.Content.Padding = new System.Windows.Forms.Padding(-1, -3, -1, -3);
            this.btn_search.StateCommon.Content.ShortText.Color1 = System.Drawing.Color.White;
            this.btn_search.StateCommon.Content.ShortText.Color2 = System.Drawing.Color.White;
            this.btn_search.StateCommon.Content.ShortText.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_search.StatePressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(145)))), ((int)(((byte)(198)))));
            this.btn_search.StatePressed.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(121)))), ((int)(((byte)(206)))));
            this.btn_search.StatePressed.Back.ColorAngle = 135F;
            this.btn_search.StatePressed.Border.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(145)))), ((int)(((byte)(198)))));
            this.btn_search.StatePressed.Border.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(121)))), ((int)(((byte)(206)))));
            this.btn_search.StatePressed.Border.ColorAngle = 135F;
            this.btn_search.StatePressed.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.btn_search.StatePressed.Border.Rounding = 20;
            this.btn_search.StatePressed.Border.Width = 1;
            this.btn_search.StateTracking.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(142)))), ((int)(((byte)(254)))));
            this.btn_search.StateTracking.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(174)))), ((int)(((byte)(244)))));
            this.btn_search.StateTracking.Back.ColorAngle = 45F;
            this.btn_search.StateTracking.Border.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(174)))), ((int)(((byte)(244)))));
            this.btn_search.StateTracking.Border.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(142)))), ((int)(((byte)(254)))));
            this.btn_search.StateTracking.Border.ColorAngle = 45F;
            this.btn_search.StateTracking.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.btn_search.StateTracking.Border.GraphicsHint = ComponentFactory.Krypton.Toolkit.PaletteGraphicsHint.AntiAlias;
            this.btn_search.StateTracking.Border.Rounding = 20;
            this.btn_search.StateTracking.Border.Width = 1;
            this.btn_search.TabIndex = 64;
            this.btn_search.Values.Text = "Search";
            this.btn_search.Click += new System.EventHandler(this.btn_search_Click);
            // 
            // cbx_designation
            // 
            this.cbx_designation.CheckOnClick = true;
            this.cbx_designation.Location = new System.Drawing.Point(12, 315);
            this.cbx_designation.Name = "cbx_designation";
            this.cbx_designation.Palette = this.kryptonPalette1;
            this.cbx_designation.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.Custom;
            this.cbx_designation.Size = new System.Drawing.Size(120, 104);
            this.cbx_designation.StateCheckedPressed.Item.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.cbx_designation.StateCheckedTracking.Item.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.cbx_designation.StateCommon.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.cbx_designation.StateCommon.Border.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.cbx_designation.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.cbx_designation.StateCommon.Item.Content.ShortText.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.cbx_designation.TabIndex = 62;
            // 
            // dgv_facultys
            // 
            this.dgv_facultys.AutoGenerateColumns = false;
            this.dgv_facultys.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_facultys.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.facultyidDataGridViewTextBoxColumn,
            this.nameDataGridViewTextBoxColumn,
            this.emailDataGridViewTextBoxColumn,
            this.contactDataGridViewTextBoxColumn,
            this.designationidDataGridViewTextBoxColumn,
            this.designationDataGridViewTextBoxColumn,
            this.researchareaDataGridViewTextBoxColumn,
            this.totalteachinghoursDataGridViewTextBoxColumn,
            this.useridDataGridViewTextBoxColumn,
            this.update,
            this.delete});
            this.dgv_facultys.DataSource = this.facultyBindingSource;
            this.dgv_facultys.Location = new System.Drawing.Point(100, 66);
            this.dgv_facultys.Name = "dgv_facultys";
            this.dgv_facultys.Palette = this.kryptonPalette1;
            this.dgv_facultys.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.Custom;
            this.dgv_facultys.RowTemplate.Height = 40;
            this.dgv_facultys.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgv_facultys.Size = new System.Drawing.Size(857, 246);
            this.dgv_facultys.StateCommon.Background.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.dgv_facultys.StateCommon.Background.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.dgv_facultys.StateCommon.BackStyle = ComponentFactory.Krypton.Toolkit.PaletteBackStyle.GridBackgroundList;
            this.dgv_facultys.StateCommon.DataCell.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.dgv_facultys.StateCommon.DataCell.Border.Color1 = System.Drawing.Color.LightGray;
            this.dgv_facultys.StateCommon.DataCell.Border.Color2 = System.Drawing.Color.Transparent;
            this.dgv_facultys.StateCommon.DataCell.Border.DrawBorders = ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom;
            this.dgv_facultys.StateCommon.DataCell.Content.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.dgv_facultys.StateCommon.DataCell.Content.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgv_facultys.StateCommon.HeaderColumn.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.dgv_facultys.StateCommon.HeaderColumn.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.dgv_facultys.StateCommon.HeaderColumn.Border.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(174)))), ((int)(((byte)(244)))));
            this.dgv_facultys.StateCommon.HeaderColumn.Border.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(142)))), ((int)(((byte)(254)))));
            this.dgv_facultys.StateCommon.HeaderColumn.Border.DrawBorders = ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom;
            this.dgv_facultys.StateCommon.HeaderColumn.Border.Width = 5;
            this.dgv_facultys.StateCommon.HeaderColumn.Content.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgv_facultys.StateCommon.HeaderRow.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.dgv_facultys.StateCommon.HeaderRow.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.dgv_facultys.StateCommon.HeaderRow.Border.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(174)))), ((int)(((byte)(244)))));
            this.dgv_facultys.StateCommon.HeaderRow.Border.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(142)))), ((int)(((byte)(254)))));
            this.dgv_facultys.StateCommon.HeaderRow.Border.DrawBorders = ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right;
            this.dgv_facultys.StateCommon.HeaderRow.Border.Width = 5;
            this.dgv_facultys.StateCommon.HeaderRow.Content.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold);
            this.dgv_facultys.TabIndex = 60;
            this.dgv_facultys.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_facultys_CellContentClick);
            // 
            // facultyidDataGridViewTextBoxColumn
            // 
            this.facultyidDataGridViewTextBoxColumn.DataPropertyName = "faculty_id";
            this.facultyidDataGridViewTextBoxColumn.HeaderText = "Faculty\nId";
            this.facultyidDataGridViewTextBoxColumn.Name = "facultyidDataGridViewTextBoxColumn";
            this.facultyidDataGridViewTextBoxColumn.Width = 80;
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "Name";
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            // 
            // emailDataGridViewTextBoxColumn
            // 
            this.emailDataGridViewTextBoxColumn.DataPropertyName = "email";
            this.emailDataGridViewTextBoxColumn.HeaderText = "Email";
            this.emailDataGridViewTextBoxColumn.Name = "emailDataGridViewTextBoxColumn";
            // 
            // contactDataGridViewTextBoxColumn
            // 
            this.contactDataGridViewTextBoxColumn.DataPropertyName = "contact";
            this.contactDataGridViewTextBoxColumn.HeaderText = "Contact";
            this.contactDataGridViewTextBoxColumn.Name = "contactDataGridViewTextBoxColumn";
            // 
            // designationidDataGridViewTextBoxColumn
            // 
            this.designationidDataGridViewTextBoxColumn.DataPropertyName = "designation_id";
            this.designationidDataGridViewTextBoxColumn.HeaderText = "Designation\nId";
            this.designationidDataGridViewTextBoxColumn.Name = "designationidDataGridViewTextBoxColumn";
            this.designationidDataGridViewTextBoxColumn.Visible = false;
            // 
            // designationDataGridViewTextBoxColumn
            // 
            this.designationDataGridViewTextBoxColumn.DataPropertyName = "designation";
            this.designationDataGridViewTextBoxColumn.HeaderText = "Designation";
            this.designationDataGridViewTextBoxColumn.Name = "designationDataGridViewTextBoxColumn";
            // 
            // researchareaDataGridViewTextBoxColumn
            // 
            this.researchareaDataGridViewTextBoxColumn.DataPropertyName = "research_area";
            this.researchareaDataGridViewTextBoxColumn.HeaderText = "Research\nArea";
            this.researchareaDataGridViewTextBoxColumn.Name = "researchareaDataGridViewTextBoxColumn";
            // 
            // totalteachinghoursDataGridViewTextBoxColumn
            // 
            this.totalteachinghoursDataGridViewTextBoxColumn.DataPropertyName = "total_teaching_hours";
            this.totalteachinghoursDataGridViewTextBoxColumn.HeaderText = "Teaching\nHours";
            this.totalteachinghoursDataGridViewTextBoxColumn.Name = "totalteachinghoursDataGridViewTextBoxColumn";
            this.totalteachinghoursDataGridViewTextBoxColumn.Width = 60;
            // 
            // useridDataGridViewTextBoxColumn
            // 
            this.useridDataGridViewTextBoxColumn.DataPropertyName = "user_id";
            this.useridDataGridViewTextBoxColumn.HeaderText = "User\nId";
            this.useridDataGridViewTextBoxColumn.Name = "useridDataGridViewTextBoxColumn";
            this.useridDataGridViewTextBoxColumn.Visible = false;
            this.useridDataGridViewTextBoxColumn.Width = 60;
            // 
            // update
            // 
            this.update.ButtonStyle = ComponentFactory.Krypton.Toolkit.ButtonStyle.Custom1;
            this.update.HeaderText = "Update";
            this.update.Name = "update";
            this.update.Text = "Up";
            this.update.Width = 80;
            // 
            // delete
            // 
            this.delete.ButtonStyle = ComponentFactory.Krypton.Toolkit.ButtonStyle.Custom2;
            this.delete.HeaderText = "Delete";
            this.delete.Name = "delete";
            this.delete.Text = "Delete";
            this.delete.Width = 80;
            // 
            // facultyBindingSource
            // 
            this.facultyBindingSource.DataSource = typeof(Krypton_toolKit_Demo.BL.Faculty);
            // 
            // lbl_designation
            // 
            this.lbl_designation.AutoSize = true;
            this.lbl_designation.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_designation.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbl_designation.Location = new System.Drawing.Point(12, 294);
            this.lbl_designation.Name = "lbl_designation";
            this.lbl_designation.Size = new System.Drawing.Size(82, 18);
            this.lbl_designation.TabIndex = 63;
            this.lbl_designation.Text = "Designation";
            // 
            // FacultyManagement
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.ClientSize = new System.Drawing.Size(948, 498);
            this.Controls.Add(this.gbx_add_updt_faculty);
            this.Controls.Add(this.pnl_sort_direction);
            this.Controls.Add(this.pnl_sortby);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.txt_search_facultys);
            this.Controls.Add(this.btn_dashboard);
            this.Controls.Add(this.btn_search);
            this.Controls.Add(this.cbx_designation);
            this.Controls.Add(this.dgv_facultys);
            this.Controls.Add(lbl_direction);
            this.Controls.Add(lbl_sort);
            this.Controls.Add(label1);
            this.Controls.Add(this.lbl_designation);
            this.Name = "FacultyManagement";
            this.Palette = this.kryptonPalette1;
            this.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.Custom;
            this.Text = "FacultyManagement";
            this.Load += new System.EventHandler(this.FacultyManagement_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gbx_add_updt_faculty.Panel)).EndInit();
            this.gbx_add_updt_faculty.Panel.ResumeLayout(false);
            this.gbx_add_updt_faculty.Panel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gbx_add_updt_faculty)).EndInit();
            this.gbx_add_updt_faculty.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.cmbx_designations)).EndInit();
            this.pnl_sort_direction.ResumeLayout(false);
            this.pnl_sort_direction.PerformLayout();
            this.pnl_sortby.ResumeLayout(false);
            this.pnl_sortby.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_facultys)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.facultyBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ComponentFactory.Krypton.Toolkit.KryptonGroupBox gbx_add_updt_faculty;
        private ComponentFactory.Krypton.Toolkit.KryptonPalette kryptonPalette1;
        private ComponentFactory.Krypton.Toolkit.KryptonComboBox cmbx_designations;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox txt_email;
        private ComponentFactory.Krypton.Toolkit.KryptonButton btn_back;
        private ComponentFactory.Krypton.Toolkit.KryptonButton btn_add_updt;
        private System.Windows.Forms.Label lbl_designations;
        private System.Windows.Forms.Label lbl_research_area;
        private System.Windows.Forms.Label lbl_user_name;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox txt_research_area;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox txt_user_name;
        private System.Windows.Forms.Panel pnl_sort_direction;
        private ComponentFactory.Krypton.Toolkit.KryptonRadioButton rdo_desc;
        private ComponentFactory.Krypton.Toolkit.KryptonRadioButton rdo_asc;
        private System.Windows.Forms.Panel pnl_sortby;
        private ComponentFactory.Krypton.Toolkit.KryptonRadioButton rdo_sort_name;
        private ComponentFactory.Krypton.Toolkit.KryptonRadioButton rdo_sort_id;
        private ComponentFactory.Krypton.Toolkit.KryptonRadioButton rdo_sort_email;
        private ComponentFactory.Krypton.Toolkit.KryptonButton btn_add;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox txt_search_facultys;
        private ComponentFactory.Krypton.Toolkit.KryptonButton btn_dashboard;
        private ComponentFactory.Krypton.Toolkit.KryptonButton btn_search;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckedListBox cbx_designation;
        private ComponentFactory.Krypton.Toolkit.KryptonDataGridView dgv_facultys;
        private System.Windows.Forms.Label lbl_designation;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox txt_password;
        private System.Windows.Forms.Label lbl_name;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox txt_name;
        private System.Windows.Forms.Label lbl_contact;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox txt_contact;
        private System.Windows.Forms.Label lbl_teaching_hours;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox txt_teaching_hours;
        private System.Windows.Forms.BindingSource facultyBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn facultyidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn emailDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn contactDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn designationidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn designationDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn researchareaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn totalteachinghoursDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn useridDataGridViewTextBoxColumn;
        private ComponentFactory.Krypton.Toolkit.KryptonDataGridViewButtonColumn update;
        private ComponentFactory.Krypton.Toolkit.KryptonDataGridViewButtonColumn delete;
    }
}