﻿using ComponentFactory.Krypton.Toolkit;
using Krypton_toolKit_Demo.BL;
using Krypton_toolKit_Demo.DL;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Krypton_toolKit_Demo.UI
{
    public partial class FacultyAdminRoleForm : KryptonForm
    {
        static int? admin_roleId = null;
        static int faculty_id = 0;
        int facultyId = 0;
        int userRole = 3;
        public FacultyAdminRoleForm(int userRole = 3,int facultyId = 0)
        {
            InitializeComponent();
            this.userRole = userRole;

            if (userRole == 2)
            {
                this.facultyId = facultyId;
            }
        }

        private void gbx_add_updt_admin_role_Panel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            string name = null, sortby = null, direction = null;
            List<FacultyAdminRoleDTO> admin_roles;
            // Get the item text
            // Get the item text
            ItemCheckListHandler handler = new ItemCheckListHandler(cbx_semester_term);
            List<string> semester_terms = handler.GetCheckedItems();


            if (txt_search_admin_roles.Text != "Search role/faculty")
                name = txt_search_admin_roles.Text;

            if (rdo_sort_faculty_name.Checked)
                sortby = "f.name";
            else if (rdo_sort_semester_year.Checked)
                sortby = "s.year";
            else if (rdo_sort_role_name.Checked)
                sortby = "far.role_name";


            if (rdo_asc.Checked)
            {
                direction = "DESC";
            }
            else if (rdo_desc.Checked)
            {
                direction = "ASC";
            }
            if(facultyId != 0)
            {
                admin_roles = FacultyAdminRoleCRUD.GetFacultyAdminRoles(name, semester_terms, sortby, direction, facultyId);
            }
            else
            {
                admin_roles = FacultyAdminRoleCRUD.GetFacultyAdminRoles(name, semester_terms, sortby, direction);
            }
            //admin_roles = FacultyAdminRoleCRUD.GetFacultyAdminRoles(name, semester_terms, sortby, direction);
            facultyAdminRoleDTOBindingSource.DataSource = admin_roles;
            dgv_admin_roles.DataSource = facultyAdminRoleDTOBindingSource;
        }

        private void FacultyAdminRoleForm_Load(object sender, EventArgs e)
        {
            List<string> years = SemesterCRUD.GetSemesterYears();
            cmbx_semester_year.Items.AddRange(years.ToArray());
            if (facultyId != 0)
            {
                dgv_admin_roles.Columns["update"].Visible = false;
                dgv_admin_roles.Columns["delete"].Visible = false;
                btn_add.Visible = false;

            }

        }

        private void dgv_admin_roles_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                var cellValue = dgv_admin_roles.Rows[e.RowIndex].Cells["facultyIdDataGridViewTextBoxColumn"].Value;
                faculty_id = Convert.ToInt32(cellValue);
            }
            if (e.RowIndex >= 0 && e.ColumnIndex == dgv_admin_roles.Columns["update"].Index)
            {
                var cellValue = dgv_admin_roles.Rows[e.RowIndex].Cells["adminRoleIdDataGridViewTextBoxColumn"].Value;
                //IsDBNull(reader.GetOrdinal("AdminRoleId")) ? (int?)null : reader.GetInt32(reader.GetOrdinal("AdminRoleId"))
                if (cellValue != null && cellValue != DBNull.Value)
                {
                    admin_roleId = Convert.ToInt32(cellValue);
                }

                if (admin_roleId == null)
                {
                    enableGroupBox();
                }
                else
                {
                    var far = FacultyAdminRoleCRUD.GetFacultyAdminRole(admin_roleId.Value);
                    var sem = SemesterCRUD.GetSemesterFromDB(far.SemesterId.Value);
                    far.SemesterTerm = sem.term;
                    far.SemesterYear = sem.year;
                    enableGroupBox(far);
                }
                btn_search_Click(sender, e);
                //MessageBox.Show($"Delete button clicked in row: {e.RowIndex + 1}");
            }
            if (e.RowIndex >= 0 && e.ColumnIndex == dgv_admin_roles.Columns["delete"].Index)
            {
                var cellValue = dgv_admin_roles.Rows[e.RowIndex].Cells["adminRoleIdDataGridViewTextBoxColumn"].Value;
                admin_roleId = Convert.ToInt32(cellValue);
                if (admin_roleId != null)
                    FacultyAdminRoleDTO.DeleteFacultyAdminRole(admin_roleId.Value);
                btn_search_Click(sender, e);
                //MessageBox.Show($"Delete button clicked in row: {e.RowIndex + 1}");
            }
        }
        private void enableGroupBox(FacultyAdminRoleDTO far = null)
        {
            gbx_add_updt_admin_role.Enabled = true;
            gbx_add_updt_admin_role.Visible = true;
            if (admin_roleId.HasValue)
            {
                txt_role_name.Text = far.RoleName;
                if (far.SemesterYear.HasValue)
                {
                    cmbx_semester_year.Text = far.SemesterYear.Value.ToString();
                }
                else
                {
                    cmbx_semester_year.Text = string.Empty;
                }
                cmbx_semester_term.Text = far.SemesterTerm ?? string.Empty;

                btn_add_updt.Text = "Update";
            }
        }
        private void disableGroupBox()
        {
            gbx_add_updt_admin_role.Enabled = false;
            gbx_add_updt_admin_role.Visible = false;
            cmbx_semester_year.Text = "Select Year";
            cmbx_semester_term.Text = "Select Term";
            txt_role_name.Text = "Enter Role Name";
            admin_roleId = null;
        }

        private void btn_add_updt_Click(object sender, EventArgs e)
        {
            try
            {

                if (admin_roleId.HasValue)
                {
                    if (admin_roleId.HasValue)
                    {
                        FacultyAdminRoleDTO far = new FacultyAdminRoleDTO
                        {
                           RoleName = txt_role_name.Text,

                            AdminRoleId = admin_roleId.Value,
                            SemesterId = SemesterCRUD.GetSemesterId(Convert.ToInt32(cmbx_semester_year.Text), cmbx_semester_term.Text),
                            FacultyId = faculty_id,
                            SemesterYear = Convert.ToInt32(cmbx_semester_year.Text)
                        };
                        far.UpdateFacultyAdminRole();
                    }
                }
                    else
                    {
                        FacultyAdminRoleDTO far = new FacultyAdminRoleDTO
                        {
                            RoleName = txt_role_name.Text,
                            SemesterId = SemesterCRUD.GetSemesterId(Convert.ToInt32(cmbx_semester_year.Text), cmbx_semester_term.Text),
                            SemesterYear = Convert.ToInt32(cmbx_semester_year.Text),
                            FacultyId = faculty_id
                        };
                        far.AddFacultyAdminRole();

                    }
            }
            catch (Exception ex)
            {
                //throw ex;
                MessageBox.Show(ex.Message);
            }
            btn_search_Click(sender, e);
            disableGroupBox();
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            disableGroupBox();
        }

        private void txt_role_name_Leave(object sender, EventArgs e)
        {
            if (txt_role_name.Text == "")
                txt_role_name.Text = "Enter Role Name";
        }

        private void txt_role_name_Enter(object sender, EventArgs e)
        {
            if (txt_role_name.Text == "Enter Role Name")
                txt_role_name.Text = "";
        }

        private void txt_search_admin_roles_Leave(object sender, EventArgs e)
        {
            if (txt_search_admin_roles.Text == "")
                txt_search_admin_roles.Text = "Enter role/faculty";
        }

        private void txt_search_admin_roles_Enter(object sender, EventArgs e)
        {
            if (txt_search_admin_roles.Text == "Enter role/faculty")
                txt_search_admin_roles.Text = "";
        }

        private void cmbx_semester_year_SelectedIndexChanged(object sender, EventArgs e)
        {
            int selectedValue = Convert.ToInt32(cmbx_semester_year.Text);
            List<string> terms = SemesterCRUD.GetSemesterTerms(selectedValue);
            cmbx_semester_term.Items.Clear();
            cmbx_semester_term.Items.AddRange(terms.ToArray());
        }

        private void btn_dashboard_Click(object sender, EventArgs e)
        {
            if (userRole == 2)
                new FacultyDashboard(facultyId).Show();
            else
                new DepartmentHeadDashboard().Show();
            this.Close();
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            enableGroupBox();
        }
    }

}
