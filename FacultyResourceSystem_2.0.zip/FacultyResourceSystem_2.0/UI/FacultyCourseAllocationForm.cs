﻿using ComponentFactory.Krypton.Toolkit;
using Krypton_toolKit_Demo.BL;
using Krypton_toolKit_Demo.DL;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Krypton_toolKit_Demo.UI
{
    public partial class FacultyCourseAllocationForm : KryptonForm
    {
        static int? faculty_courseId = null;
        static int faculty_id = 0;
        int UserRole;
        int facultyId;
        public FacultyCourseAllocationForm(int UserRole = 1,int facultyId = 0)
        {
            InitializeComponent();
                this.UserRole = UserRole;
            if(UserRole == 2)
            {
                this.facultyId = facultyId;
            }
        }

        private void lbl_course_name_Click(object sender, EventArgs e)
        {

        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            string name = null, sortby = null, direction = null;
            List<CourseAllocationDTO> faculty_courses;
            // Get the item text
            // Get the item text
            ItemCheckListHandler handler = new ItemCheckListHandler(cbx_semester_term);
            List<string> semester_terms = handler.GetCheckedItems();
            ItemCheckListHandler handler2 = new ItemCheckListHandler(cbx_course_type);
            List<string> course_types = handler2.GetCheckedItems();


            if (txt_search_faculty_courses.Text != "Search course/faculty")
                name = txt_search_faculty_courses.Text;

            if (rdo_sort_faculty_name.Checked)
                sortby = "f.name";
            else if (rdo_sort_semester_year.Checked)
                sortby = "s.year";
            else if (rdo_sort_course_name.Checked)
                sortby = "c.course_name";


            if (rdo_asc.Checked)
            {
                direction = "DESC";
            }
            else if (rdo_desc.Checked)
            {
                direction = "ASC";
            }
            if(UserRole == 2)
            {
                faculty_courses = CourseAllocationCRUD.GetCourseAllocations(name, semester_terms, course_types, sortby, direction, facultyId);

                
            }else
                faculty_courses = CourseAllocationCRUD.GetCourseAllocations(name, semester_terms, course_types, sortby, direction);
            courseAllocationDTOBindingSource.DataSource = faculty_courses;
            dgv_faculty_courses.DataSource = courseAllocationDTOBindingSource;
        }

        private void dgv_faculty_courses_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                var cellValue = dgv_faculty_courses.Rows[e.RowIndex].Cells["facultyIdDataGridViewTextBoxColumn"].Value;
                faculty_id = Convert.ToInt32(cellValue);
            }
            if (e.RowIndex >= 0 && e.ColumnIndex == dgv_faculty_courses.Columns["update"].Index)
            {
                var cellValue = dgv_faculty_courses.Rows[e.RowIndex].Cells["facultyCourseIdDataGridViewTextBoxColumn"].Value;
                faculty_courseId = Convert.ToInt32(cellValue);

                var ca = CourseAllocationCRUD.GetCourseAllocation(faculty_courseId.Value);
                enableGroupBox(ca);
                //MessageBox.Show($"Delete button clicked in row: {e.RowIndex + 1}");
            }
            if (e.RowIndex >= 0 && e.ColumnIndex == dgv_faculty_courses.Columns["delete"].Index)
            {
                var cellValue = dgv_faculty_courses.Rows[e.RowIndex].Cells["facultyCourseIdDataGridViewTextBoxColumn"].Value;
                //IsDBNull(reader.GetOrdinal("FacultyCourseId")) ? (int?)null : reader.GetInt32(reader.GetOrdinal("FacultyCourseId"))
                if (cellValue != null && cellValue != DBNull.Value)
                {
                    faculty_courseId = Convert.ToInt32(cellValue);
                }
                CourseAllocationDTO.DeleteCourseAllocation(faculty_courseId.Value);
                faculty_courseId = null;
                btn_search_Click(sender, e);
                //MessageBox.Show($"Delete button clicked in row: {e.RowIndex + 1}");
            }
        }
        private void enableGroupBox(CourseAllocationDTO ca = null)
        {
            gbx_add_updt_faculty_course.Enabled = true;
            gbx_add_updt_faculty_course.Visible = true;
            List<string> years = SemesterCRUD.GetSemesterYears();
            cmbx_semester_year.Items.AddRange(years.ToArray());
            List<string> courses = CourseCRUD.GetCoursesNames();
            cmbx_course.Items.AddRange(courses.ToArray());
            List<string> faculty_names = FacultyCRUD.GetFacultyNames();
            cmbx_faculty_name.Items.AddRange(faculty_names.ToArray());

            if (faculty_courseId.HasValue)
            {
                if (ca.SemesterYear.HasValue)
                {
                    cmbx_semester_year.Text = ca.SemesterYear.Value.ToString();
                }
                else
                {
                    cmbx_semester_year.Text = string.Empty;
                }
                cmbx_semester_term.Text = ca.SemesterTerm ?? string.Empty;
                cmbx_course.Text = ca.CourseName;
                cmbx_course_types.Text = ca.CourseType;
                cmbx_faculty_name.Text = ca.FacultyName;

                btn_add_updt.Text = "Update";
            }
        }
        private void disableGroupBox()
        {
            gbx_add_updt_faculty_course.Enabled = false;
            gbx_add_updt_faculty_course.Visible = false;
            cmbx_semester_year.Text = "Select Year";
            cmbx_semester_term.Text = "Select Term";
            cmbx_course.Text = "Select Course";
            cmbx_course_types.Text = "Select Type";
            faculty_courseId = null;
            cmbx_course.Items.Clear();
            cmbx_semester_year.Items.Clear();
            cmbx_faculty_name.Items.Clear();
            faculty_courseId = null;
            faculty_id = 0;
        }

        private void FacultyCourseAllocationForm_Load(object sender, EventArgs e)
        {
            btn_search_Click(sender, e);
            //List<string> years = SemesterCRUD.GetSemesterYears();
            //cmbx_semester_year.Items.AddRange(years.ToArray());
            if (UserRole == 2)
            {
                dgv_faculty_courses.Columns["update"].Visible = false;
                dgv_faculty_courses.Columns["delete"].Visible = false;
                dgv_faculty_courses.Columns["facultyNameDataGridViewTextBoxColumn"].Visible = false;
                btn_export.Visible = false;
                btn_add.Visible = false;
            }
                if(UserRole == 3)  btn_export.Visible = true;
        }

        private void cmbx_semester_year_SelectedIndexChanged(object sender, EventArgs e)
        {
            int selectedValue = Convert.ToInt32(cmbx_semester_year.Text);
            List<string> terms = SemesterCRUD.GetSemesterTerms(selectedValue);
            cmbx_semester_term.Items.Clear();
            cmbx_semester_term.Items.AddRange(terms.ToArray());
        }

        private void cmbx_course_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedValue = cmbx_course.Text;
            List<string> course_types = CourseCRUD.GetCourseTypes(selectedValue);
            cmbx_course_types.Items.Clear();
            cmbx_course_types.Items.AddRange(course_types.ToArray());
        }

        private void btn_add_updt_Click(object sender, EventArgs e)
        {
            try
            {

                if (faculty_courseId.HasValue)
                {
                    if (faculty_courseId.HasValue)
                    {
                        CourseAllocationDTO ca = new CourseAllocationDTO
                        {
                            CourseName = cmbx_course.Text,

                            FacultyCourseId = faculty_courseId.Value,
                            SemesterId = SemesterCRUD.GetSemesterId(Convert.ToInt32(cmbx_semester_year.Text), cmbx_semester_term.Text),
                            CourseId = CourseCRUD.GetCourseId(cmbx_course.Text, cmbx_course_types.Text),
                            FacultyId = faculty_id,
                            SemesterYear = Convert.ToInt32(cmbx_semester_year.Text)
                        };
                        ca.UpdateCourseAllocation();
                    }
                }
                else
                {
                    CourseAllocationDTO ca = new CourseAllocationDTO
                    {
                        CourseName = txt_search_faculty_courses.Text,
                        SemesterId = SemesterCRUD.GetSemesterId(Convert.ToInt32(cmbx_semester_year.Text), cmbx_semester_term.Text),
                        //SemesterYear = Convert.ToInt32(cmbx_semester_year.Text),
                        CourseId = CourseCRUD.GetCourseId(cmbx_course.Text, cmbx_course_types.Text),
                        FacultyId = FacultyCRUD.GetFacultyId(cmbx_faculty_name.Text)
                    };
                    ca.AddCourseAllocation();

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                disableGroupBox();
                btn_search_Click(sender, e);
            }
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            disableGroupBox();
        }

        private void btn_dashboard_Click(object sender, EventArgs e)
        {
            if(UserRole == 3)
                new DepartmentHeadDashboard().Show();
            else
                new FacultyDashboard(facultyId).Show();
            this.Close();
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            enableGroupBox();
        }

        private void txt_search_faculty_courses_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_export_Click(object sender, EventArgs e)
        {
            new CourseAllocationReport().Show();
        }
    }
}
