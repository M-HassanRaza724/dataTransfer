﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ComponentFactory.Krypton.Toolkit;

namespace Krypton_toolKit_Demo.UI
{
    public partial class AdminDashboard: KryptonForm
    {
        static User User = null;
        public AdminDashboard(User user = null)
        {
            InitializeComponent();
            User = user;
        }

        private void AdminDashboard_Load(object sender, EventArgs e)
        {

        }

        private void kryptonPalette1_PalettePaint(object sender, ComponentFactory.Krypton.Toolkit.PaletteLayoutEventArgs e)
        {

        }

        private void btn_profiles_Click(object sender, EventArgs e)
        {
            new UserManagement().Show();
            this.Close();
        }

        private void btn_courses_Click(object sender, EventArgs e)
        {
            new CourseManagement().Show();
            this.Close();
        }

        private void btn_rooms_Click(object sender, EventArgs e)
        {
            new RoomManagement().Show();
            this.Close();
        }

        private void btn_consumables_Click(object sender, EventArgs e)
        {
            new ConsumableManagement().Show();
            this.Close();

        }

        private void btn_projects_Click(object sender, EventArgs e)
        {
            new ProjectManagement().Show();

            this.Close();

        }

        private void btn_faculty_requests_Click(object sender, EventArgs e)
        {
            new FacultyRequestForm(1).Show();
            this.Close();
        }

        private void btn_semesters_Click(object sender, EventArgs e)
        {
            new SemesterManagement().Show();
            this.Close();
        }

        private void btn_logout_Click(object sender, EventArgs e)
        {
            User = null;
            new LoginForm().Show();
            this.Close();
        }

        private void kryptonButton1_Click(object sender, EventArgs e)
        {
            new FacultyManagement().Show();
            this.Close();
        }
    }
}
