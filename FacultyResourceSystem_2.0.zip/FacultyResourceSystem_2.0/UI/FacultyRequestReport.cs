﻿using Krypton_toolKit_Demo.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ComponentFactory.Krypton.Toolkit;

namespace Krypton_toolKit_Demo.UI
{
    public partial class FacultyRequestReport: KryptonForm
    {
        public 
            FacultyRequestReport()
        {
            InitializeComponent();
        }

        private void FacultyRequestReport_Load(object sender, EventArgs e)
        {
            rpt_faculty_requests.DataBindings.Clear();
            facultyRequestBindingSource.DataSource = FacultyRequestCRUD.GetFacultyRequests();   
            this.rpt_faculty_requests.RefreshReport();
        }
    }
}
