﻿using ComponentFactory.Krypton.Toolkit;
using Krypton_toolKit_Demo.BL;
using Krypton_toolKit_Demo.DL;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Krypton_toolKit_Demo.UI
{
    public partial class FacultyRequestForm : KryptonForm
    {
        int facultyId { get; set; }
        int UserRoleId { get; set; }
        public FacultyRequestForm()
        {
            InitializeComponent();
        }
        public FacultyRequestForm(int userRoleId, int facultyId = -1)
        {
            InitializeComponent();
            this.UserRoleId = userRoleId;
            if (userRoleId == 2)
                this.facultyId = facultyId;
        }

        private void btn_search_Click(object sender, EventArgs e)
        {

            string name = null, sortby = null, direction = null;
            List<FacultyRequestDTO> requests;
            // Get the item text
            // Get the item text
            ItemCheckListHandler handler = new ItemCheckListHandler(cbx_status);
            List<string> statuses = handler.GetCheckedItems();


            if (txt_search_requests.Text != "Search requests")
                name = txt_search_requests.Text;

            if (rdo_sort_name.Checked)
                sortby = "item_name";
            else if (rdo_sort_date.Checked)
                sortby = "request_date";
            else if (rdo_sort_quantity.Checked)
                sortby = "quantity";


            if (rdo_asc.Checked)
            {
                direction = "DESC";
            }
            else if (rdo_desc.Checked)
            {
                direction = "ASC";
            }
            if (UserRoleId == 1)
            {
                //statuses.Clear();
                statuses = new List<string>();
                statuses.Add("Approved");
            }
            else if (UserRoleId == 3)
            {
                //statuses.Clear();
                statuses = new List<string>();
                statuses.Add("Pending");
            }
            if (UserRoleId == 2)
                requests = FacultyRequestCRUD.GetFacultyRequests(facultyId,name, statuses, sortby, direction);
            else
            {

                requests = FacultyRequestCRUD.GetFacultyRequests(0,name, statuses, sortby, direction);
            }

            facultyRequestDTOBindingSource.DataSource = requests;
            dgv_requests.DataSource = facultyRequestDTOBindingSource;
        }

        private void FacultyRequestForm_Load(object sender, EventArgs e)
        {
            if (UserRoleId == 2)
            {
                dgv_requests.Columns["update"].Visible = false;
                dgv_requests.Columns["delete"].Visible = false;
                dgv_requests.Columns["facultynameDataGridViewTextBoxColumn"].Visible = false;

                List<string> items = new List<string>();
                foreach (Consumable c in ConsumableCRUD.GetConsumables())
                {
                    items.Add(c.item_name);
                }
                cmbx_items.Items.AddRange(items.ToArray());
                List<string> status = LookupCRUD.GetValues("RequestStatus");
                cbx_status.Items.AddRange(status.ToArray());
                btn_export.Visible = false;

            }
            else
            {
                btn_add.Visible = false;
                //lbl_status.Visible = false;
                cbx_status.Visible = false;
                update.Text = "Approve";
                delete.Text = "Reject";
                if (UserRoleId == 1)
                {
                    dgv_requests.Columns["delete"].Visible = false;
                    update.Text = "Fulfill";
                }
            }
            
        btn_search_Click(sender, e);
        }

            

        private void dgv_requests_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex == dgv_requests.Columns["update"].Index)
            {
                var cellValue = dgv_requests.Rows[e.RowIndex].Cells["requestidDataGridViewTextBoxColumn"].Value;
                int requestId = Convert.ToInt32(cellValue);

                int statusId = 0;
                if(UserRoleId == 1)
                {
                    statusId = LookupCRUD.GetId("Fulfilled");
                }
                else if (UserRoleId == 3)
                {
                    statusId = LookupCRUD.GetId("Approved");
                }
                FacultyRequestCRUD.UpdateFacultyRequest(requestId,statusId);
                btn_search_Click(sender, e);
                //MessageBox.Show($"Delete button clicked in row: {e.RowIndex + 1}");
            }
            if (e.RowIndex >= 0 && e.ColumnIndex == dgv_requests.Columns["delete"].Index)
            {
                var cellValue = dgv_requests.Rows[e.RowIndex].Cells["requestidDataGridViewTextBoxColumn"].Value;
                int requestId = Convert.ToInt32(cellValue);
                if(UserRoleId == 3)
                {
                    int statusId = LookupCRUD.GetId("Rejected");
                    FacultyRequestCRUD.UpdateFacultyRequest(requestId, statusId);
                }
                btn_search_Click(sender, e);
                //MessageBox.Show($"Delete button clicked in row: {e.RowIndex + 1}");
            }
        }
        private void enableGroupBox()
        {
            gbx_add_updt_request.Enabled = true;
            gbx_add_updt_request.Visible = true;
        }
        private void disableGroupBox()
        {
            gbx_add_updt_request.Enabled = false;
            gbx_add_updt_request.Visible = false;
            txt_quantity.Text = "Enter Quantity";
            cmbx_items.Text = "Select Item";
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            enableGroupBox();
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            disableGroupBox();
        }

        private void btn_add_updt_Click(object sender, EventArgs e)
        {
            FacultyRequestDTO fr = new FacultyRequestDTO(facultyId, ConsumableCRUD.GetConsumableId(cmbx_items.Text), Convert.ToInt32(txt_quantity.Text));
            FacultyRequestDTO.AddFacultyRequest(fr);
            btn_search_Click(sender, e);
            disableGroupBox();
        }

        private void txt_quantity_Enter(object sender, EventArgs e)
        {
            if (txt_quantity.Text == "Enter Quantity")
                txt_quantity.Text = "";
        }

        private void txt_quantity_Leave(object sender, EventArgs e)
        {
            if (txt_quantity.Text == "")
            {
                txt_quantity.Text = "Enter Quantity";
            }
        }

        private void btn_dashboard_Click(object sender, EventArgs e)
        {
            if(UserRoleId == 1)
            {
                new AdminDashboard().Show();
            }
            else if (UserRoleId == 2)
            {
                new FacultyDashboard(facultyId).Show();
            }
            else if (UserRoleId == 3)
            {
                new DepartmentHeadDashboard().Show();
            }
            this.Close();
        }

        private void btn_export_Click(object sender, EventArgs e)
        {
            new FacultyRequestReport().Show();
        }
    }
}
