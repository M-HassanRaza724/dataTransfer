﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Krypton_toolKit_Demo.BL;
using ComponentFactory.Krypton.Toolkit;
using Krypton_toolKit_Demo.DL;

namespace Krypton_toolKit_Demo.UI
{
    public partial class UserManagement : KryptonForm
    {
        static User user = null;

        //BindingSource UserBindingSource = new BindingSource();
        public UserManagement()
        {
            InitializeComponent();
        }
        //cbx_roles.Items.Add("Admin");

        private void btn_add_Click(object sender, EventArgs e)
        {
            gbx_add_updt_user.Enabled = true;
            gbx_add_updt_user.Visible = true;
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            List<User> users;
            string name = null, sortby = null, direction = null;
            // Get the item text
            ItemCheckListHandler handler = new ItemCheckListHandler(cbx_role);
            List<string> roles = handler.GetCheckedItems();

            if (txt_search_users.Text != "Search users")
                name = txt_search_users.Text;

            if (rdo_sort_name.Checked)
                sortby = "username";
            else if (rdo_sort_email.Checked)
                sortby = "email";
            else if (rdo_sort_id.Checked)
                sortby = "user_id";

            if (rdo_asc.Checked)
            {
                direction = "DESC";
            }
            else if (rdo_desc.Checked)
            {
                direction = "ASC";
            }

            //MessageBox.Show($"name is {name}, type is {itemType}, sort is {sortby}");
            users = UserCRUD.GetUsers(name, roles, sortby, direction);

            userBindingSource.DataSource = users;
            dgv_users.DataSource = userBindingSource;
            dgv_users.Refresh();
            MessageBox.Show("Data Loaded Successfully");
        }

        private void UserManagement_Load(object sender, EventArgs e)
        {
            btn_search_Click(sender, e);
            List<string> roles = LookupCRUD.GetValues("UserRoles");
            cmbx_roles.Items.AddRange(roles.ToArray());
            cbx_role.Items.AddRange(roles.ToArray());
        }

        private void dgv_users_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex == dgv_users.Columns["update"].Index)
            {
                var cellValue = dgv_users.Rows[e.RowIndex].Cells["useridDataGridViewTextBoxColumn"].Value;
                int userId = Convert.ToInt32(cellValue);
                user = UserCRUD.GetUser(userId);
                enableGroupBox();
                //MessageBox.Show($"Update button clicked in row: {e.RowIndex + 1}");
            }
            if (e.RowIndex >= 0 && e.ColumnIndex == dgv_users.Columns["delete"].Index)
            {
                var cellValue = dgv_users.Rows[e.RowIndex].Cells["useridDataGridViewTextBoxColumn"].Value;
                int userId = Convert.ToInt32(cellValue);

                User.DeleteUser(userId);
                btn_search_Click(sender, e);
                //Handle button click
                //MessageBox.Show($"Delete button clicked in row: {e.RowIndex + 1}");
            }
        }

        private void btn_add_updt_Click(object sender, EventArgs e)
        {
            if (btn_add_updt.Text == "Update")
            {
                try
                {
                    User u = new User(user.UserId,txt_user_name.Text, txt_email.Text, PasswordHasher.HashPassword(txt_password.Text), LookupCRUD.GetId(cmbx_roles.Text));
                    FacultyCRUD.UpdateFacultyEmail(user.UserId, txt_email.Text);
                    u.UpdateUser();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                try
                {
                    User u = new User(txt_user_name.Text, txt_email.Text,PasswordHasher.HashPassword(txt_password.Text),LookupCRUD.GetId(cmbx_roles.Text));
                    u.AddUser();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            btn_search_Click(sender, e);
            disableGroupBox();
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            disableGroupBox();
        }

        private void enableGroupBox()
        {
            gbx_add_updt_user.Enabled = true;
            gbx_add_updt_user.Visible = true;
            if (user != null)
            {
                txt_user_name.Text = user.Name;
                txt_email.Text = user.Email;
                cmbx_roles.SelectedIndex = user.RoleId-1;
                gbx_add_updt_user.Text = "Update User";
                btn_add_updt.Text = "Update";
                gbx_add_updt_user.Refresh();
            }
        }

        private void disableGroupBox()
        {
            gbx_add_updt_user.Enabled = false;
            gbx_add_updt_user.Visible = false;
            user = null;
            txt_user_name.Text = "Enter UserName";
            txt_email.Text = "Enter Email";
            txt_password.Text = "Enter Password";
            gbx_add_updt_user.Text = "Add User";
            btn_add_updt.Text = "Add";
            gbx_add_updt_user.Refresh();
        }

        private void txt_user_name_Leave(object sender, EventArgs e)
        {
            if(txt_user_name.Text == "")
                txt_user_name.Text = "Enter UserName";
        }

        private void txt_user_name_Enter(object sender, EventArgs e)
        {
            if(txt_user_name.Text == "Enter UserName")
                txt_user_name.Text = "";
        }

        private void txt_email_Leave(object sender, EventArgs e)
        {
            if( txt_email.Text == "")
                txt_email.Text = "Enter Email";
        }

        private void txt_email_Enter(object sender, EventArgs e)
        {
            if(txt_email.Text == "Enter Email")
                txt_email.Text = "";
        }

        private void txt_password_Leave(object sender, EventArgs e)
        {
            if(txt_password.Text == "")
            {

                txt_password.PasswordChar = '\0';
                txt_password.Text = "Enter Password";
            }
        }

        private void txt_password_Enter(object sender, EventArgs e)
        {
            if(txt_password.Text == "Enter Password")
                txt_password.Text = "";
        }

        private void txt_search_users_Leave(object sender, EventArgs e)
        {
            if(txt_search_users.Text == "")
            {
                txt_search_users.Text = "Search users";
            }
        }

        private void txt_search_users_MouseDown(object sender, MouseEventArgs e)
        {

        }

        private void txt_search_users_Enter(object sender, EventArgs e)
        {
            if(txt_search_users.Text == "Search users")
                txt_search_users.Text = "";
        }

        private void txt_password_TextChanged(object sender, EventArgs e)
        {
            if( txt_password.Text != "Enter Password")
            {
                txt_password.PasswordChar = '*';
            }
        }

        private void btn_dashboard_Click(object sender, EventArgs e)
        {
            new AdminDashboard().Show();
            this.Close();
        }
    }
}
