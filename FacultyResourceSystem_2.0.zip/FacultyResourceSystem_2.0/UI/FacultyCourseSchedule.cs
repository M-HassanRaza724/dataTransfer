﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ComponentFactory.Krypton.Toolkit;
using Krypton_toolKit_Demo.BL;
using Krypton_toolKit_Demo.DL;

namespace Krypton_toolKit_Demo.UI
{
    public partial class FacultyCourseSchedule: KryptonForm
    {
        public static int? scheduleId = null;
        public static int faculty_course_id = 0;
        int facultyId;
        int UserRole;
        public FacultyCourseSchedule(int userRole = 3, int facultyId = 0)
        {
            InitializeComponent();
                this.UserRole = userRole;
            if (userRole == 2)
            {
                this.facultyId = facultyId;
            }
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            string name = null, sortby = null, direction = null , day = null;
            List<FacultyCourseScheduleDTO> faculty_schedule;
            // Get the item text
            // Get the item text
            ItemCheckListHandler handler = new ItemCheckListHandler(cbx_semester_term);
            List<string> semester_terms = handler.GetCheckedItems();
            ItemCheckListHandler handler2 = new ItemCheckListHandler(cbx_course_type);
            List<string> course_types = handler2.GetCheckedItems();

            if(cmbx_filter_day.Text != "Select Day")
                day = cmbx_filter_day.Text;

            if (txt_search_faculty_schedule.Text != "Search room/faculty")
                name = txt_search_faculty_schedule  .Text;

            else if (rdo_sort_semester_year.Checked)
                sortby = "fc.SemesterYear";
            else if (rdo_sort_course_name.Checked)
                sortby = "fc.CourseName";


            if (rdo_asc.Checked)
            {
                direction = "DESC";
            }
            else if (rdo_desc.Checked)
            {
                direction = "ASC";
            }
            if(UserRole == 2)
            {
                faculty_schedule = FacultyCourseScheduleCRUD.GetFacultyCourseSchedules(facultyId,name, day, semester_terms, course_types, sortby, direction);
            }
            else
                faculty_schedule = FacultyCourseScheduleCRUD.GetFacultyCourseSchedules(0,name, day, semester_terms, course_types, sortby, direction);
            facultyCourseScheduleDTOBindingSource.DataSource = faculty_schedule;
            dgv_faculty_course_schedule.DataSource = facultyCourseScheduleDTOBindingSource;
        }

        private void dgv_faculty_course_schedule_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                var cellValue = dgv_faculty_course_schedule.Rows[e.RowIndex].Cells["facultyCourseIdDataGridViewTextBoxColumn"].Value;
                faculty_course_id = Convert.ToInt32(cellValue);
            }
            if (e.RowIndex >= 0 && e.ColumnIndex == dgv_faculty_course_schedule.Columns["update"].Index)
            {
                var cellValue = dgv_faculty_course_schedule.Rows[e.RowIndex].Cells["scheduleIdDataGridViewTextBoxColumn"].Value;
                scheduleId = Convert.ToInt32(cellValue);

                var fs = FacultyCourseScheduleCRUD.GetFacultyCourseSchedule(scheduleId.Value);
                enableGroupBox(fs);
                //MessageBox.Show($"Delete button clicked in row: {e.RowIndex + 1}");
            }
            if (e.RowIndex >= 0 && e.ColumnIndex == dgv_faculty_course_schedule.Columns["delete"].Index)
            {
                var cellValue = dgv_faculty_course_schedule.Rows[e.RowIndex].Cells["scheduleIdDataGridViewTextBoxColumn"].Value;
                //IsDBNull(reader.GetOrdinal("FacultyCourseId")) ? (int?)null : reader.GetInt32(reader.GetOrdinal("FacultyCourseId"))
                if (cellValue != null && cellValue != DBNull.Value)
                {
                    scheduleId = Convert.ToInt32(cellValue);
                }
                FacultyCourseScheduleDTO.DeleteFacultyCourseSchedule(scheduleId.Value); //  delete
                scheduleId = null;
                btn_search_Click(sender, e);
                //MessageBox.Show($"Delete button clicked in row: {e.RowIndex + 1}");
            }
        }
        private void enableGroupBox(FacultyCourseScheduleDTO fs = null)
        {
            gbx_add_updt_faculty_course_schedule.Enabled = true;
            gbx_add_updt_faculty_course_schedule.Visible = true;
            List<string> rooms = RoomCRUD.GetRoomsNames();
            cmbx_room.Items.AddRange(rooms.ToArray());
            List<FacultyCourseDTO> facultyCourses = FacultyCourseDTO.GetFacultyCourses();
            cmbx_faculty_course.Items.AddRange(facultyCourses.ToArray());
            //List<> faculty_names = FacultyCRUD.GetFacultyNames();
            //cmbx_faculty_course.Items.AddRange(faculty_names.ToArray());

            if (scheduleId.HasValue)
            {
                cmbx_room.Text = fs.RoomName;
                cmbx_day.Text = fs.DayOfWeek;
                cmbx_faculty_course.Text = $"{fs.FacultyName}-{fs.CourseName}-{fs.CourseType}-{fs.SemesterTerm}-{fs.SemesterYear}";
                cmbx_start_time.Text = fs.StartTime.ToString();
                cmbx_end_time.Text = fs.EndTime.ToString();

                btn_add_updt.Text = "Update";
            }
        }
        private void disableGroupBox()
        {
            gbx_add_updt_faculty_course_schedule.Enabled = false;
            gbx_add_updt_faculty_course_schedule.Visible = false;
            cmbx_day.Text = "Select Day";
            cmbx_room.Text = "Select Room";
            cmbx_faculty_course.Text = "Select Course";
                cmbx_start_time.Text = "Select Start Time";
            cmbx_end_time.Text = "Select End Time";
            scheduleId = null;
            cmbx_faculty_course.Items.Clear();
            cmbx_room.Items.Clear();
            faculty_course_id = 0;
        }

        private void FacultyFacultyCourseScheduleForm_Load(object sender, EventArgs e)
        {
            //List<string> years = RoomCRUD.GetRoomYears();
            //cmbx_room.Items.AddRange(years.ToArray());
        }


        private void btn_add_updt_Click(object sender, EventArgs e)
        {
            try
            {
                int facultyCourseId = -1;
                if(cmbx_faculty_course.SelectedItem is FacultyCourseDTO selectedFacultyCourse)
                {
                    facultyCourseId = selectedFacultyCourse.FacultyCourseId;

                }
                    if (facultyCourseId == -1)
                    {
                        MessageBox.Show("Please select a valid faculty course.");
                        return;
                    }
                if (scheduleId.HasValue)
                {
                    FacultyCourseScheduleDTO fs = new FacultyCourseScheduleDTO
                        {
                        ScheduleId = scheduleId.Value,
                        StartTime = TimeSpan.Parse(cmbx_start_time.Text),
                        EndTime = TimeSpan.Parse(cmbx_end_time.Text),
                        FacultyCourseId = facultyCourseId,
                        DayOfWeek = cmbx_day.Text,
                                
                            RoomId = RoomCRUD.GetRoomId(cmbx_room.Text),
                        };
                        fs.UpdateFacultyCourseSchedule();
                }
                else
                {
                    FacultyCourseScheduleDTO fs = new FacultyCourseScheduleDTO
                    {
                        StartTime = TimeSpan.Parse(cmbx_start_time.Text),
                        EndTime = TimeSpan.Parse(cmbx_end_time.Text),
                        FacultyCourseId = facultyCourseId,
                        DayOfWeek = cmbx_day.Text,

                        RoomId = RoomCRUD.GetRoomId(cmbx_room.Text),
                    };
                    fs.AddFacultyCourseSchedule();

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                disableGroupBox();
                btn_search_Click(sender, e);
            }
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            disableGroupBox();
        }

        private void btn_dashboard_Click(object sender, EventArgs e)
        {
            new FacultyDashboard(facultyId).Show();
            this.Close();
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            enableGroupBox();
        }

        private void cmbx_start_time_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbx_start_time.SelectedItem is TimeSpan selectedTime)
            {
                List<TimeSpan> end_times = FacultyCourseScheduleDTO.GetValidTimes(selectedTime);
                foreach(TimeSpan e_time in end_times)
                {
                cmbx_end_time.Items.Add(e_time);
                }
            }
        }

        private void FacultyCourseSchedule_Load(object sender, EventArgs e)
        {
            if(UserRole == 2)
            {
                dgv_faculty_course_schedule.Columns["update"].Visible = false;
                dgv_faculty_course_schedule.Columns["delete"].Visible = false;
                //AddingNewEventArgs|.Visible = false;
                btn_add.Visible = false;
                btn_export.Visible = true;
                btn_add.Visible = false;

            }
            btn_search_Click(sender, e);
        }

        private void btn_dashboard_Click_1(object sender, EventArgs e)
        {
            if(UserRole == 2)
            {
                new FacultyDashboard(facultyId).Show();
            }
            else
            {
                new DepartmentHeadDashboard().Show();
            }
            this.Close();
        }

        private void btn_export_Click(object sender, EventArgs e)
        {
            new ScheduleReportForm(facultyId).Show();
        }
    }
}
