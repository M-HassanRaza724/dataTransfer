﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ComponentFactory.Krypton.Toolkit;
using Krypton_toolKit_Demo.BL;
using Krypton_toolKit_Demo.DL;

namespace Krypton_toolKit_Demo.UI
{
    public partial class ProjectSupervision: KryptonForm
    {
        static int? faculty_projectId = null;
        int facultyID = 0;
        int userRole;
        public ProjectSupervision(int userRole ,int facultyID = 0)
        {
            InitializeComponent();
            this.userRole = userRole;
            if (userRole == 2)
            {
                this.facultyID = facultyID;
            }
        }
        private void btn_search_Click(object sender, EventArgs e)
        {
            string name = null, sortby = null, direction = null;
            List<FacultyProjectSupervisionDTO> faculty_projects;
            // Get the item text
            // Get the item text
            ItemCheckListHandler handler = new ItemCheckListHandler(cbx_semester_term);
            List<string> semester_terms = handler.GetCheckedItems();


            if (txt_search_faculty_projects.Text != "Search project/faculty")
                name = txt_search_faculty_projects.Text;

            if (rdo_sort_faculty_name.Checked)
                sortby = "f.name";
            else if (rdo_sort_semester_year.Checked)
                sortby = "s.year";
            else if (rdo_sort_project_title.Checked)
                sortby = "p.title";


            if (rdo_asc.Checked)
            {
                direction = "DESC";
            }
            else if (rdo_desc.Checked)
            {
                direction = "ASC";
            }

            if(facultyID != 0)
            {
                faculty_projects = ProjectSupervisionCRUD.GetProjectSupervisions(name, semester_terms, sortby, direction, facultyID);
            }
            else
            {
                faculty_projects = ProjectSupervisionCRUD.GetProjectSupervisions(name, semester_terms, sortby, direction);
            }
            facultyProjectSupervisionDTOBindingSource.DataSource = faculty_projects;
            dgv_faculty_projects.DataSource = facultyProjectSupervisionDTOBindingSource;
        }

        private void dgv_faculty_projects_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //if (e.RowIndex >= 0)
            //{
            //    var cellValue = dgv_faculty_projects.Rows[e.RowIndex].Cells["facultyIdDataGridViewTextBoxColumn"].Value;
            //    faculty_id = Convert.ToInt32(cellValue);
            //}
            if (e.RowIndex >= 0 && e.ColumnIndex == dgv_faculty_projects.Columns["update"].Index)
            {
                var cellValue = dgv_faculty_projects.Rows[e.RowIndex].Cells["facultyProjectIdDataGridViewTextBoxColumn"].Value;
                faculty_projectId = Convert.ToInt32(cellValue);

                var fp = ProjectSupervisionCRUD.GetProjectSupervision(faculty_projectId.Value);
                enableGroupBox(fp);
                //MessageBox.Show($"Delete button clicked in row: {e.RowIndex + 1}");
            }
            if (e.RowIndex >= 0 && e.ColumnIndex == dgv_faculty_projects.Columns["delete"].Index)
            {
                var cellValue = dgv_faculty_projects.Rows[e.RowIndex].Cells["facultyProjectIdDataGridViewTextBoxColumn"].Value;
                //IsDBNull(reader.GetOrdinal("FacultyProjectId")) ? (int?)null : reader.GetInt32(reader.GetOrdinal("FacultyProjectId"))
                if (cellValue != null && cellValue != DBNull.Value)
                {
                    faculty_projectId = Convert.ToInt32(cellValue);
                }
                FacultyProjectSupervisionDTO.DeleteProjectSupervision(faculty_projectId.Value);
                faculty_projectId = null;
                btn_search_Click(sender, e);
                //MessageBox.Show($"Delete button clicked in row: {e.RowIndex + 1}");
            }
        }
        private void enableGroupBox(FacultyProjectSupervisionDTO fp = null)
        {
            gbx_add_updt_faculty_project.Enabled = true;
            gbx_add_updt_faculty_project.Visible = true;
            List<string> years = SemesterCRUD.GetSemesterYears();
            cmbx_semester_year.Items.AddRange(years.ToArray());
            List<string> projects = ProjectCRUD.GetProjectTitles();
            cmbx_project.Items.AddRange(projects.ToArray());
            List<string> faculty_names = FacultyCRUD.GetFacultyNames();
            cmbx_faculty_name.Items.AddRange(faculty_names.ToArray());

            if (faculty_projectId.HasValue)
            {
                    cmbx_semester_year.Text = fp.SemesterYear.ToString();
                cmbx_semester_term.Text = fp.SemesterTerm ;
                cmbx_project.Text = fp.ProjectTitle;
                txt_supervision_hours.Text = fp.SupervisionHours.ToString();
                cmbx_faculty_name.Text = fp.FacultyName;

                btn_add_updt.Text = "Update";
            }
        }
        private void disableGroupBox()
        {
            gbx_add_updt_faculty_project.Enabled = false;
            gbx_add_updt_faculty_project.Visible = false;
            cmbx_semester_year.Text = "Select Year";
            cmbx_semester_term.Text = "Select Term";
            cmbx_project.Text = "Select Project";
            txt_supervision_hours.Text = "Select Type";
            faculty_projectId = null;
            cmbx_project.Items.Clear();
            cmbx_semester_year.Items.Clear();
            cmbx_faculty_name.Items.Clear();
            faculty_projectId = null;
        }

        private void FacultyProjectSupervisionForm_Load(object sender, EventArgs e)
        {
            //List<string> years = SemesterCRUD.GetSemesterYears();
            //cmbx_semester_year.Items.AddRange(years.ToArray());
            if (userRole == 2)
            {
                MessageBox.Show("Legged in as faculty member");
                btn_add.Visible = false;
                btn_add.Enabled = false;
                dgv_faculty_projects.Columns["update"].Visible = false;
                dgv_faculty_projects.Columns["delete"].Visible = false;
                btn_add.Visible = false;

                //Add.Visible = false
            }
            btn_search_Click(sender, e);
        }

        private void cmbx_semester_year_SelectedIndexChanged(object sender, EventArgs e)
        {
            int selectedValue = Convert.ToInt32(cmbx_semester_year.Text);
            List<string> terms = SemesterCRUD.GetSemesterTerms(selectedValue);
            cmbx_semester_term.Items.Clear();
            cmbx_semester_term.Items.AddRange(terms.ToArray());
        }


        private void btn_add_updt_Click(object sender, EventArgs e)
        {
            try
            {

                if (faculty_projectId.HasValue)
                {
                    if (faculty_projectId.HasValue)
                    {
                        FacultyProjectSupervisionDTO fp = new FacultyProjectSupervisionDTO
                        {
                            ProjectTitle = cmbx_project.Text,

                            FacultyProjectId = faculty_projectId.Value,
                            SemesterId = SemesterCRUD.GetSemesterId(Convert.ToInt32(cmbx_semester_year.Text), cmbx_semester_term.Text),
                            ProjectId = ProjectCRUD.GetProjectId(cmbx_project.Text),
                            FacultyId = FacultyCRUD.GetFacultyId(cmbx_faculty_name.Text),
                            SupervisionHours = Convert.ToInt32(txt_supervision_hours.Text)
                        };
                        fp.UpdateProjectSupervision();
                    }
                }
                else
                {
                    FacultyProjectSupervisionDTO fp = new FacultyProjectSupervisionDTO
                    {
                        ProjectTitle = cmbx_project.Text,
                        SemesterId = SemesterCRUD.GetSemesterId(Convert.ToInt32(cmbx_semester_year.Text), cmbx_semester_term.Text),
                        //SemesterYear = Convert.ToInt32(cmbx_semester_year.Text),
                        ProjectId = ProjectCRUD.GetProjectId(cmbx_project.Text),
                        FacultyId = FacultyCRUD.GetFacultyId(cmbx_faculty_name.Text),
                            SupervisionHours = Convert.ToInt32(txt_supervision_hours.Text)

                    };
                    fp.AddProjectSupervision();

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                disableGroupBox();
                btn_search_Click(sender, e);
            }
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            disableGroupBox();
        }

        private void btn_dashboard_Click(object sender, EventArgs e)
        {
            if(userRole == 3)
                new DepartmentHeadDashboard().Show();
            else if (userRole == 2)
                new FacultyDashboard(facultyID).Show();
            this.Close();
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            enableGroupBox();
        }

        
    }
}
