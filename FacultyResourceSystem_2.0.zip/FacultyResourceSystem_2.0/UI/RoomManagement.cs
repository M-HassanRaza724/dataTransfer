﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using ComponentFactory.Krypton.Toolkit;
using Krypton_toolKit_Demo.BL;
using Krypton_toolKit_Demo.DL;

namespace Krypton_toolKit_Demo.UI
{
    public partial class RoomManagement : KryptonForm
    {
        static Room room { get; set; }
        int userRole;
        public RoomManagement()
        {
            InitializeComponent();
        }

        private void RoomManagement_Load(object sender, EventArgs e)
        {
            btn_search_Click(sender, e);
        }
        static string itemType;
        private void btn_search_Click(object sender, EventArgs e)
        {
            string name = null, sortby = null, direction = null;
            List<Room> rooms;
            // Get the item text


            if (txt_search_rooms.Text != "Search rooms")
                name = txt_search_rooms.Text;

            if (rdo_sort1.Checked)
                sortby = "room_id";
            else if (rdo_sort2.Checked)
                sortby = "capacity";
            else
                sortby = null;

            if (rdo_asc.Checked)
            {
                direction = "DESC";
            }
            else if (rdo_desc.Checked)
            {
                direction = "ASC";
            }

            //MessageBox.Show($"name is {name}, type is {itemType}, sort is {sortby}");
            rooms = RoomCRUD.GetAllRooms(name, itemType, sortby, direction);

            RoomBindingSource.DataSource = rooms;
            dgv_rooms.DataSource = RoomBindingSource;
            //dgv_rooms.Refresh();
            MessageBox.Show("Data Loaded Successfully");
        }

        private void dgv_rooms_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex == dgv_rooms.Columns["update"].Index)
            {
                var cellValue = dgv_rooms.Rows[e.RowIndex].Cells["roomidDataGridViewTextBoxColumn"].Value;
                int roomId = Convert.ToInt32(cellValue);
                room = RoomCRUD.GetRoomFromDB(roomId);
                enableGroupBox();
                //MessageBox.Show($"Update button clicked in row: {e.RowIndex + 1}");
            }
            if (e.RowIndex >= 0 && e.ColumnIndex == dgv_rooms.Columns["delete"].Index)
            {
                var cellValue = dgv_rooms.Rows[e.RowIndex].Cells["roomidDataGridViewTextBoxColumn"].Value;
                int roomId = Convert.ToInt32(cellValue);

                Room.DeleteRoom(roomId);
                btn_search_Click(sender, e);
                //Handle button click
                //MessageBox.Show($"Delete button clicked in row: {e.RowIndex + 1}");
            }
        }

        private void cbx_type_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            // Get the current state of the items
            bool isItem1Checked = cbx_type.GetItemChecked(0);
            bool isItem2Checked = cbx_type.GetItemChecked(1);

            // Determine the new state after the current change
            if (e.Index == 0)
            {
                isItem1Checked = (e.NewValue == CheckState.Checked);
            }
            else if (e.Index == 1)
            {
                isItem2Checked = (e.NewValue == CheckState.Checked);
            }

            // Logic to determine the return value
            if (isItem1Checked && isItem2Checked)
            {
                // Both items are checked
                itemType = null;
                //MessageBox.Show("Returning: null (both items are checked)");
            }
            else if (!isItem1Checked && !isItem2Checked)
            {
                // Both items are unchecked
                itemType = null;
                //MessageBox.Show("Returning: null (both items are unchecked)");
            }
            else
            {
                // Only one item is checked
                string checkedItemText = isItem1Checked ? cbx_type.Items[0].ToString() : cbx_type.Items[1].ToString();
                itemType = checkedItemText;
                //MessageBox.Show($"Returning: {checkedItemText}");
            }
        }

        private void txt_search_rooms_Leave(object sender, EventArgs e)
        {
            if (txt_search_rooms.Text == "")
                txt_search_rooms.Text = "Search rooms";
        }

        private void txt_search_rooms_Enter(object sender, EventArgs e)
        {
            if (txt_search_rooms.Text == "Search rooms")
                txt_search_rooms.Text = "";
        }

        private void lbl_credit_hours_Click(object sender, EventArgs e)
        {

        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            gbx_add_updt_room.Enabled = true;
            gbx_add_updt_room.Visible = true;


        }

        private void txt_room_name_Leave(object sender, EventArgs e)
        {
            if (txt_room_name.Text == "")
                txt_room_name.Text = "Enter Room Name";
        }

        private void txt_room_name_Enter(object sender, EventArgs e)
        {
            if (txt_room_name.Text == "Enter Room Name")
                txt_room_name.Text = "";
        }

        private void txt_capacity_Leave(object sender, EventArgs e)
        {
            if (txt_capacity.Text == "")
                txt_capacity.Text = "Enter Room Capacity";
        }

        private void txt_capacity_Enter(object sender, EventArgs e)
        {
            if (txt_capacity.Text == "Enter Room Capacity")
                txt_capacity.Text = "";
        }

        private void btn_add_updt_Click(object sender, EventArgs e)
        {
            if (btn_add_updt.Text == "Update")
            {
                try
                {
                    Room r = new Room(txt_room_name.Text, rdo_theory.Checked ? "Classroom" : "Lab", Convert.ToInt32(txt_capacity.Text), room.room_id);
                    r.UpdateRoom();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {

                try
                {
                    Room r = new Room(txt_room_name.Text, rdo_theory.Checked ? "Classroom" : "Lab", Convert.ToInt32(txt_capacity.Text));
                    r.AddRoom();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            btn_search_Click(sender, e);
            disableGroupBox();

        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            disableGroupBox();
        }
        private void enableGroupBox()
        {
            gbx_add_updt_room.Enabled = true;
            gbx_add_updt_room.Visible = true;
            if (room != null)
            {
                txt_room_name.Text = room.room_name;
                txt_capacity.Text = room.capacity.ToString();
                if (room.room_type == "Classroom")
                    rdo_theory.Checked = true;
                else
                    rdo_lab.Checked = true;
                gbx_add_updt_room.Text = "Update Room";
                btn_add_updt.Text = "Update";
                gbx_add_updt_room.Refresh();

            }
       
        }
        private void disableGroupBox()
        {
            gbx_add_updt_room.Enabled = false;
            gbx_add_updt_room.Visible = false;
            room = null;
            txt_room_name.Text = "Enter Room Name";
            txt_capacity.Text = "Enter Room Capacity";
            rdo_theory.Checked = true;
            gbx_add_updt_room.Text = "Add Room";
            btn_add_updt.Text = "Add";
            gbx_add_updt_room.Refresh();
        }

        private void btn_dashboard_Click(object sender, EventArgs e)
        {
            new AdminDashboard().Show();
            this.Close();
        }
    }
}
