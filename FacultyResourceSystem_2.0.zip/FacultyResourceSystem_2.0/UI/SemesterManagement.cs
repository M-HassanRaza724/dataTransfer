﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using ComponentFactory.Krypton.Toolkit;
using Krypton_toolKit_Demo.BL;
using Krypton_toolKit_Demo.DL;

namespace Krypton_toolKit_Demo.UI
{
    public partial class SemesterManagement : KryptonForm
    {
        static Semester semester { get; set; }
        public SemesterManagement()
        {
            InitializeComponent();
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            int year = 0;
            string sortby = null, direction = null;
            // Get the item text

            ItemCheckListHandler handler = new ItemCheckListHandler(cbx_term);
            List<string> checkedterms = handler.GetCheckedItems();

            if (txt_search_sems.Text != "Search semesters")
            {
                try
                {
                    year = Convert.ToInt32(txt_search_sems.Text);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Please enter a valid year");
                    return;
                }
            }

            if (rdo_sort_year.Checked)
                sortby = "year";
            else if (rdo_sort_id.Checked)
                sortby = "semester_id";

            if (rdo_asc.Checked)
            {
                direction = "DESC";
            }
            else if (rdo_desc.Checked)
            {
                direction = "ASC";
            }
            List<Semester> sems = SemesterCRUD.GetSemesters(year, checkedterms, sortby, direction);

            semesterBindingSource.DataSource = sems;
            dgv_sems.DataSource = semesterBindingSource;
            dgv_sems.Refresh();
            MessageBox.Show("Data Loaded Successfully");
        }
        private void SemesterManagement_Load(object sender, EventArgs e)
        {
            btn_search_Click(sender, e);
        }

        private void btn_add_updt_Click(object sender, EventArgs e)
        {
            if(btn_add_updt.Text == "Update")
            {
                try
                {
                    string term = null;
                    if (rdo_fall.Checked) term = "Fall";
                    else if (rdo_spring.Checked) term = "Spring";
                    else if (rdo_summer.Checked) term = "Summer";
                    Semester s = new Semester(term, Convert.ToInt32(txt_sem_year.Text),semester.semester_id);
                    s.UpdateSemester();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Please enter a valid year");
                    return;
                }
            }
            else
            {

                try
                {
                    string term = null;
                    if (rdo_fall.Checked) term = "Fall";
                    else if (rdo_spring.Checked) term = "Spring";
                    else if (rdo_summer.Checked) term = "Summer";
                    Semester s = new Semester(term, Convert.ToInt32(txt_sem_year.Text));
                    s.AddSemester();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Please enter a valid year");
                    return;
                }
            }
            btn_search_Click(sender, e);
            disableGroupBox();
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            disableGroupBox();
        }


        private void btn_add_Click(object sender, EventArgs e)
        {
            enableGroupBox();
        }
        private void enableGroupBox()
        {
            gbx_add_updt_sem.Enabled = true;
            gbx_add_updt_sem.Visible = true;
            if (semester != null)
            {
                txt_sem_year.Text = semester.year.ToString();
                if (semester.term == "Fall")
                    rdo_fall.Checked = true;
                else if (semester.term == "Spring")
                    rdo_spring.Checked = true;
                else if (semester.term == "Summer")
                    rdo_summer.Checked = true;
                gbx_add_updt_sem.Text = "Update Room";
                btn_add_updt.Text = "Update";
                gbx_add_updt_sem.Refresh();

            }
        }


        private void dgv_sems_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex == dgv_sems.Columns["update"].Index)
            {
                var cellValue = dgv_sems.Rows[e.RowIndex].Cells["semesteridDataGridViewTextBoxColumn"].Value;
                int semId = Convert.ToInt32(cellValue);
                semester = SemesterCRUD.GetSemesterFromDB(semId);
                enableGroupBox();

                //MessageBox.Show($"Update button clicked in row: {e.RowIndex + 1}");
            }
            if (e.RowIndex >= 0 && e.ColumnIndex == dgv_sems.Columns["delete"].Index)
            {
                var cellValue = dgv_sems.Rows[e.RowIndex].Cells["semesteridDataGridViewTextBoxColumn"].Value;
                int semId = Convert.ToInt32(cellValue);

                Semester.DeleteSemester(semId);
                btn_search_Click(sender, e);
                //Handle button click
                //MessageBox.Show($"Delete button clicked in row: {e.RowIndex + 1}");
            }
        }
        private void disableGroupBox()
        {
            gbx_add_updt_sem.Enabled = false;
            gbx_add_updt_sem.Visible = false;
            btn_add_updt.Text = "Add";
            semester = null;
            rdo_fall.Checked = true;
            txt_sem_year.Text = "Enter Semester year";

        }

        private void btn_dashboard_Click(object sender, EventArgs e)
        {
            new AdminDashboard().Show();
            this.Close();
        }
    }
}
