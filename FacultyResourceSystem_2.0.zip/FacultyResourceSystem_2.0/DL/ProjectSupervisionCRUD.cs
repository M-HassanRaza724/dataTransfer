﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using Krypton_toolKit_Demo.BL;
using static Mysqlx.Crud.Order.Types;

namespace Krypton_toolKit_Demo.DL
{
    static public class ProjectSupervisionCRUD
    {
        public static void AddProjectSupervision(FacultyProjectSupervisionDTO fps)
        {
            string query = $"INSERT INTO faculty_projects (faculty_id, project_id, semester_id, supervision_hours) VALUES ({fps.FacultyId}, {fps.ProjectId}, {fps.SemesterId}, {fps.SupervisionHours})";
            DatabaseHelper.Instance.Update(query);
        }
        public static void UpdateProjectSupervision(FacultyProjectSupervisionDTO fps)
        {
            string query = $"UPDATE faculty_projects SET project_id = {fps.ProjectId}, semester_id = {fps.SemesterId}, supervision_hours = {fps.SupervisionHours} where faculty_project_id = {fps.FacultyProjectId};";
            DatabaseHelper.Instance.Update(query);
        }
        public static void DeleteProjectSupervision(int facultyProjectId)
        {
            string query = $"DELETE FROM faculty_projects WHERE faculty_project_id = {facultyProjectId}";
            DatabaseHelper.Instance.Update(query);
        }
        public static FacultyProjectSupervisionDTO GetProjectSupervision(int facultyProjectId)
        {
            string query = $"SELECT fp.faculty_project_id AS FacultyProjectId, fp.faculty_id AS FacultyId, f.name AS FacultyName, fp.project_id AS ProjectId, p.title AS ProjectTitle, p.description AS ProjectDescription, fp.semester_id AS SemesterId, s.term AS SemesterTerm, s.year AS SemesterYear, fp.supervision_hours AS SupervisionHours FROM faculty_projects fp NATURAL JOIN faculty f Natural JOIN projects p Natural JOIN semesters s  WHERE faculty_project_id = {facultyProjectId}";
            using (var reader = DatabaseHelper.Instance.getData(query))
            {
                if (reader.Read())
                {
                    return  new FacultyProjectSupervisionDTO
                    {
                        FacultyProjectId = reader.GetInt32(reader.GetOrdinal("FacultyProjectId")),
                        FacultyId = reader.GetInt32(reader.GetOrdinal("FacultyId")),
                        FacultyName = reader.GetString(reader.GetOrdinal("FacultyName")),
                        ProjectId = reader.GetInt32(reader.GetOrdinal("ProjectId")),
                        ProjectTitle = reader.GetString(reader.GetOrdinal("ProjectTitle")),
                        ProjectDescription = reader.IsDBNull(reader.GetOrdinal("ProjectDescription"))
                                    ? null
                                    : reader.GetString(reader.GetOrdinal("ProjectDescription")),
                        SemesterId = reader.GetInt32(reader.GetOrdinal("SemesterId")),
                        SemesterTerm = reader.GetString(reader.GetOrdinal("SemesterTerm")),
                        SemesterYear = reader.GetInt32(reader.GetOrdinal("SemesterYear")),
                        SupervisionHours = reader.GetInt32(reader.GetOrdinal("SupervisionHours"))
                    };
                }return null;
            }
        }
        public static List<FacultyProjectSupervisionDTO> GetProjectSupervisions(string name = null, List<string> semester_terms = null,  string sortby = null, string direction = null,int facultyId = 0)
        {
            string query = "SELECT fp.faculty_project_id AS FacultyProjectId, fp.faculty_id AS FacultyId, f.name AS FacultyName, fp.project_id AS ProjectId, p.title AS ProjectTitle, p.description AS ProjectDescription, fp.semester_id AS SemesterId, s.term AS SemesterTerm, s.year AS SemesterYear, fp.supervision_hours AS SupervisionHours FROM faculty_projects fp NATURAL JOIN faculty f Natural JOIN projects p Natural JOIN semesters s where 1=1";
            if(facultyId != 0)
            {
                query += $" AND f.faculty_id = {facultyId}";
            }

            if (!string.IsNullOrEmpty(name))
                query += $" AND (f.name LIKE '%{name}%' or p.title LIKE '%{name}%')";
            if (semester_terms != null && semester_terms.Count > 0)
            {
                string filter = string.Join("', '", semester_terms);
                query += $" AND s.term IN ('{filter}')";
            }
            // Handle sortb
            if (!string.IsNullOrEmpty(sortby))
                query += $" ORDER BY {sortby}";
            if (!string.IsNullOrEmpty(direction))
                query += $" {direction}";
            //MessageBox.Show(query);



            List<FacultyProjectSupervisionDTO> fps = new List<FacultyProjectSupervisionDTO>();
            using (var reader = DatabaseHelper.Instance.getData(query))
            {
                while (reader.Read())
                {
                    fps.Add(new FacultyProjectSupervisionDTO
                    {
                        FacultyProjectId = reader.GetInt32(reader.GetOrdinal("FacultyProjectId")),
                        FacultyId = reader.GetInt32(reader.GetOrdinal("FacultyId")),
                        FacultyName = reader.GetString(reader.GetOrdinal("FacultyName")),
                        ProjectId = reader.GetInt32(reader.GetOrdinal("ProjectId")),
                        ProjectTitle = reader.GetString(reader.GetOrdinal("ProjectTitle")),
                        ProjectDescription = reader.IsDBNull(reader.GetOrdinal("ProjectDescription"))
                                    ? null
                                    : reader.GetString(reader.GetOrdinal("ProjectDescription")),
                        SemesterId = reader.GetInt32(reader.GetOrdinal("SemesterId")),
                        SemesterTerm = reader.GetString(reader.GetOrdinal("SemesterTerm")),
                        SemesterYear = reader.GetInt32(reader.GetOrdinal("SemesterYear")),
                        SupervisionHours = reader.GetInt32(reader.GetOrdinal("SupervisionHours"))
                    });
                }
            }
            return fps;
        }
    }
}
