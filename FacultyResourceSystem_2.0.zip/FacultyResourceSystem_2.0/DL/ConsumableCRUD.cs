﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using Krypton_toolKit_Demo.BL;
using static Mysqlx.Crud.Order.Types;
using System.Windows;

namespace Krypton_toolKit_Demo.DL
{
    class ConsumableCRUD
    {
        public static List<Consumable> GetConsumables(string name = null,string sortby = null,string direction = null)
        {
            List<Consumable> consumables = new List<Consumable>();
            string query = "SELECT * FROM Consumables where 1=1";
            if (!string.IsNullOrEmpty(name))
                query += $" AND item_name LIKE '%{name}%'";
            if (sortby != null)
            {
                query += $" ORDER BY {sortby}";
                if (direction != null)
                    query += $" {direction}";
            }
            //MessageBox.Show($"{query}. Name: {name}");
            MySqlDataReader reader = DatabaseHelper.Instance.getData(query);
            while (reader.Read())
            {
                consumables.Add(new Consumable(Convert.ToInt32(reader["consumable_id"]), reader["item_name"].ToString()));
            }
            return consumables;
        }
        public static void AddConsumable(Consumable c)
        {
            string query = $"INSERT INTO Consumables (consumable_id, item_name) VALUES ( {c.consumable_id},'{c.item_name}')";
            DatabaseHelper.Instance.Update(query);
        }
        public static void UpdateConsumable(Consumable c)
        {
            string query = $"UPDATE Consumables SET item_name = '{c.item_name}' WHERE consumable_id = {c.consumable_id}";
            DatabaseHelper.Instance.Update(query);
        }
        public static void DeleteConsumable(int consumableId)
        {
            string query = $"DELETE FROM Consumables WHERE consumable_id = {consumableId}";
            DatabaseHelper.Instance.Update(query);
        }
        public static Consumable GetConsumable(int consumable_id)
        {
            string query = $"SELECT * FROM Consumables WHERE consumable_id = {consumable_id}";
            MySqlDataReader reader = DatabaseHelper.Instance.getData(query);
            if (reader.Read())
            {
                return new Consumable(Convert.ToInt32(reader["consumable_id"]), reader["item_name"].ToString());
            }
            return null;
        }
        public static int GetConsumableId(string item)
        {
            string query = $"SELECT consumable_id FROM Consumables WHERE item_name = '{item}'";
            MySqlDataReader reader = DatabaseHelper.Instance.getData(query);
            if (reader.Read())
            {
                return Convert.ToInt32(reader["consumable_id"]);
            }
            return -1;
        }
    }
}
