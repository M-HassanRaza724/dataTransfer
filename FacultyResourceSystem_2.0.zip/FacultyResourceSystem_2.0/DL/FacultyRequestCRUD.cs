﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using Krypton_toolKit_Demo.BL;
using Mysqlx.Crud;
using System.Windows;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using Microsoft.ReportingServices.ReportProcessing.OnDemandReportObjectModel;
using System.Reflection;
using System.Windows.Controls.Primitives;

namespace Krypton_toolKit_Demo.DL

{
    public class FacultyRequestCRUD
    {
        public static void AddFacultyRequest(FacultyRequestDTO fr)
        {
            string formattedDate = fr.request_date.ToString("yyyy-MM-dd HH:mm:ss");

            string query = $"INSERT INTO `faculty_requests` (`faculty_id`, `item_id`, `quantity`, `status_id`, `request_date`) VALUES({fr.faculty_id}, {fr.item_id}, {fr.quantity}, {fr.status_id} , '{formattedDate}')";
            //MessageBox.Show(query);
            DatabaseHelper.Instance.Update(query);
        }
        public static void UpdateFacultyRequest(FacultyRequestDTO fr)
        {
            string query = $"UPDATE `faculty_requests` SET `faculty_id` = {fr.faculty_id}, `item_id` = {fr.item_id}, `quantity` = {fr.quantity}, `status_id` = {fr.status_id}, `request_date` = '{fr.request_date}' WHERE `request_id` = {fr.request_id}";
            DatabaseHelper.Instance.Update(query);
        }
        public static void DeleteFacultyRequest(int requestId)
        {
            string query = $"DELETE FROM `faculty_requests` WHERE `request_id` = {requestId}";
            DatabaseHelper.Instance.Update(query);
        }
        public static FacultyRequestDTO GetFacultyRequest(int requestId)
        {
            string query = $"SELECT * FROM `faculty_requests` WHERE `request_id` = {requestId}";
            MySqlDataReader reader = DatabaseHelper.Instance.getData(query);
            if (reader.Read())
            {
                FacultyRequestDTO fr = new FacultyRequestDTO(reader["item_id"].ToString(), Convert.ToInt32(reader["quantity"]), reader["status_id"].ToString(), reader.GetDateTime(4));
                fr.request_id = Convert.ToInt32(reader["request_id"]);
                fr.faculty_id = Convert.ToInt32(reader["faculty_id"]);
                return fr;
            }
            return null;
        }
        public static List<FacultyRequestDTO> GetFacultyRequests(int facultyId = 0, string name = null, List<string> statuses = null,string sortby = null, string direction = null)
        {
            List<FacultyRequestDTO> facultyRequests = new List<FacultyRequestDTO>();
            string query = "SELECT name, request_id, item_name Item, quantity Quantity, value AS Status, request_date RequestDate FROM faculty_requests NATURAL JOIN faculty INNER JOIN consumables ON consumable_id = item_id INNER JOIN lookup ON status_id = lookup_id where 1=1";
            if (facultyId != 0)
                query += $" and faculty_id = {facultyId}";
            if (!string.IsNullOrEmpty(name))
                query += $" AND item_name LIKE '%{name}%'";
            if (statuses != null && statuses.Count > 0)
            {
                string filter = string.Join("', '", statuses);
                query += $" AND value IN ('{filter}')";
            }
            // Handle sortb
            if (!string.IsNullOrEmpty(sortby))
                query += $" ORDER BY {sortby}";
            if (!string.IsNullOrEmpty(direction))
                query += $" {direction}";
            //MessageBox.Show(query);
            MySqlDataReader reader = DatabaseHelper.Instance.getData(query);
            while (reader.Read())
            {
                FacultyRequestDTO fr = new FacultyRequestDTO($"{reader["item"]}", Convert.ToInt32(reader["quantity"]), $"{reader["Status"]}", reader.GetDateTime(5), reader.GetInt32(1));
                fr.faculty_name = reader.GetString(0);
                //fr.request_id = Convert.ToInt32(reader["request_id"]);
                //fr.faculty_id = Convert.ToInt32(reader["faculty_id"]);
                //fr.item_id = Convert.ToInt32(reader["item_id"]);
                //fr.status_id = Convert.ToInt32(reader["status_id"]);
                facultyRequests.Add(fr);
            }
            return facultyRequests;
        }

        public static void UpdateFacultyRequest(int requestId, int statusId)
        {
            string query = $"UPDATE `faculty_requests` SET `status_id` = {statusId} WHERE `request_id` = {requestId}";
            DatabaseHelper.Instance.Update(query);
        }
    }
}
