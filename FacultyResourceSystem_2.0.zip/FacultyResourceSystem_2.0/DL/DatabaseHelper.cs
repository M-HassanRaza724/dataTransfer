﻿using MySql.Data.MySqlClient;
using System;
using System.Configuration;
using System.Data.SqlClient;

namespace Krypton_toolKit_Demo
{
    public class DatabaseHelper
    {
        private String serverName = "127.0.0.1";
        private String port = "3306";
        private String databaseName = "faculty";
        private String databaseUser = "root";
        private String databasePassword = "`1234567890-=";

        private DatabaseHelper() { }

        private static DatabaseHelper _instance;
        public static DatabaseHelper Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new DatabaseHelper();
                return _instance;
            }
        }
        public MySqlConnection getConnection()
        {
            string connectionString = $"server={serverName};port={port};user={databaseUser};database ={databaseName}; password ={databasePassword}; SslMode = Required; ";
            var connection = new MySqlConnection(connectionString);
            connection.Open();



            return connection;
        }

        public MySqlDataReader getData(string query, MySqlParameter[] parameters = null)
        {
            using (var connection = getConnection())
            {
                using (var cmd = new MySqlCommand(query, getConnection()))
                {
                    if (parameters != null)
                        cmd.Parameters.AddRange(parameters);
                    return cmd.ExecuteReader();
                }
            }

        }

        public int Update(string query, MySqlParameter[] parameters = null)
        {
            using (var connection = getConnection())
            {
                using (var cmd = new MySqlCommand(query, getConnection()))
                {
                    if (parameters != null)
                        cmd.Parameters.AddRange(parameters);
                    return cmd.ExecuteNonQuery();
                }
            }

        }
    }

}
        //public static void ExecuteNonQuery(string query, MySqlParameter[] parameters = null)
        //{
        //    using (MySqlConnection conn = GetConnection())
        //    {
        //        conn.Open();
        //    }
        //}

        //public static MySqlDataReader ExecuteReader(string query, MySqlParameter[] parameters = null)
        //{
        //    MySqlConnection conn = GetConnection();
        //    conn.Open();
        //    MySqlCommand cmd = new MySqlCommand(query, conn);
        //    if (parameters != null)
        //        cmd.Parameters.AddRange(parameters);
        //    return cmd.ExecuteReader(System.Data.CommandBehavior.CloseConnection);
        //}