﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using Krypton_toolKit_Demo.BL;
using System.Globalization;
using System.Xml.Linq;

namespace Krypton_toolKit_Demo.DL
{
    static class RoomCRUD
    {
        public static void AddRoomToDB(Room r)
        {
            string query = $"INSERT INTO Rooms (room_id, room_name, room_type, capacity) VALUES ({r.room_id}, '{r.room_name}', '{r.room_type}', {r.capacity})";
            DatabaseHelper.Instance.Update(query);
        }
        public static void DeleteRoomFromDB(int roomId)
        {
            string query = $"DELETE FROM Rooms WHERE room_id = {roomId}";
            DatabaseHelper.Instance.Update(query);
        }
        public static void UpdateRoomInDB(Room r)
        {
            string query = $"UPDATE Rooms SET room_name = '{r.room_name}', room_type = '{r.room_type}', capacity = {r.capacity} WHERE room_id = {r.room_id}";
            DatabaseHelper.Instance.Update(query);
        }
        public static Room GetRoomFromDB(int room_id)
        {
            string query = $"SELECT * FROM Rooms WHERE room_id = '{room_id}'";
            MySqlDataReader reader = DatabaseHelper.Instance.getData(query);
            if (reader.Read())
            {
                return new Room(reader["room_name"].ToString(), reader["room_type"].ToString(), Convert.ToInt32(reader["capacity"]), Convert.ToInt32(reader["room_id"]));
            }
            return null;
        }
        public static List<Room> GetAllRooms(string name = null, string type = null, string sortby = null, string direction = null)
        {
            List<Room> rooms = new List<Room>();
            string query = "SELECT * FROM Rooms where 1=1";
            if (!string.IsNullOrEmpty(name))
                query += $" AND room_name LIKE '%{name}%'";

            // Handle type
            if (!string.IsNullOrEmpty(type))
                query += $" AND room_type = '{type}'";

            // Handle sortby
            if (!string.IsNullOrEmpty(sortby))
                query += $" ORDER BY {sortby}";
            if (!string.IsNullOrEmpty(direction))
                query += $" {direction}";
            MySqlDataReader reader = DatabaseHelper.Instance.getData(query);
            while (reader.Read())
            {
                Room room = new Room(reader["room_name"].ToString(), reader["room_type"].ToString(), Convert.ToInt32(reader["capacity"]), Convert.ToInt32(reader["room_id"]));
                rooms.Add(room);
            }
            return rooms;
        }
        public static List<string> GetRoomsNames()
        {
            List<string> rooms = new List<string>();
            string query = "SELECT Distinct room_name FROM Rooms";
            MySqlDataReader reader = DatabaseHelper.Instance.getData(query);
            while (reader.Read())
            {
                rooms.Add(reader["room_name"].ToString());
            }
            return rooms;
        }
        public static List<string> GetRoomTypes(string room_name)
        {
            List<string> rooms = new List<string>();
            string query = $"SELECT Distinct room_type FROM Rooms WHERE room_name = '{room_name}'";
            MySqlDataReader reader = DatabaseHelper.Instance.getData(query);
            while (reader.Read())
            {
                rooms.Add(reader["room_type"].ToString());
            }
            return rooms;
        }
        public static int GetRoomId(string roomName)
        {
            string query = $"SELECT room_id FROM Rooms WHERE room_name = '{roomName}'";
            MySqlDataReader reader = DatabaseHelper.Instance.getData(query);
            if (reader.Read())
            {
                return Convert.ToInt32(reader["room_id"]);
            }
            return 0;
        }
    }
}
