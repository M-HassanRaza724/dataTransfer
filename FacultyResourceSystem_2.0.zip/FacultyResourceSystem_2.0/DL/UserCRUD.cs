﻿using MySql.Data.MySqlClient;
using Newtonsoft.Json.Linq;
using Org.BouncyCastle.Tls;
using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls.Primitives;

namespace Krypton_toolKit_Demo.DL
{
    class UserCRUD
    {
        public static void AddUser(User user)
        {
            try
            {
                string query = $"INSERT INTO users (username, password_hash, email, role_id) VALUES ('{user.Name}', '{user.Password}', '{user.Email}', {user.RoleId})";
                DatabaseHelper.Instance.Update(query);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public static void UpdateUser(User user)
        {
            try
            {

                string query;
                if (user.RoleId == 0)
                    query = $"UPDATE users SET password_hash = '{user.Password}' WHERE email = '{user.Email}' and username = '{user.Name}'";
                else
                    query = $"UPDATE users SET username = '{user.Name}', password_hash = '{user.Password}', role_id = {user.RoleId} ,email = '{user.Email}' WHERE user_id = {user.UserId}";
                DatabaseHelper.Instance.Update(query);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public static void DeleteUser(int userId)
        {
            string query = $"DELETE FROM users WHERE user_id = {userId}";
            DatabaseHelper.Instance.Update(query);
        }
        //public static User GetUser(string email)
        //{
        //    string query = $"SELECT * FROM users WHERE email = '{email}'";
        //    MySqlDataReader reader = DatabaseHelper.Instance.getData(query);
        //    if (reader.Read())
        //    {
        //        return new User(reader["username"].ToString(), reader["password_hash"].ToString(), reader["email"].ToString(), Convert.ToInt32(reader["role_id"]));
        //    }
        //    return null;
        //}
        public static List<User> GetUsers(string username = null, List<string> roles = null, string sortby = null, string direction = null)
        {
            List<User> users = new List<User>();
            List<JObject> u;
            string query = "SELECT  user_id, username, email, password_hash, value FROM users inner join lookup where lookup_id = role_id";
            if (!string.IsNullOrEmpty(username))
                query += $" AND username LIKE '%{username}%'";
            if (roles != null && roles.Count > 0)
            {
                string filter = string.Join("', '", roles);
                query += $" AND value IN ('{filter}')";
            }
            if (!string.IsNullOrEmpty(sortby))
                query += $" ORDER BY {sortby}";
            if (!string.IsNullOrEmpty(direction))
                query += $" {direction}";
            //MessageBox.Show(query);
            using (MySqlDataReader reader = DatabaseHelper.Instance.getData(query))
            {
                while (reader.Read())
                {
                    users.Add(new User(reader.GetInt32(0), reader["username"].ToString(), reader["email"].ToString(), reader["password_hash"].ToString(), reader["value"].ToString()));
                }
            }
            //MessageBox.Show(users.Count.ToString());
            return users;
        }
        public static User GetUser(int userId)
        {
            string query = $"SELECT * FROM Users WHERE user_id = {userId}";

            MySqlDataReader reader = DatabaseHelper.Instance.getData(query);
            if (reader.Read())
            {
                return new User(reader.GetInt32(0), reader["username"].ToString(), reader["email"].ToString(), reader["password_hash"].ToString(), Convert.ToInt32(reader["role_id"]));
            }
            return null;
        }
        public static User GetUser(string email)
        {
            string query = $"SELECT * FROM Users WHERE email = '{email}'";
            MySqlDataReader reader = DatabaseHelper.Instance.getData(query);
            if (reader.Read())
            {
                return new User(reader.GetInt32(0), reader["username"].ToString(), reader["email"].ToString(), reader["password_hash"].ToString(), Convert.ToInt32(reader["role_id"]));
            }
            return null;
        }

    }
}
