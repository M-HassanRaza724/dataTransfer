﻿using Krypton_toolKit_Demo.BL;
using Krypton_toolKit_Demo.UI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls.Primitives;
using System.Windows.Forms;

namespace Krypton_toolKit_Demo.DL
{
    static public class FacultyCourseScheduleCRUD
    {
        public static void AddFacultyCourseScheduleToDB(FacultyCourseScheduleDTO fcs)
        {
            string query = $"INSERT INTO faculty_course_schedule (faculty_course_id, room_id, day_of_week, start_time, end_time) VALUES ({fcs.FacultyCourseId}, {fcs.RoomId}, '{fcs.DayOfWeek}', '{fcs.StartTime}', '{fcs.EndTime}')";
            DatabaseHelper.Instance.Update(query);
        }
        public static void DeleteFacultyCourseScheduleFromDB(int scheduleId)
        {
            string query = $"DELETE FROM faculty_course_schedule WHERE schedule_id = {scheduleId}";
            DatabaseHelper.Instance.Update(query);
        }
        public static void UpdateFacultyCourseScheduleInDB(FacultyCourseScheduleDTO fcs)
        {
            string query = $"UPDATE faculty_course_schedule SET faculty_course_id = {fcs.FacultyCourseId}, room_id = {fcs.RoomId}, day_of_week = '{fcs.DayOfWeek}', start_time = '{fcs.StartTime}', end_time = '{fcs.EndTime}' WHERE schedule_id = {fcs.ScheduleId}";
            DatabaseHelper.Instance.Update(query);
        }
        public static FacultyCourseScheduleDTO GetFacultyCourseSchedule(int scheduleId)
        {
            string query = $"SELECT     fcs.schedule_id AS ScheduleId,    fc.FacultyCourseId,    fc.FacultyName,    fc.CourseName,     fc.CourseType,      fc.SemesterTerm,     fc.SemesterYear,   r.room_id As RoomId,  COALESCE(r.room_name, 'No Room Assigned') AS RoomName,     fcs.day_of_week AS DayOfWeek,     fcs.start_time AS StartTime,     fcs.end_time AS EndTime FROM     faculty_course_schedule fcs INNER JOIN     (SELECT          fc.faculty_course_id AS FacultyCourseId,          f.name AS FacultyName,          COALESCE(c.course_name, 'No Course Assigned') AS CourseName,          c.course_type AS CourseType,          s.term AS SemesterTerm,          s.year AS SemesterYear      FROM          faculty f      INNER JOIN          faculty_courses fc ON f.faculty_id = fc.faculty_id      INNER JOIN          courses c ON fc.course_id = c.course_id      INNER JOIN          semesters s ON fc.semester_id = s.semester_id      WHERE          1 = 1) fc ON     fcs.faculty_course_id = fc.FacultyCourseId LEFT JOIN     rooms r ON fcs.room_id = r.room_id  WHERE schedule_id = {scheduleId}";

            using (var reader = DatabaseHelper.Instance.getData(query))
            {
                if (reader.Read())
                {
                    return new FacultyCourseScheduleDTO
                    {

                        ScheduleId = reader.GetInt32(reader.GetOrdinal("ScheduleId")),
                        FacultyCourseId = reader.GetInt32(reader.GetOrdinal("FacultyCourseId")),
                        FacultyName = reader.GetString(reader.GetOrdinal("FacultyName")),
                        CourseName = reader.GetString(reader.GetOrdinal("CourseName")),
                        CourseType = reader.GetString(reader.GetOrdinal("CourseType")),
                        SemesterTerm = reader.GetString(reader.GetOrdinal("SemesterTerm")),
                        RoomId = reader.GetInt32(reader.GetOrdinal("RoomId")),
                        SemesterYear = reader.GetInt32(reader.GetOrdinal("SemesterYear")),
                        RoomName = reader.GetString(reader.GetOrdinal("RoomName")),
                        DayOfWeek = reader.GetString(reader.GetOrdinal("DayOfWeek")),
                        StartTime = reader.GetTimeSpan(reader.GetOrdinal("StartTime")),
                        EndTime = reader.GetTimeSpan(reader.GetOrdinal("EndTime"))
                    };
                }
            }
            return null;
        }
public static  List<FacultyCourseScheduleDTO> GetFacultyCourseSchedules(int facultyId = 0,string name = null,string day = null, List<string> semester_terms = null, List<string> course_types = null, string sortby = null, string direction = null)
    {
        var schedules = new List<FacultyCourseScheduleDTO>();
            string query = "SELECT fcs.schedule_id AS ScheduleId,    fc.FacultyCourseId,    fc.FacultyName,    fc.CourseName,    fc.CourseType,    fc.SemesterTerm,    fc.SemesterYear,    r.room_id AS RoomId,    COALESCE(r.room_name, 'No Room Assigned') AS RoomName, fcs.day_of_week AS DayOfWeek,    fcs.start_time AS StartTime,    fcs.end_time AS EndTime FROM    faculty_course_schedule fcs        INNER JOIN(SELECT fc.faculty_course_id AS FacultyCourseId, f.name AS FacultyName, COALESCE(c.course_name, 'No Course Assigned') AS CourseName, c.course_type AS CourseType,            s.term AS SemesterTerm,            s.year AS SemesterYear FROM        faculty f    INNER JOIN faculty_courses fc ON f.faculty_id = fc.faculty_id    INNER JOIN courses c ON fc.course_id = c.course_id    INNER JOIN semesters s ON fc.semester_id = s.semester_id where 1 = 1";
            if (facultyId != 0)
            {
                query += $" AND fc.faculty_id = {facultyId}";
            }
            query += ")fc ON fcs.faculty_course_id = fc.FacultyCourseId        LEFT JOIN    rooms r ON fcs.room_id = r.room_id where 1=1 ";
            if (!string.IsNullOrEmpty(name))
                query += $" AND (fc.FacultyName LIKE '%{name}%' or fc.CourseName LIKE '%{name}%')";
            if (semester_terms != null && semester_terms.Count > 0)
            {
                string filter = string.Join("', '", semester_terms);
                query += $" AND fc.SemesterTerm IN ('{filter}')";
            }
            if (course_types != null && course_types.Count > 0)
            {
                string filter = string.Join("', '", course_types);
                query += $" AND fc.CourseType IN ('{filter}')";
            }
            if (!string.IsNullOrEmpty(day))
            {
                query += $" and fcs.day_of_week = '{day}'";
            }
            // Handle sortb
            if (!string.IsNullOrEmpty(sortby))
                query += $" ORDER BY {sortby}";
            if (!string.IsNullOrEmpty(direction))
                query += $" {direction}";
            //MessageBox.Show(query);
            using (var reader = DatabaseHelper.Instance.getData(query))
            {
                while (reader.Read())
                {
                    var schedule = new FacultyCourseScheduleDTO
                    {
                        ScheduleId = reader.GetInt32(reader.GetOrdinal("ScheduleId")),
                        FacultyCourseId = reader.GetInt32(reader.GetOrdinal("FacultyCourseId")),
                        FacultyName = reader.GetString(reader.GetOrdinal("FacultyName")),
                        CourseName = reader.GetString(reader.GetOrdinal("CourseName")),
                        CourseType = reader.GetString(reader.GetOrdinal("CourseType")),
                        SemesterTerm = reader.GetString(reader.GetOrdinal("SemesterTerm")),
                        RoomId = reader.GetInt32(reader.GetOrdinal("RoomId")),
                        SemesterYear = reader.GetInt32(reader.GetOrdinal("SemesterYear")),
                        RoomName = reader.GetString(reader.GetOrdinal("RoomName")),
                    DayOfWeek = reader.GetString(reader.GetOrdinal("DayOfWeek")),
                    StartTime = reader.GetTimeSpan(reader.GetOrdinal("StartTime")),
                    EndTime = reader.GetTimeSpan(reader.GetOrdinal("EndTime"))
                };

                schedules.Add(schedule);
            }
        }

        return schedules;
    }
}
}
