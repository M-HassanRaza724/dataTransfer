﻿using Krypton_toolKit_Demo.BL;
using System.Collections.Generic;
using static Mysqlx.Crud.Order.Types;
using System.Globalization;
using System.Xml.Linq;
using System.Windows.Forms;

namespace Krypton_toolKit_Demo.DL
{
    public static class CourseAllocationCRUD
    {
        public static void AddCourseAllocation(CourseAllocationDTO ca)
        {
            string query = $"INSERT INTO faculty_courses (faculty_id, course_id ,semester_id) VALUES ({ca.FacultyId}, {ca.CourseId}, {ca.SemesterId})";
            DatabaseHelper.Instance.Update(query);
        }
        public static void UpdateCourseAllocation(CourseAllocationDTO ca)
        {
            string query = $"UPDATE faculty_courses SET course_id = {ca.CourseId}, semester_id = {ca.SemesterId}, faculty_id = {ca.FacultyId} where faculty_course_id = {ca.FacultyCourseId};";
            DatabaseHelper.Instance.Update(query);
        }
        public static void DeleteCourseAllocation(int facultyCourseId)
        {
            string query = $"DELETE FROM faculty_courses WHERE faculty_course_id = {facultyCourseId}";
            DatabaseHelper.Instance.Update(query);
        }
        public static CourseAllocationDTO GetCourseAllocation(int facultyCourseId)
        {
            string query = $"SELECT      fc.faculty_course_id AS FacultyCourseId,     fc.course_id AS CourseId,     s.semester_id AS SemesterId,     f.faculty_id AS FacultyId,     f.name AS FacultyName,     COALESCE(c.course_name, 'No Course Assigned') AS CourseName,     c.course_type AS CourseType,     s.term AS SemesterTerm,     s.year AS SemesterYear FROM     faculty f         INNER JOIN     faculty_courses fc ON f.faculty_id = fc.faculty_id         INNER JOIN     courses c ON fc.course_id = c.course_id         INNER JOIN     semesters s ON fc.semester_id = s.semester_id WHERE faculty_course_id = {facultyCourseId}";

            using (var reader = DatabaseHelper.Instance.getData(query))
            {
                if (reader.Read())
                {
                    return new CourseAllocationDTO
                    {
                        FacultyCourseId = reader.IsDBNull(reader.GetOrdinal("FacultyCourseId")) ? (int?)null : reader.GetInt32(reader.GetOrdinal("FacultyCourseId")),
                        CourseId = reader.IsDBNull(reader.GetOrdinal("CourseId")) ? (int?)null : reader.GetInt32(reader.GetOrdinal("CourseId")),
                        FacultyId = reader.GetInt32(reader.GetOrdinal("FacultyId")),
                        SemesterId = reader.IsDBNull(reader.GetOrdinal("SemesterId")) ? (int?)null : reader.GetInt32(reader.GetOrdinal("SemesterId")),
                        CourseName = reader.GetString(reader.GetOrdinal("CourseName")),
                        CourseType = reader.GetString(reader.GetOrdinal("CourseType")),
                        SemesterTerm = reader.IsDBNull(reader.GetOrdinal("SemesterTerm")) ? null : reader.GetString(reader.GetOrdinal("SemesterTerm")),
                        SemesterYear = reader.IsDBNull(reader.GetOrdinal("SemesterYear")) ? (int?)null : reader.GetInt32(reader.GetOrdinal("SemesterYear")),
                        FacultyName = reader.GetString(reader.GetOrdinal("FacultyName"))
                    };
                }
                return null;
            }
        }
        public static List<CourseAllocationDTO> GetCourseAllocations(string name = null, List<string> semester_terms = null, List<string> course_types = null, string sortby = null, string direction = null,int facultyId = 0)
        {
            List<CourseAllocationDTO> courseAllocations = new List<CourseAllocationDTO>();
            string query = "SELECT      fc.faculty_course_id AS FacultyCourseId,     fc.course_id AS CourseId,     s.semester_id AS SemesterId,     f.faculty_id AS FacultyId,     f.name AS FacultyName,     COALESCE(c.course_name, 'No Course Assigned') AS CourseName,     c.course_type AS CourseType,     s.term AS SemesterTerm,     s.year AS SemesterYear FROM     faculty f         INNER JOIN     faculty_courses fc ON f.faculty_id = fc.faculty_id         INNER JOIN     courses c ON fc.course_id = c.course_id         INNER JOIN     semesters s ON fc.semester_id = s.semester_id WHERE     1 = 1 ";
            if(facultyId != 0)
            {
                query += $" AND f.faculty_id = {facultyId}";
            }
            if (!string.IsNullOrEmpty(name))
                query += $" AND (f.name LIKE '%{name}%' or c.course_name LIKE '%{name}%')";
            if (semester_terms != null && semester_terms.Count > 0)
            {
                string filter = string.Join("', '", semester_terms);
                query += $" AND s.term IN ('{filter}')";
            }
            if (course_types != null && course_types.Count > 0)
            {
                string filter = string.Join("', '", course_types);
                query += $" AND c.course_type IN ('{filter}')";
            }
            // Handle sortb
            if (!string.IsNullOrEmpty(sortby))
                query += $" ORDER BY {sortby}";
            if (!string.IsNullOrEmpty(direction))
                query += $" {direction}";
            //MessageBox.Show(query);
            using (var reader = DatabaseHelper.Instance.getData(query))
            {
                while (reader.Read())
                {
                    var facultyCourseAllocation = new CourseAllocationDTO
                    {
                        FacultyCourseId = reader.IsDBNull(reader.GetOrdinal("FacultyCourseId")) ? (int?)null : reader.GetInt32(reader.GetOrdinal("FacultyCourseId")),
                        CourseId = reader.IsDBNull(reader.GetOrdinal("CourseId")) ? (int?)null : reader.GetInt32(reader.GetOrdinal("CourseId")),
                        FacultyId = reader.GetInt32(reader.GetOrdinal("FacultyId")),
                        SemesterId = reader.IsDBNull(reader.GetOrdinal("SemesterId")) ? (int?)null : reader.GetInt32(reader.GetOrdinal("SemesterId")),
                        CourseType = reader.IsDBNull(reader.GetOrdinal("CourseType")) ? null : reader.GetString(reader.GetOrdinal("CourseType")),
                        CourseName = reader.IsDBNull(reader.GetOrdinal("CourseName")) ? null : reader.GetString(reader.GetOrdinal("CourseName")),
                        SemesterTerm = reader.IsDBNull(reader.GetOrdinal("SemesterTerm")) ? null : reader.GetString(reader.GetOrdinal("SemesterTerm")),
                        SemesterYear = reader.IsDBNull(reader.GetOrdinal("SemesterYear")) ? (int?)null : reader.GetInt32(reader.GetOrdinal("SemesterYear")),
                        FacultyName = reader.IsDBNull(reader.GetOrdinal("FacultyName")) ? null : reader.GetString(reader.GetOrdinal("FacultyName"))

                    };
                    courseAllocations.Add(facultyCourseAllocation);
                }
                return courseAllocations;
            }
        }
    }
}