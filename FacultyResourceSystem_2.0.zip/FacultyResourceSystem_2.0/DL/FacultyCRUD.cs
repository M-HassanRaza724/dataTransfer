﻿using Krypton_toolKit_Demo.BL;
using MySql.Data.MySqlClient;
using Org.BouncyCastle.Tls;
using System;
using System.Collections.Generic;
using System.Windows;

namespace Krypton_toolKit_Demo.DL
{
    class FacultyCRUD
    {
        public static void AddFaculty(Faculty f)
        {
            string query = $"INSERT INTO Faculty (faculty_id, name, email, contact, designation_id, research_area, total_teaching_hours, user_id) VALUES ('{f.faculty_id}', '{f.name}', '{f.email}', '{f.contact}', '{f.designation_id}', '{f.research_area}', '{f.total_teaching_hours}', '{f.user_id}')";
            DatabaseHelper.Instance.Update(query);
        }
        public static void UpdateFaculty(Faculty f)
        {
            string query = $"UPDATE Faculty SET name = '{f.name}', email = '{f.email}', contact = '{f.contact}', designation_id = '{f.designation_id}', research_area = '{f.research_area}', total_teaching_hours = '{f.total_teaching_hours}', user_id = '{f.user_id}' WHERE faculty_id = '{f.faculty_id}'";
            DatabaseHelper.Instance.Update(query);
        }
        public static void UpdateFacultyEmail(int userId, string email)
        {
            try
            {
                string query = $"UPDATE Faculty SET email = '{email}' WHERE user_id = '{userId}'";
                DatabaseHelper.Instance.Update(query);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public static void DeleteFaculty(int faculty_id)
        {
            string query = $"DELETE FROM Faculty WHERE faculty_id = {faculty_id}";
            DatabaseHelper.Instance.Update(query);
        }
        public static Faculty GetFaculty(int faculty_id)
        {
            string query = $"SELECT * FROM Faculty WHERE faculty_id = {faculty_id}";
            MySqlDataReader reader = DatabaseHelper.Instance.getData(query);
            if (reader.Read())
            {
                return new Faculty(Convert.ToInt32(reader["faculty_id"]), reader["name"].ToString(), reader["email"].ToString(), reader["contact"].ToString(), Convert.ToInt32(reader["designation_id"]), reader["research_area"].ToString(), Convert.ToInt32(reader["total_teaching_hours"]), Convert.ToInt32(reader["user_id"]));
            }
            return null;
        }
        public static List<Faculty> GetFaculties(string name, List<string> designations = null, string sortby = null, string direction = null)
        {
            List<Faculty> faculties = new List<Faculty>();
            string query = "SELECT faculty_id, name, email, contact ,value designation, research_area, total_teaching_hours,user_id FROM Faculty inner join lookup where designation_id = lookup_id";
            if (!string.IsNullOrEmpty(name))
            {
                query += $" AND name Like '%{name}%'";
            }
            if (designations != null && designations.Count > 0)
            {
                string filter = string.Join("', '", designations);
                query += $" AND value IN ('{filter}')";
            }
            if (!string.IsNullOrEmpty(sortby))
            {
                query += $" ORDER BY {sortby}";
                if (!string.IsNullOrEmpty(direction))
                {
                    query += $" {direction}";
                }
            }
            //MessageBox.Show(query);
            MySqlDataReader reader = DatabaseHelper.Instance.getData(query);
            while (reader.Read())
            {
                faculties.Add(new Faculty(Convert.ToInt32(reader["faculty_id"]), reader["name"].ToString(), reader["email"].ToString(), reader["contact"].ToString(), reader["designation"].ToString(), reader["research_area"].ToString(), Convert.ToInt32(reader["total_teaching_hours"]), Convert.ToInt32(reader["user_id"])));
            }
            return faculties;
        }
        public static List<string> GetFacultyNames()
        {
            List<string> faculties = new List<string>();
            string query = "SELECT faculty_id, name, email, contact ,value designation, research_area, total_teaching_hours,user_id FROM Faculty inner join lookup where designation_id = lookup_id";
            MySqlDataReader reader = DatabaseHelper.Instance.getData(query);
            while (reader.Read())
            {
                faculties.Add(reader["name"].ToString());
            }
            return faculties;
        }
        public static int GetFacultyId(string faculty_name)
        {
            string query = $"SELECT * FROM Faculty WHERE name = '{faculty_name}'";
            MySqlDataReader reader = DatabaseHelper.Instance.getData(query);
            if (reader.Read())
            {
                return Convert.ToInt32(reader["faculty_id"]);
            }
            return -1;
        }
        public static int GetFacultyIdFromEmail(string email)
        {
            string query = $"SELECT * FROM Faculty natural join users WHERE email = '{email}'";
            MySqlDataReader reader = DatabaseHelper.Instance.getData(query);
            if (reader.Read())
            {
                return Convert.ToInt32(reader["faculty_id"]);
            }
            return -1;
        }
    }
}
