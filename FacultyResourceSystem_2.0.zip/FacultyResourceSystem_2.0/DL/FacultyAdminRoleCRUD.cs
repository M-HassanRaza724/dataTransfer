﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using Krypton_toolKit_Demo.BL;
using static Mysqlx.Crud.Order.Types;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Globalization;
using System.Xml.Linq;
using System.Windows;

namespace Krypton_toolKit_Demo.DL
{
    public static class FacultyAdminRoleCRUD
    {
        public static void AddFacultyAdminRole(FacultyAdminRoleDTO far)
        {
            string query = $"INSERT INTO faculty_admin_roles (faculty_id, role_name, semester_id) VALUES ({far.FacultyId}, '{far.RoleName}', {far.SemesterId})";
            DatabaseHelper.Instance.Update(query);
        }
        public static void UpdateFacultyAdminRole(FacultyAdminRoleDTO far)
        {
            string query = $"UPDATE faculty_admin_roles SET role_name = '{far.RoleName}', semester_id = {far.SemesterId} WHERE admin_role_id = {far.AdminRoleId}";
            DatabaseHelper.Instance.Update(query);
        }
        public static void DeleteFacultyAdminRole(int adminRoleId)
        {
            string query = $"DELETE FROM faculty_admin_roles WHERE admin_role_id = {adminRoleId}";
            DatabaseHelper.Instance.Update(query);
        }
        public static void DeleteFacultyAdminRoleByFacultyId(int facultyId)
        {
            string query = $"DELETE FROM faculty_admin_roles WHERE faculty_id = {facultyId}";
            DatabaseHelper.Instance.Update(query);
        }
        public static void DeleteFacultyAdminRoleBySemesterId(int semesterId)
        {
            string query = $"DELETE FROM faculty_admin_roles WHERE semester_id = {semesterId}";
            DatabaseHelper.Instance.Update(query);
        }
        public static FacultyAdminRoleDTO GetFacultyAdminRole(int adminRoleId)
        {
            string query = $"Select * FROM faculty_admin_roles WHERE admin_role_id = {adminRoleId}";
            using (MySqlDataReader reader = DatabaseHelper.Instance.getData(query))
            {
                if (reader.Read())
                {
                    return new FacultyAdminRoleDTO
                    {
                        FacultyId = reader.GetInt32(reader.GetOrdinal("faculty_id")),
                        RoleName = reader.GetString(reader.GetOrdinal("role_name")),
                        AdminRoleId = reader.GetInt32(reader.GetOrdinal("admin_role_id")),
                        SemesterId = reader.IsDBNull(reader.GetOrdinal("semester_id")) ? (int?)null : reader.GetInt32(reader.GetOrdinal("semester_id"))
                    };
                }
            }
                return null;
        }
        public static List<FacultyAdminRoleDTO> GetFacultyAdminRoles(string name = null, List<string> semester_terms = null, string sortby = null, string direction = null,int facultyId = 0)
        {
            List<FacultyAdminRoleDTO> facultyAdminRoles = new List<FacultyAdminRoleDTO>();
            string query = "SELECT f.faculty_id AS FacultyId,   f.name AS FacultyName,  COALESCE(far.role_name, 'No Admin Role') AS RoleName, far.admin_role_id AS AdminRoleId,  s.semester_id AS SemesterId,  s.term AS SemesterTerm,  s.year AS SemesterYear FROM   faculty f LEFT JOIN   faculty_admin_roles far ON f.faculty_id = far.faculty_id LEFT JOIN   semesters s ON far.semester_id = s.semester_id where 1=1";
            if(facultyId != 0)
            {
                query += $" AND f.faculty_id = {facultyId}";
            }


            if (!string.IsNullOrEmpty(name))
                query += $" AND (f.name LIKE '%{name}%' or far.role_name LIKE '%{name}%')";
            if (semester_terms != null && semester_terms.Count > 0)
            {
                string filter = string.Join("', '", semester_terms);
                query += $" AND s.term IN ('{filter}')";
            }
            // Handle sortb
            if (!string.IsNullOrEmpty(sortby))
                query += $" ORDER BY {sortby}";
            if (!string.IsNullOrEmpty(direction))
                query += $" {direction}";
            //MessageBox.Show(query);
            using (MySqlDataReader reader = DatabaseHelper.Instance.getData(query))
            {
                while (reader.Read())
                {
                    var facultyAdminRole = new FacultyAdminRoleDTO
                    {
                        FacultyId = reader.GetInt32(reader.GetOrdinal("FacultyId")),
                        FacultyName = reader.GetString(reader.GetOrdinal("FacultyName")),
                        RoleName = reader.GetString(reader.GetOrdinal("RoleName")),
                        AdminRoleId = reader.IsDBNull(reader.GetOrdinal("AdminRoleId")) ? (int?)null : reader.GetInt32(reader.GetOrdinal("AdminRoleId")),
                        SemesterId = reader.IsDBNull(reader.GetOrdinal("SemesterId")) ? (int?)null : reader.GetInt32(reader.GetOrdinal("SemesterId")),
                        SemesterTerm = reader.IsDBNull(reader.GetOrdinal("SemesterTerm")) ? null : reader.GetString(reader.GetOrdinal("SemesterTerm")),
                        SemesterYear = reader.IsDBNull(reader.GetOrdinal("SemesterYear")) ? (int?)null : reader.GetInt32(reader.GetOrdinal("SemesterYear"))
                    };
                    facultyAdminRoles.Add(facultyAdminRole);

                }
            }
            return facultyAdminRoles;
        }
    }

}
