﻿using Krypton_toolKit_Demo.BL;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Windows;


namespace Krypton_toolKit_Demo.DL
{

    public static class CourseCRUD
    {
        public static void AddCourseToDB(Course c)
        {
            string query = $"INSERT INTO Courses (course_name, course_type, credit_hours, contact_hours) VALUES ('{c.course_name}', '{c.course_type}', {c.credit_hours}, {c.contact_hours})";
            DatabaseHelper.Instance.Update(query);
        }
        public static void UpdateCourseInDB(Course c)
        {
            string query = $"UPDATE Courses SET course_name = '{c.course_name}', course_type = '{c.course_type}', credit_hours = {c.credit_hours}, contact_hours = {c.contact_hours} WHERE course_id = {c.course_id}";
            DatabaseHelper.Instance.Update(query);
        }
        public static void DeleteCourse(int course_id)
        {
            string query = $"DELETE FROM Courses WHERE course_id = {course_id}";
            DatabaseHelper.Instance.Update(query);
        }
        public static Course GetCourseFromDB(int course_id)
        {
            string query = $"SELECT * FROM Courses WHERE course_id = {course_id}";
            MySqlDataReader reader = DatabaseHelper.Instance.getData(query);
            if (reader.Read())
            {
                return new Course(reader["course_name"].ToString(), Convert.ToInt32(reader["credit_hours"]), Convert.ToInt32(reader["contact_hours"]), reader["course_type"].ToString(), Convert.ToInt32(reader["course_id"]));
            }
            return null;
        }
        public static List<Course> GetCourses(string course_name = null,string type = null,string sortby = null)
        {
            List<Course> courses = new List<Course>();
            string query = "SELECT * FROM Courses WHERE 1=1";

            // Handle course_name
            if (!string.IsNullOrEmpty(course_name))
            {
                query += $" AND course_name LIKE {course_name}";
            }

            // Handle type
            if (!string.IsNullOrEmpty(type))
            {
                query += $" AND course_type = {type}";
            }

            // Handle sortby
            if (!string.IsNullOrEmpty(sortby))
            {
                query += $" ORDER BY {sortby}";

            }

            MessageBox.Show(query);
            // Execute query
            MySqlDataReader reader = DatabaseHelper.Instance.getData(query);

            while (reader.Read())
            {
                courses.Add(new Course(reader["course_name"].ToString(), Convert.ToInt32(reader["credit_hours"]), Convert.ToInt32(reader["contact_hours"]), reader["course_type"].ToString(), Convert.ToInt32(reader["course_id"])));
            }
            //MessageBox.Show($"Data Loaded Successfully. {i} rows returned");
            return courses;
        }
        public static List<string> GetCoursesNames()
        {
            List<string> courses = new List<string>();
            string query = "SELECT Distinct course_name FROM Courses";
            MySqlDataReader reader = DatabaseHelper.Instance.getData(query);
            while (reader.Read())
            {
                courses.Add(reader["course_name"].ToString());
            }
            return courses;
        }
        public static List<string> GetCourseTypes(string course_name)
        {
            List<string> courses = new List<string>();
            string query = $"SELECT Distinct course_type FROM Courses WHERE course_name = '{course_name}'";
            MySqlDataReader reader = DatabaseHelper.Instance.getData(query);
            while (reader.Read())
            {
                courses.Add(reader["course_type"].ToString());
            }
            return courses;
        }
        public static int GetCourseId(string courseName, string courseType)
        {
            string query = $"SELECT course_id FROM Courses WHERE course_name = '{courseName}' AND course_type = '{courseType}'";
            MySqlDataReader reader = DatabaseHelper.Instance.getData(query);
            if (reader.Read())
            {
                return Convert.ToInt32(reader["course_id"]);
            }
            return 0;
        }
    }
}