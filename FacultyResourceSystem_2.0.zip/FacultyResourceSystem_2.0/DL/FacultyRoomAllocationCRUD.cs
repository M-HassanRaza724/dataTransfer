﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using Krypton_toolKit_Demo.BL;
using MySql.Data.MySqlClient;

namespace Krypton_toolKit_Demo.DL
{
    public class FacultyRoomAllocationCRUD
    {
        public static void AddRoomAllocation(FacultyRoomAllocationDTO ra)
        {

            string query = $"INSERT INTO faculty_room_allocations (faculty_id, room_id, reserved_hours, semester_id) VALUES ({ra.FacultyId}, {ra.RoomId}, {ra.ReservedHours}, {ra.SemesterId});";
            DatabaseHelper.Instance.Update(query);
        }
        public static void UpdateRoomAllocation(FacultyRoomAllocationDTO ra)
        {
            string query = $"UPDATE faculty_room_allocations SET faculty_id = {ra.FacultyId}, room_id = {ra.RoomId}, reserved_hours = {ra.ReservedHours}, semester_id = {ra.SemesterId} where allocation_id = {ra.AllocationId};";
            DatabaseHelper.Instance.Update(query);
        }
        public static void DeleteRoomAllocation(int allocationId)
        {
            string query = $"DELETE FROM faculty_room_allocations WHERE allocation_id = {allocationId}";
            DatabaseHelper.Instance.Update(query);
        }
        public static FacultyRoomAllocationDTO GetRoomAllocation(int allocationId)
        {
            string query = $"SELECT      ra.allocation_id AS AllocationId,     ra.room_id AS RoomId,     ra.reserved_hours AS ReservedHours,     s.semester_id AS SemesterId,     f.faculty_id AS FacultyId,     f.name AS FacultyName,     COALESCE(r.room_name, 'No Room Assigned') AS RoomName,     s.term AS SemesterTerm,     s.year AS SemesterYear FROM     faculty f         INNER JOIN     faculty_room_allocations ra ON f.faculty_id = ra.faculty_id         INNER JOIN     rooms r ON ra.room_id = r.room_id         INNER JOIN     semesters s ON ra.semester_id = s.semester_id WHERE allocation_id = {allocationId}";
            using (var reader = DatabaseHelper.Instance.getData(query))
            {
                if (reader.Read())
                {
                    return new FacultyRoomAllocationDTO
                    {
                        AllocationId = reader.GetInt32(reader.GetOrdinal("AllocationId")),
                        RoomId = reader.IsDBNull(reader.GetOrdinal("RoomId")) ? (int?)null : reader.GetInt32(reader.GetOrdinal("RoomId")),
                        FacultyId = reader.GetInt32(reader.GetOrdinal("FacultyId")),
                        ReservedHours = reader.GetInt32(reader.GetOrdinal("ReservedHours")),
                        SemesterId = reader.IsDBNull(reader.GetOrdinal("SemesterId")) ? (int?)null : reader.GetInt32(reader.GetOrdinal("SemesterId")),
                        RoomName = reader.GetString(reader.GetOrdinal("RoomName")),
                        SemesterTerm = reader.IsDBNull(reader.GetOrdinal("SemesterTerm")) ? null : reader.GetString(reader.GetOrdinal("SemesterTerm")),
                        SemesterYear = reader.IsDBNull(reader.GetOrdinal("SemesterYear")) ? (int?)null : reader.GetInt32(reader.GetOrdinal("SemesterYear")),
                        FacultyName = reader.GetString(reader.GetOrdinal("FacultyName"))
                    };
                }
                return null;
            }
        }
        public static List<FacultyRoomAllocationDTO> GetRoomAllocations(string name = null, List<string> semester_terms = null, string sortby = null, string direction = null)
        {
            List<FacultyRoomAllocationDTO> roomAllocations = new List<FacultyRoomAllocationDTO>();
            string query = $"SELECT      ra.allocation_id AS AllocationId,     ra.room_id AS RoomId,     ra.reserved_hours AS ReservedHours,     s.semester_id AS SemesterId,     f.faculty_id AS FacultyId,     f.name AS FacultyName,     COALESCE(r.room_name, 'No Room Assigned') AS RoomName,     s.term AS SemesterTerm,     s.year AS SemesterYear FROM     faculty f         INNER JOIN     faculty_room_allocations ra ON f.faculty_id = ra.faculty_id         INNER JOIN     rooms r ON ra.room_id = r.room_id         INNER JOIN     semesters s ON ra.semester_id = s.semester_id WHERE 1=1";
            if (!string.IsNullOrEmpty(name))
                query += $" AND (f.name LIKE '%{name}%' or r.room_name LIKE '%{name}%')";
            if (semester_terms != null && semester_terms.Count > 0)
            {
                string filter = string.Join("', '", semester_terms);
                query += $" AND s.term IN ('{filter}')";
            }
            // Handle sortb
            if (!string.IsNullOrEmpty(sortby))
                query += $" ORDER BY {sortby}";
            if (!string.IsNullOrEmpty(direction))
                query += $" {direction}";
            //MessageBox.Show(query);
            using (var reader = DatabaseHelper.Instance.getData(query))
            {
                while (reader.Read())
                {
                    var roomAllocation = new FacultyRoomAllocationDTO
                    {
                        AllocationId = reader.GetInt32(reader.GetOrdinal("AllocationId")),
                        RoomId = reader.IsDBNull(reader.GetOrdinal("RoomId")) ? (int?)null : reader.GetInt32(reader.GetOrdinal("RoomId")),
                        FacultyId = reader.GetInt32(reader.GetOrdinal("FacultyId")),
                        ReservedHours = reader.GetInt32(reader.GetOrdinal("ReservedHours")),
                        SemesterId = reader.IsDBNull(reader.GetOrdinal("SemesterId")) ? (int?)null : reader.GetInt32(reader.GetOrdinal("SemesterId")),
                        RoomName = reader.GetString(reader.GetOrdinal("RoomName")),
                        SemesterTerm = reader.IsDBNull(reader.GetOrdinal("SemesterTerm")) ? null : reader.GetString(reader.GetOrdinal("SemesterTerm")),
                        SemesterYear = reader.IsDBNull(reader.GetOrdinal("SemesterYear")) ? (int?)null : reader.GetInt32(reader.GetOrdinal("SemesterYear")),
                        FacultyName = reader.GetString(reader.GetOrdinal("FacultyName"))
                    };
                    roomAllocations.Add(roomAllocation);
                }
                return roomAllocations;
            }
        }

    }

}
