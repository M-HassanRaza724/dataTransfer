﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using Krypton_toolKit_Demo.BL;

namespace Krypton_toolKit_Demo.DL
{
    public static class LookupCRUD
    {
        public static List<Lookup> lookups = new List<Lookup>();
        public static List<string> GetValues(string category)
        {
            List<string> values = new List<string>();
            string query = $"SELECT value FROM Lookup WHERE category = '{category}'";
            using (MySqlDataReader reader = DatabaseHelper.Instance.getData(query))
            {
                while (reader.Read())
                {
                    values.Add(reader["value"].ToString());
                }
            }
            return values;
        }
        public static string GetValue(int id)
        {
            foreach (Lookup lookup in lookups)
            {
                if (lookup.lookup_id == id)
                    return lookup.value;
            }
            return null;

        }
        public static int GetId(string value)
        {
            foreach(Lookup lookup in lookups)
            {
                if (lookup.value == value)
                    return lookup.lookup_id;
            }
            return -1;
        }
        public static void LoadLookups()
        {
            lookups.Clear();
            string query = "SELECT * FROM Lookup";
            using (MySqlDataReader reader = DatabaseHelper.Instance.getData(query))
            {
                while (reader.Read())
                {
                    lookups.Add(new Lookup(Convert.ToInt32(reader["lookup_id"]), reader["category"].ToString(), reader["value"].ToString()));
                }
            }
        }
    }
}
