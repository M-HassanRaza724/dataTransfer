﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using Krypton_toolKit_Demo.BL;
using System.Windows;

namespace Krypton_toolKit_Demo.DL
{
    class SemesterCRUD
    {
        public static void AddSemesterToDB(Semester s)
        {
            string query = $"INSERT INTO Semesters (term, year) VALUES ('{s.term}', {s.year})";
            DatabaseHelper.Instance.Update(query);
        }
        public static void UpdateSemesterInDB(Semester s)
        {
            string query = $"UPDATE Semesters SET term = '{s.term}', year = {s.year} WHERE semester_id = {s.semester_id}";
            DatabaseHelper.Instance.Update(query);
        }
        public static void DeleteSemesterFromDB(int semesterID)
        {
            string query = $"DELETE FROM Semesters WHERE semester_id = {semesterID}";
            DatabaseHelper.Instance.Update(query);
        }
        public static Semester GetSemesterFromDB(int semester_id)
        {
            string query = $"SELECT * FROM Semesters WHERE semester_id = {semester_id}";
            MySqlDataReader reader = DatabaseHelper.Instance.getData(query);
            if (reader.Read())
            {
                return new Semester( reader["term"].ToString(), Convert.ToInt32(reader["year"]), Convert.ToInt32(reader["semester_id"]));
            }
            return null;
        }
        public static List<Semester> GetSemesters(int year = 0,List<string> terms = null,string sortby = null,string direction = null)
        {
            List<Semester> semesters = new List<Semester>();
            string query = $"SELECT * FROM Semesters where 1=1";
            if (year != 0)
                query += $" AND year = '{year}'";
            if (terms != null)
            {
                string filter = string.Join("', '", terms);
                query += $" and term IN ('{filter}')";
            }
            if (!string.IsNullOrEmpty(sortby))
            {
                query += $" ORDER BY {sortby}";
                if (!string.IsNullOrEmpty(direction))
                    query += $" {direction}";
            }
            //MessageBox.Show(query);
            MySqlDataReader reader = DatabaseHelper.Instance.getData(query);
            while (reader.Read())
            {
                semesters.Add(new Semester( reader["term"].ToString(), Convert.ToInt32(reader["year"]), Convert.ToInt32(reader["semester_id"])));
            }
            return semesters;
        }
        public static int GetSemesterId(int Year,string Term)
        {
            string query = $"Select semester_id from semesters where term = '{Term}' and year = {Year}";
            using(MySqlDataReader reader = DatabaseHelper.Instance.getData(query))
            {
                if (reader.Read())
                    return Convert.ToInt32(reader["semester_id"]);
                return 0;
            }
        }
        public static List<string> GetSemesterYears()
        {
            List<string> years = new List<string>();
            string query = "SELECT DISTINCT year FROM Semesters";
            MySqlDataReader reader = DatabaseHelper.Instance.getData(query);
            while (reader.Read())
            {
                years.Add(reader["year"].ToString());
            }
            return years;
        }
        public static List<string> GetSemesterTerms(int year)
        {
            List<string> terms = new List<string>();
            string query = $"SELECT DISTINCT term FROM Semesters WHERE year = {year}";
            MySqlDataReader reader = DatabaseHelper.Instance.getData(query);
            while (reader.Read())
            {
                terms.Add(reader["term"].ToString());
            }
            return terms;
        }
    }
}
