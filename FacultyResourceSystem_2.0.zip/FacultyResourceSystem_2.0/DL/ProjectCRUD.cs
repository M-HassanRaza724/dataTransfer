﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using Krypton_toolKit_Demo.BL;
using System.Windows.Documents;
using static Mysqlx.Crud.Order.Types;
using System.Globalization;
using System.Windows;

namespace Krypton_toolKit_Demo.DL
{
    static class ProjectCRUD
    {
        public static void AddProject(Project p)
        {
            string query = $"INSERT INTO Projects ( title, description) VALUES ('{p.title}', '{p.description}')";
            DatabaseHelper.Instance.Update(query);
        }
        public static void DeleteProject(int ProjectId)
        {
            string query = $"DELETE FROM Projects WHERE project_id = {ProjectId}";
            DatabaseHelper.Instance.Update(query);
        }
        public static void UpdateProject(Project p)
        {
            string query = $"UPDATE Projects SET title = '{p.title}', description = '{p.description}' WHERE project_id = {p.project_id}";
            DatabaseHelper.Instance.Update(query);
        }
        public static List<Project> GetProjects(string title = null,string sortby = null,string direction = null)
        {
            List<Project> projects = new List<Project>();
            string query = "SELECT project_id, title, description FROM Projects where 1=1";
            if(!string.IsNullOrEmpty(title))
                query += $" AND title LIKE '%{title}%'";
            if (!string.IsNullOrEmpty(sortby))
                query += $" ORDER BY {sortby}";
            if (!string.IsNullOrEmpty(direction))
                query += $" {direction}";
            //MessageBox.Show(query);
            using (MySqlDataReader reader = DatabaseHelper.Instance.getData(query))
            {
                while (reader.Read())
                {
                    projects.Add(new Project(Convert.ToInt32(reader["project_id"]), reader["title"].ToString(), reader["description"].ToString()));
                }
            }
            //MessageBox.Show(projects.Count.ToString());
            return projects;
        }
        public static Project GetProject(int projectId)
        {
            string query = $"SELECT * FROM Projects WHERE project_id = {projectId}";

            MySqlDataReader reader = DatabaseHelper.Instance.getData(query);
            if (reader.Read())
            {
                return new Project(Convert.ToInt32(reader["project_id"]), reader["title"].ToString(), reader["description"].ToString());
            }
            return null;
        }
        public static List<string> GetProjectTitles()
        {
            string query = $"SELECT title FROM Projects";
            List<string> strings = new List<string>();
            MySqlDataReader reader = DatabaseHelper.Instance.getData(query);
            while (reader.Read())
            {
                strings.Add( reader["title"].ToString());

            }
            return strings;
        }

        public static int GetProjectId(string projectTitle)
        {
            string query = $"SELECT * FROM Projects WHERE title = '{projectTitle}'";
            MySqlDataReader reader = DatabaseHelper.Instance.getData(query);
            if (reader.Read())
            {
                return Convert.ToInt32(reader["project_id"]);
            }
            return 0;
        }
    }
}
