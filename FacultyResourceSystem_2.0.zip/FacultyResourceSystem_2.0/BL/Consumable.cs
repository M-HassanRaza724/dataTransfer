﻿using System.Windows.Forms;
using Krypton_toolKit_Demo.DL;

namespace Krypton_toolKit_Demo.BL
{
    class Consumable
    {
        public int consumable_id { get; set; }
        public string item_name { get; set; }
        public Consumable(string item_name)
        {
            this.item_name = item_name;
        }
        public Consumable(int consumable_id, string item_name)
        {
            this.consumable_id = consumable_id;
            this.item_name = item_name;
        }
        public void AddConsumable()
        {
            if(string.IsNullOrEmpty(item_name))
                throw new System.Exception("Item name cannot be empty");
            else
                ConsumableCRUD.AddConsumable(this);
        }
        public void UpdateConsumable()
        {
            if (string.IsNullOrEmpty(item_name))
                throw new System.Exception("Item name cannot be empty");
            else
                ConsumableCRUD.UpdateConsumable(this);
        }
        public static void DeleteConsumable(int consumableId)
        {
            DialogResult result = MessageBox.Show(
            "Are you sure you want to delete this record?",
            "Confirm Deletion",
            MessageBoxButtons.OKCancel,
            MessageBoxIcon.Warning
            );
            if (result == DialogResult.Cancel)
                return;
            else
            {
                ConsumableCRUD.DeleteConsumable(consumableId);
            }
        }
    }
}
