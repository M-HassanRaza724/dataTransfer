﻿using Krypton_toolKit_Demo.DL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Krypton_toolKit_Demo.BL
{
    public class FacultyCourseScheduleDTO
    {
        public int ScheduleId { get; set; }
        public int FacultyCourseId { get; set; }
        public string FacultyName { get; set; }
        public string CourseName { get; set; }
        public string CourseType { get; set; }
        public string SemesterTerm { get; set; }
        public int SemesterYear { get; set; }
        public string RoomName { get; set; }
        public int RoomId { get; set; }
        public string DayOfWeek { get; set; }
        public TimeSpan StartTime { get; set; }
        public TimeSpan EndTime { get; set; }
        public bool Check()
        {
            if (FacultyCourseId == 0)
            {
                MessageBox.Show("Faculty Course is required");
                return false;
            }
            else if (RoomId == 0)
            {
                MessageBox.Show("Room is required");
                return false;
            }
            else if (DayOfWeek == null)
            {
                MessageBox.Show("Day of Week is required");
                return false;
            }
            else if (StartTime == null)
            {
                MessageBox.Show("Start Time is required");
                return false;
            }
            else if (EndTime == null)
            {
                MessageBox.Show("End Time is required");
                return false;
            }

            return true;
        }
        internal static void DeleteFacultyCourseSchedule(int scheduleId)
        {
            try
            {

                DialogResult result = MessageBox.Show(
                   "Are you sure you want to delete this record?",
                   "Confirm Deletion",
                   MessageBoxButtons.YesNo,
                   MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                    CourseAllocationCRUD.DeleteCourseAllocation(scheduleId);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        internal void AddFacultyCourseSchedule()
        {
            if(Check())
            {
                FacultyCourseScheduleCRUD.AddFacultyCourseScheduleToDB(this);
            }
        }

        internal void UpdateFacultyCourseSchedule()
        {
            if (Check())
            {
                FacultyCourseScheduleCRUD.UpdateFacultyCourseScheduleInDB(this);
            }
        }
        public static List<TimeSpan> GetValidTimes(TimeSpan startTime)
        {
            List<TimeSpan> times = new List<TimeSpan>();
            List<TimeSpan> timeSlots = new List<TimeSpan>
            {
                new TimeSpan(7, 0, 0),  // 07:00 AM
                new TimeSpan(8, 0, 0),  // 08:00 AM
                new TimeSpan(9, 0, 0),  // 09:00 AM
                new TimeSpan(10, 0, 0), // 10:00 AM
                new TimeSpan(11, 0, 0), // 11:00 AM
                new TimeSpan(12, 0, 0), // 12:00 PM
                new TimeSpan(13, 0, 0), // 01:00 PM
                new TimeSpan(14, 0, 0), // 02:00 PM
                new TimeSpan(15, 0, 0), // 03:00 PM
                new TimeSpan(16, 0, 0)  // 04:00 PM
            };
            foreach(TimeSpan time in timeSlots)
            {
                if(time > startTime)
                    times.Add(time);
            }
            return times;
        }
    }
}
