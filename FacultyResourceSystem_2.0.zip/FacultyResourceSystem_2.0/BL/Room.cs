﻿using System;
using System.Windows.Forms;
using Krypton_toolKit_Demo.DL;

namespace Krypton_toolKit_Demo.BL
{
    public class Room
    {
        public int room_id { get; set; }
        public string room_name { get; set; }
        public string room_type { get; set; }
        public int capacity { get; set; }

        public Room(string room_name, string room_type, int capacity, int room_id = 0)
        {
            if (room_id != 0)
                this.room_id = room_id;
            this.room_name = room_name;
            this.room_type = room_type;
            this.capacity = capacity;
        }
        public Room() { }

        public void AddRoom()
        {
            if (this.room_name == null || room_name == "" || room_name == "Enter Room Name")
                throw new Exception("Room name cannot be empty");
            else if (this.room_type == null || room_type == "")
                throw new Exception("Room type cannot be empty");
            else if (this.capacity <= 0)
                throw new Exception("Capacity must be greater than 0");
            else
            {
                Room r = new Room(room_name, room_type, capacity);
                RoomCRUD.AddRoomToDB(r);
            }
        }
        public void UpdateRoom()
        {
            if (room_name == null || room_name == "" || room_name == "Enter Room Name")
                throw new Exception("Room name cannot be empty");
            else if (room_type == null || room_type == "")
                throw new Exception("Room type cannot be empty");
            else if (capacity <= 0)
                throw new Exception("Capacity must be greater than 0");
            else
            {
                Room r = new Room(room_name, room_type, capacity, room_id);
                RoomCRUD.UpdateRoomInDB(r);
            }
        }
        public static void DeleteRoom(int roomId)
        {
            DialogResult result = MessageBox.Show(
            "Are you sure you want to delete this record?",
            "Confirm Deletion",
            MessageBoxButtons.OKCancel,
            MessageBoxIcon.Warning
            );
            if (result == DialogResult.Cancel)
                return;
            else
            {

                if (roomId == 0)
                    throw new Exception("Room ID is required");
                else
                {
                    RoomCRUD.DeleteRoomFromDB(roomId);
                }
            }
        }
    }
}
