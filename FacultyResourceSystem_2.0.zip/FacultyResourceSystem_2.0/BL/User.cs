﻿using Mysqlx.Session;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Krypton_toolKit_Demo.DL;
using System.Runtime.CompilerServices;
using Krypton_toolKit_Demo.BL;
using System.Windows.Forms;

namespace Krypton_toolKit_Demo
{
    public class User
    {
        public int UserId { get; set; }
        public string Name { get; set; }
        public string Password { get; set; }
        public string Email { get; set; }
        public int RoleId { get; set; }
        public string Role { get; set; }

        // SignUp
        public User(string name, string email, string password, int roleId)
        {
            Name = name;
            Password = password;
            Email = email;
            RoleId = roleId;
        }
        // Login
        public User(string username, string password)
        {
            Name = username;
            Password = password;
        }
        public User (string username,string email, string password)
        {
            Name = username;
            Email = email;
            Password = password;
        }
        public User(int userId,  string name, string email, string password,  int role)
        {
            UserId = userId;
            Name = name;
            Password = password;
            Email = email;
            RoleId = role;
        }
        public User(int userId, string name, string email, string password, string role)
        {
            UserId = userId;
            Name = name;
            Password = password;
            Email = email;
            Role = role;
        }

        public User(int userId, string name, string email, int role)
        {
            UserId = userId;
            Name = name;
            Email = email;
            RoleId = role;
        }
        public User(string name, string email, int role)
        {
            Name = name;
            Email = email;
            RoleId = role;
        }
        public bool Login()
        {
            User u = UserCRUD.GetUser(Name);
            if (u == null)
            {
                return false;
            }
            else
            {
                if (!PasswordHasher.VerifyPassword(Password, u.Password))
                {
                    return false;
                }
            }
            User user = new User(u.Name, u.Email, u.RoleId);
            this.Email = u.Email;
            this.RoleId = u.RoleId;
            this.Name = u.Name;
            return true;
        }
        public static bool forgotRequest(string username, string email)
        {
            // Authenticate user
            User u = UserCRUD.GetUser(email);
            if (u == null) 
            { return false; }
            else
            {
            if (username == u.Name)
                return true;
            return false;
            }
        }
        public void ResetPassword()
        {
            Password = PasswordHasher.HashPassword(Password);

            UserCRUD.UpdateUser(this);
        }
        public void AddUser()
        {
            if (string.IsNullOrEmpty(Name) || Name == "Enter UserName")
            {
                throw new Exception("Name is required");
            }
            else if (string.IsNullOrEmpty(Email) || Email == "Enter Email")
            {
                throw new Exception("Email is required");
            }
            else if (string.IsNullOrEmpty(Password) || Password == "Enter Password")
            {
                throw new Exception("Password is required");
            }
            UserCRUD.AddUser(this);
        }
        public void UpdateUser()
        {
            if(UserId == 0)
            {
                throw new Exception("User Id is required");
            }
            else if (string.IsNullOrEmpty(Name) || Name == "Enter UserName")
            {
                throw new Exception("Name is required");
            }
            else if (string.IsNullOrEmpty(Email) || Email == "Enter Email")
            {
                throw new Exception("Email is required");
            }
            else if (string.IsNullOrEmpty(Password) || Password == "Enter Password")
            {
                throw new Exception("Password is required");
            }
            UserCRUD.UpdateUser(this);
        }
        public static void DeleteUser(int userId)
        {
            DialogResult result = MessageBox.Show(
            "Are you sure you want to delete this record?",
            "Confirm Deletion",
            MessageBoxButtons.OKCancel,
            MessageBoxIcon.Warning
            );
            if (result == DialogResult.Cancel)
                return;
            else
            {

                if (userId == 0)
                    throw new Exception("Room ID is required");
                else
                {
                    UserCRUD.DeleteUser(userId);
                }
            }
        }
    }
}
