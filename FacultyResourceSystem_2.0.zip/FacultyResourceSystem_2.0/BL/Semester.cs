﻿using System;
using System.Windows.Forms;
using Krypton_toolKit_Demo.DL;

namespace Krypton_toolKit_Demo.BL
{
    class Semester
    {
        public int semester_id { get; set; }
        public string term { get; set; }
        public int year { get; set; }

        public Semester(string term, int year, int semester_id = 0)
        {
            if (semester_id != 0)
                this.semester_id = semester_id;
            this.term = term;
            this.year = year;
        }
        public void AddSemester()
        {
            if (this.term == null || term == "")
                throw new Exception("Term cannot be empty");
            else if (this.year <= 0)
                throw new Exception("Year must be greater than 0");
            else
            {
                Semester s = new Semester(term, year);
                SemesterCRUD.AddSemesterToDB(s);
            }
        }
        public void UpdateSemester()
        {
            if (term == null || term == "")
                throw new Exception("Term cannot be empty");
            else if (year <= 0)
                throw new Exception("Year must be greater than 0");
            else
            {
                Semester s = new Semester(term, year, semester_id);
                SemesterCRUD.UpdateSemesterInDB(s);
            }
        }
        public static void DeleteSemester(int semID)
        {

            DialogResult result = MessageBox.Show(
            "Are you sure you want to delete this semester?",
            "Confirm Deletion",
            MessageBoxButtons.OKCancel,
            MessageBoxIcon.Warning
            );
            if (result == DialogResult.Cancel)
                return;
            else
            {
                SemesterCRUD.DeleteSemesterFromDB(semID);
            }
        }
    }
}
