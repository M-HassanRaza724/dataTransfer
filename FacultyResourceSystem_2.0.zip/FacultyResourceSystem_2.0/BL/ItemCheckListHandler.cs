﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ComponentFactory.Krypton.Toolkit;

namespace Krypton_toolKit_Demo.BL
{
    class ItemCheckListHandler
    {
        private  KryptonCheckedListBox itemCheckList;

        public ItemCheckListHandler(KryptonCheckedListBox checkList)
        {
            itemCheckList = checkList;
        }

        public List<string> GetCheckedItems()
        {
            var checkedItems = itemCheckList.CheckedItems.Cast<string>().ToList();

            if (checkedItems.Count == itemCheckList.Items.Count || checkedItems.Count == 0)
            {
                return null;
            }

            return checkedItems;
        }
    }
}
