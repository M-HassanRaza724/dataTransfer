﻿using System;
using System.Windows.Forms;
using Krypton_toolKit_Demo.DL;

namespace Krypton_toolKit_Demo.BL
{
    public class CourseAllocationDTO
    {
        public int? FacultyCourseId { get; set; }
        public int? CourseId { get; set; }
        public string CourseName { get; set; }
        public string CourseType { get; set; }
        public int? SemesterId { get; set; }
        public string SemesterTerm { get; set; }
        public int? SemesterYear { get; set; }

        public int FacultyId { get; set; }
        public string FacultyName { get; set; }

        public bool Check()
        {
            if (CourseId == null)
            {
                MessageBox.Show("Course is required");
                return false;
            }
            else if (SemesterId == null)
            {
                MessageBox.Show("Semester is required");
                return false;
            }
            else if (FacultyId == 0)
            {
                MessageBox.Show("Faculty is required");
                return false;
            }
            else
                return true;
        }
        public void AddCourseAllocation()
        {
            try
            {

                if (Check())
                     CourseAllocationCRUD.AddCourseAllocation(this);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void UpdateCourseAllocation()
        {
            try
            {

                if (FacultyCourseId == null || FacultyCourseId == 0)
                {
                    MessageBox.Show("FacultyCourseId is required");
                    return;
                }
                else if (Check())
                    CourseAllocationCRUD.UpdateCourseAllocation(this);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public static void DeleteCourseAllocation(int FacultyCourseId)
        {
            try
            {

                DialogResult result = MessageBox.Show(
                   "Are you sure you want to delete this record?",
                   "Confirm Deletion",
                   MessageBoxButtons.YesNo,
                   MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                    CourseAllocationCRUD.DeleteCourseAllocation(FacultyCourseId);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
