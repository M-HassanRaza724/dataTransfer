﻿using System;
using System.Windows.Forms;
using Krypton_toolKit_Demo.DL;

namespace Krypton_toolKit_Demo.BL
{
    class Project
    {
        public int project_id { get; set; }
        public string title { get; set; }
        public string description { get; set; }
        public Project(int project_id, string title, string description)
        {
            this.project_id = project_id;
            this.title = title;
            this.description = description;
        }
        public Project(string title, string description)
        {
            this.title = title;
            this.description = description;
        }
        public void AddProject()
        {
            if (string.IsNullOrEmpty(title) || title == "Enter Project Title")
                throw new System.Exception("Title cannot be empty");
            else if (string.IsNullOrEmpty(description) || description == "Enter Project Description")
                throw new System.Exception("Description cannot be empty");
            else
                ProjectCRUD.AddProject(this);
        }
        public void UpdateProject()
        {
            if (string.IsNullOrEmpty(title) || title == "Enter Project Title")
                throw new System.Exception("Title cannot be empty");
            else if (project_id == 0)
                throw new System.Exception("Project ID cannot be 0");
            else if (string.IsNullOrEmpty(description) || description == "Enter Project Description")
                throw new System.Exception("Description cannot be empty");
            else
                ProjectCRUD.UpdateProject(this);
        }
        public static void DeleteProject(int projectId)
        {
            DialogResult result = MessageBox.Show(
            "Are you sure you want to delete this record?",
            "Confirm Deletion",
            MessageBoxButtons.OKCancel,
            MessageBoxIcon.Warning
            );
            if (result == DialogResult.Cancel)
                return;
            else
            {

                if (projectId == 0)
                    throw new Exception("Room ID is required");
                else
                {
                    ProjectCRUD.DeleteProject(projectId);
                }
            }
        }
    }
}
