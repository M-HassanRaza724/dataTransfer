﻿using Krypton_toolKit_Demo.DL;
using System;
using System.Windows.Forms;

namespace Krypton_toolKit_Demo.BL
{
    public class FacultyRequestDTO
    {
        public int request_id { get; set; }
        public int faculty_id { get; set; }
        public string faculty_name { get; set; }
        public int item_id { get; set; }
        public string item { get; set; }
        public int quantity { get; set; }
        public int status_id { get; set; }
        public string status { get; set; }
        public DateTime request_date { get; set; }
        public FacultyRequestDTO(string item, int quantity, string status, DateTime requestDate, int request_id = -1)
        {
            this.item = item;
            this.quantity = quantity;
            this.status = status;
            this.request_date = requestDate;
            if (request_id != -1)
            {
                this.request_id = request_id;
            }
        }
        public FacultyRequestDTO(int facultyId, int item_id, int quantity)
        {
            this.faculty_id = facultyId;
            this.item_id = item_id;
            this.quantity = quantity;
            this.status_id = 8;
            this.request_date = DateTime.Now;
        }

        public static void DeleteFacultyRequest(int requestId)
        {
            DialogResult result = MessageBox.Show(
         "Are you sure you want to delete this record?",
         "Confirm Deletion",
         MessageBoxButtons.OKCancel,
         MessageBoxIcon.Warning
         );
            if (result == DialogResult.Cancel)
                return;
            else
            {

                if (requestId == 0)
                    throw new Exception("Room ID is required");
                else
                {
                    FacultyRequestCRUD.DeleteFacultyRequest(requestId);
                }
            }
        }

        internal static void AddFacultyRequest(FacultyRequestDTO fr)
        {
            if (fr == null)
            {
                throw new Exception("Faculty Request is required");
            }
            else if (fr.faculty_id == 0)
            {
                throw new Exception("Faculty ID is required");
            }
            else if (fr.item_id == 0)
            {
                throw new Exception("Item ID is required");
            }
            else if (fr.quantity <= 0)
            {
                throw new Exception("Quantity must be greater than 0");
            }
            else
            {
                FacultyRequestCRUD.AddFacultyRequest(fr);
            }
        }

        
    }
}
