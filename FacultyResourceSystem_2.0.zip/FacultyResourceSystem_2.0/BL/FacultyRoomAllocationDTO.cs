﻿using Krypton_toolKit_Demo.DL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Krypton_toolKit_Demo.BL
{
    public class FacultyRoomAllocationDTO
    {
        public int AllocationId { get; set; }
        public int? RoomId { get; set; } 
        public string RoomName { get; set; } 
        public int ReservedHours { get; set; }
        public int? SemesterId { get; set; } 
        public string SemesterTerm { get; set; }
        public int? SemesterYear { get; set; }

        public int FacultyId { get; set; }
        public string FacultyName { get; set; }



        public bool Check()
        {
            if (RoomId == null)
            {
                MessageBox.Show("Room is required");
                return false;
            }
            else if (SemesterId == null)
            {
                MessageBox.Show("Semester is required");
                return false;
            }
            else if (FacultyId == 0)
            {
                MessageBox.Show("Faculty is required");
                return false;
            }
            else
                return true;
        }
        public void AddRoomAllocation()
        {
            try
            {

                if (Check())
                    FacultyRoomAllocationCRUD.AddRoomAllocation(this);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void UpdateRoomAllocation()
        {
            try
            {

                if (AllocationId == 0)
                {
                    MessageBox.Show("AllocationId is required");
                    return;
                }
                else if (Check())
                    FacultyRoomAllocationCRUD.UpdateRoomAllocation(this);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public static void DeleteRoomAllocation(int AllocationId)
        {
            try
            {

                DialogResult result = MessageBox.Show(
                   "Are you sure you want to delete this record?",
                   "Confirm Deletion",
                   MessageBoxButtons.YesNo,
                   MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                    FacultyRoomAllocationCRUD.DeleteRoomAllocation(AllocationId);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
