﻿using System;
using Krypton_toolKit_Demo.DL;
using Org.BouncyCastle.Asn1.Cmp;

namespace Krypton_toolKit_Demo.BL
{
    public class Course
    {
        public int course_id { get; set; }
        public string course_name { get; set; }
        public string course_type { get; set; }
        public int credit_hours { get; set; }
        public int contact_hours { get; set; }
        public Course(string course_name, int credit_hours, int contact_hours, string course_type = "Theory", int course_id = 0)
        {
            if (course_id != 0)
                this.course_id = course_id;
            this.course_name = course_name;
            this.course_type = course_type;
            this.credit_hours = credit_hours;
            this.contact_hours = contact_hours;
        }
        public Course() { }

        public void AddCourse()
        {
            if (course_name == null || course_name == "")
                throw new Exception("Course Name is required");
            else if (credit_hours <= 0)
                throw new Exception("Credit Hours must be greater than 0");
            else if (contact_hours <= 0)
                throw new Exception("Contact Hours must be greater than 0");
            else
            {
                Course c = new Course(course_name, credit_hours, contact_hours, course_type);
                CourseCRUD.AddCourseToDB(c);
            }
        }
        public void UpdateCourse()
        {
            if (course_id == 0)
                throw new Exception("Course ID is required");
            else if (course_name == null || course_name == "")
                throw new Exception("Course Name is required");
            else if (credit_hours <= 0)
                throw new Exception("Credit Hours must be greater than 0");
            else if (contact_hours <= 0)
                throw new Exception("Contact Hours must be greater than 0");
            else
            {
                Course c = new Course(course_name, credit_hours, contact_hours, course_type, course_id);
                CourseCRUD.UpdateCourseInDB(c);
            }
        }
    }
}
