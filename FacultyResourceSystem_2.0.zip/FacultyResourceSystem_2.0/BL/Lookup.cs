﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Krypton_toolKit_Demo.BL
{
    public class Lookup
    {
        public int lookup_id { get; set; }
        public string category { get ; set; }
        public string value { get ; set; }

        public Lookup(int lookup_id, string category, string value)
        {
            this.lookup_id = lookup_id;
            this.category = category;
            this.value = value;
        }
        public Lookup(string category, string value)
        {
            this.category = category;
            this.value = value;
        }
    }
}
