﻿using System;
using System.Windows.Forms;
using Krypton_toolKit_Demo.DL;
using MessageBox = System.Windows.Forms.MessageBox;

namespace Krypton_toolKit_Demo.BL
{
    public class FacultyProjectSupervisionDTO
    {
        public int FacultyProjectId { get; set; }
        public int FacultyId { get; set; }
        public string FacultyName { get; set; }
        public int ProjectId { get; set; } 
        public string ProjectTitle { get; set; } 
        public string ProjectDescription { get; set; } 
        public int SemesterId { get; set; } 
        public string SemesterTerm { get; set; } 
        public int SemesterYear { get; set; } 
        public int SupervisionHours { get; set; } 

        public bool Check()
        {
            if (FacultyId == 0)
                return false;
            if (ProjectId == 0)
                return false;
            if (SemesterId == 0)
                return false;
            if (SupervisionHours <= 0)
                return false;
            return true;
        }
        internal static void DeleteProjectSupervision(int facultyProjectId)
        {
            try
            {

                DialogResult result = MessageBox.Show(
                   "Are you sure you want to delete this record?",
                   "Confirm Deletion",
                   MessageBoxButtons.YesNo,
                   MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                    ProjectSupervisionCRUD.DeleteProjectSupervision(facultyProjectId);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        internal void AddProjectSupervision()
        {
            try
            {

                if (Check())
                    ProjectSupervisionCRUD.AddProjectSupervision(this);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        internal void UpdateProjectSupervision()
        {
            try
            {
                if (FacultyProjectId == 0)
                {
                    MessageBox.Show("Please select a project to update");
                    return;
                }
                if (Check())
                    ProjectSupervisionCRUD.UpdateProjectSupervision(this);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
