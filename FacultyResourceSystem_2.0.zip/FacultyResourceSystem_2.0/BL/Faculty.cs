﻿using Krypton_toolKit_Demo.DL;
using System;
using System.Windows.Forms;
namespace Krypton_toolKit_Demo.BL
{
    class Faculty
    {
        public int faculty_id { get; set; }
        public string name { get; set; }
        public string email { get; set; }
        public string contact { get; set; }
        public int designation_id { get; set; }
        public string designation { get; set; }
        public string research_area { get; set; }
        public int total_teaching_hours { get; set; }
        public int user_id { get; set; }
        public Faculty(int faculty_id, string name, string email, string contact, int designation_id, string research_area, int total_teaching_hours, int user_id = 0)
        {
            this.faculty_id = faculty_id;
            this.name = name;
            this.email = email;
            this.contact = contact;
            this.designation_id = designation_id;
            this.research_area = research_area;
            this.total_teaching_hours = total_teaching_hours;
            if (user_id != 0)
                this.user_id = user_id;
        }
        public Faculty(int faculty_id, string name, string email, string contact, string designation, string research_area, int total_teaching_hours, int user_id)
        {
            this.faculty_id = faculty_id;
            this.name = name;
            this.email = email;
            this.contact = contact;
            this.designation = designation;
            this.research_area = research_area;
            this.total_teaching_hours = total_teaching_hours;
            this.user_id = user_id;
        }
        public Faculty(string name, string email, string contact, int designation_id, string research_area, int total_teaching_hours, int user_id)
        {
            this.name = name;
            this.email = email;
            this.contact = contact;
            this.designation_id = designation_id;
            this.research_area = research_area;
            this.total_teaching_hours = total_teaching_hours;
            this.user_id = user_id;
        }
        public bool isValid()
        {
            bool rtn = true;
            if (string.IsNullOrEmpty(name) || name == "Enter Faculty Name")
            {
                rtn = false;
                throw new Exception("Name is required");
            }
            else if (string.IsNullOrEmpty(email) || email == "Enter Email")
            {
                rtn = false;
                throw new Exception("Email is required");
            }
            else if (string.IsNullOrEmpty(contact) || contact == "Enter Contact")
            {
                rtn = false;
                throw new Exception("Contact is required");
            }
            else if (contact.Length > 11 || contact.Length < 11)
            {
                rtn = false;
                throw new Exception("Contact must be 11 digits");
            }
            else if (!email.Contains("@"))
            {
                rtn = false;
                throw new Exception(email + " is not a valid email");
            }
            else if (designation_id == 0)
            {
                rtn = false;
                throw new Exception("Designation is required");
            }
            else if (string.IsNullOrEmpty(research_area) || research_area == "Enter Research Area")
            {
                rtn = false;
                throw new Exception("Research Area is required");
            }
            else if (total_teaching_hours <= 0)
            {
                rtn = false;
                throw new Exception("Total Teaching Hours is required or cant be zero");
            }
            return rtn;
        }
        public void AddFaculty()
        {
            if (string.IsNullOrEmpty(name) || name == "Enter Faculty Name")
            {
                throw new Exception("Name is required");
            }
            else if (string.IsNullOrEmpty(email) || email == "Enter Email")
            {
                throw new Exception("Email is required");
            }
            else if (string.IsNullOrEmpty(contact) || contact == "Enter Contact")
            {
                throw new Exception("Contact is required");
            }
            else if (contact.Length > 11 || contact.Length < 11)
            {
                throw new Exception("Contact must be 11 digits");
            }
            else if (!email.Contains("@"))
            {
                throw new Exception(email + " is not a valid email");
            }
            else if (designation_id == 0)
            {
                throw new Exception("Designation is required");
            }
            else if (string.IsNullOrEmpty(research_area) || research_area == "Enter Research Area")
            {
                throw new Exception("Research Area is required");
            }
            else if (total_teaching_hours == 0)
            {
                throw new Exception("Total Teaching Hours is required");
            }
            else
                FacultyCRUD.AddFaculty(this);
        }
        public void UpdateFaculty()
        {
            if (isValid())
                FacultyCRUD.UpdateFaculty(this);
        }
         public static  void DeleteFaculty(int facultyId)
        {
            DialogResult result = MessageBox.Show(
            "Are you sure you want to delete this record?",
            "Confirm Deletion",
            MessageBoxButtons.OKCancel,
            MessageBoxIcon.Warning
            );
            if (result == DialogResult.Cancel)
                return;
            else
            {

                if (facultyId == 0)
                    throw new Exception("Faculty ID is required");
                else
                {
                    FacultyCRUD.DeleteFaculty(facultyId);
                }
            }
        }
    }
}
