﻿using Krypton_toolKit_Demo.DL;
using System;
using System.Windows.Forms;
using MessageBox = System.Windows.Forms.MessageBox;

namespace Krypton_toolKit_Demo.BL
{
    public class FacultyAdminRoleDTO
    {
        public int FacultyId { get; set; }
        public string FacultyName { get; set; }
        public string RoleName { get; set; } 
        public int? AdminRoleId { get; set; }
        public int? SemesterId { get; set; } 
        public string SemesterTerm { get; set; }
        public int? SemesterYear { get; set; }
        public bool Check()
        {
            if (string.IsNullOrEmpty(RoleName) || RoleName == "Enter Role Name")
            {
                MessageBox.Show("Role Name is required");
                return false;
            }
            else if (SemesterId == null)
            {
                MessageBox.Show("Semester is required");
                return false;
            }
            else if (FacultyId == 0)
            {
                MessageBox.Show("Faculty is required");
                return false;
            }
            else
                return true;
        }
        public void AddFacultyAdminRole()
        {
            //SemesterId = SemesterCRUD.GetSemesterId( SemesterYear.Value,SemesterTerm);
            if (Check())
                FacultyAdminRoleCRUD.AddFacultyAdminRole(this);
        }
        public void UpdateFacultyAdminRole()
        {
            if (AdminRoleId == null || AdminRoleId == 0)
            {
                MessageBox.Show("AdminRoleId is required");
                return;
            }
            else if (Check())
            {
                //SemesterId = SemesterCRUD.GetSemesterId(SemesterYear.Value, SemesterTerm);
                FacultyAdminRoleCRUD.UpdateFacultyAdminRole(this);
            }
        }
        public static void DeleteFacultyAdminRole(int AdminRoleId)
        {
            DialogResult result = MessageBox.Show(
               "Are you sure you want to delete this record?",
               "Confirm Deletion",
               MessageBoxButtons.OKCancel,
               MessageBoxIcon.Warning
               );
            if (result == DialogResult.Cancel)
                return;
            else
            {

                if (AdminRoleId == 0)
                    throw new Exception("Room ID is required");
                else
                {
                    FacultyAdminRoleCRUD.DeleteFacultyAdminRole(AdminRoleId);
                }
            }
        }

    }
}
