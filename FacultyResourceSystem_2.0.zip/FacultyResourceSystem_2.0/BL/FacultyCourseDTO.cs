﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace Krypton_toolKit_Demo.BL
{
    public class FacultyCourseDTO
    {
        public int FacultyCourseId { get; set; }
        public string CourseName { get; set; }
        public string CourseType { get; set; }
        public string SemesterTerm { get; set; }
        public int SemesterYear { get; set; }

        public string FacultyName { get; set; }
        public override string ToString()
        {
            return $"{FacultyName}-{CourseName}-{CourseType}-{SemesterTerm}-{SemesterYear}";
        }
        public static int GetFacultyCourseId(FacultyCourseDTO facultyCourse)
        {
            string query = $"SELECT facultyCourseId FROM (SELECT  fc.faculty_course_id AS FacultyCourseId, f.name AS FacultyName, COALESCE(c.course_name, 'No Course Assigned') AS CourseName, c.course_type AS CourseType, s.term AS SemesterTerm, s.year AS SemesterYear FROM faculty f   INNER JOIN faculty_courses fc ON f.faculty_id = fc.faculty_id   INNER JOIN courses c ON fc.course_id = c.course_id INNER JOIN semesters s ON fc.semester_id = s.semester_id ) WHERE (FacultyName, CourseName, CourseType, SemesterTerm, SemesterYear) value ('{facultyCourse.FacultyName}', '{facultyCourse.CourseName}', '{facultyCourse.CourseType}', '{facultyCourse.SemesterTerm}', {facultyCourse.SemesterYear})";
            using (var reader = DatabaseHelper.Instance.getData(query))
            {
                if (reader.Read())
                {
                    return reader.GetInt32(reader.GetOrdinal("FacultyCourseId"));
                }
                return -1;
            }
        }
        public static List<FacultyCourseDTO> GetFacultyCourses()
        {
            List<FacultyCourseDTO> facultyCourses = new List<FacultyCourseDTO>();
            string query = "SELECT  fc.faculty_course_id AS FacultyCourseId, f.name AS FacultyName, COALESCE(c.course_name, 'No Course Assigned') AS CourseName, c.course_type AS CourseType, s.term AS SemesterTerm, s.year AS SemesterYear FROM faculty f   INNER JOIN faculty_courses fc ON f.faculty_id = fc.faculty_id   INNER JOIN courses c ON fc.course_id = c.course_id INNER JOIN semesters s ON fc.semester_id = s.semester_id WHERE 1=1";
            using (var reader = DatabaseHelper.Instance.getData(query))
            {
                while (reader.Read())
                {
                    facultyCourses.Add(new FacultyCourseDTO
                    {
                        FacultyCourseId = reader.GetInt32(reader.GetOrdinal("FacultyCourseId")),
                        FacultyName = reader.GetString(reader.GetOrdinal("FacultyName")),
                        CourseName = reader.GetString(reader.GetOrdinal("CourseName")),
                        CourseType = reader.GetString(reader.GetOrdinal("CourseType")),
                        SemesterTerm = reader.GetString(reader.GetOrdinal("SemesterTerm")),
                        SemesterYear = reader.GetInt32(reader.GetOrdinal("SemesterYear"))
                    });
                }
            }
            return facultyCourses;
        }
        //public static 
    }
}