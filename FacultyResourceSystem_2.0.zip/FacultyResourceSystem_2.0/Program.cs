﻿using Krypton_toolKit_Demo.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Krypton_toolKit_Demo
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            DL.LookupCRUD.LoadLookups();
            //MessageBox.Show($"{DL.LookupCRUD.GetId("Lecturer")}");
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new LoginForm());
          
        }
    }
}
